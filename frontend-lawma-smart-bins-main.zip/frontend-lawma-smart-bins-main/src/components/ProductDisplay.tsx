import { Card } from "@/components/ui/card";

const ProductDisplay = () => {
  return (
    <Card className="p-6 max-w-3xl mx-auto">
      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-4 flex flex-col items-center justify-center">
          {/* Remove text "Waste Bin" and insert large image */}
          <img
            src="https://placehold.co/600x400/F2FCE2/1A1F2C/png?text=SMART+BIN"
            alt="Smart Bin"
            className="rounded-lg w-full"
            style={{ maxWidth: "340px" }}
          />
        </div>
        <div className="space-y-6 flex flex-col justify-center">
          <div>
            <h1 className="text-2xl font-semibold text-[#1A1F2C] mb-2">
              Introducing SMART BIN Technology into Waste Management.
            </h1>
            <h2 className="text-lg font-medium mb-2">
              Welcome to the Internet of Bins
            </h2>
            <h3 className="mb-4 text-base font-normal">
              Building a Smart City of Interconnected Waste Bins
            </h3>
            <p className="text-gray-600">
              The Internet of Bins is our answer to the Internet of Things. Intelligent and connected SMART Waste Bins in combination with innovative and disruptive solutions are the future of Waste Management 
              <br /><br />
              Our SMART bins, which are RFID enabled for tracking and identification, are laser fitted with individual programmable QR code and unique alphanumeric numbers. Each bin has an ultra-high frequency chip fitted, along with a QR Code and a Unique Serial Number laser printed on the back of the bin.
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default ProductDisplay;
