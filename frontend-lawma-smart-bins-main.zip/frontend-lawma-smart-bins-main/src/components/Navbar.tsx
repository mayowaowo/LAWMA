import {useEffect, useState} from "react";
import {Link, useNavigate, useLocation} from "react-router-dom";
import {Button} from "@/components/ui/button";
import {LogOut, User, Home, ShoppingBag, Menu, X} from "lucide-react";
import {toast} from "sonner";
import {useDispatch, useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {clearOrders, handleLogoutRequest} from "@/services/constant/actions.ts";

const Navbar = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const authState = useSelector((state: RootState) => state.auth);
    const userState = useSelector((state: RootState) => state.user);
    const dispatch = useDispatch();
    const {isAuthenticated} = authState;
    const {user} = userState;

    useEffect(() => {
        if (isAuthenticated) {
            setIsLoggedIn(true);
        } else {
            setIsLoggedIn(false);
            setIsAdmin(false);
        }
    }, [location.pathname]);

    const handlesLogout = () => {
        dispatch(clearOrders());
        dispatch(handleLogoutRequest());
        toast.success("You have been logged out successfully");
        setIsMobileMenuOpen(false);
        navigate("/");
    };

    return (
        <div className="w-full border-b bg-white/60 backdrop-blur-md relative z-50">
            <div className="container mx-auto px-4 py-3">
                <div className="flex justify-between items-center">
                    <Link to="/" className="flex items-center gap-2">
                        <img
                            src="/lovable-uploads/64c46b42-4d7d-498c-94bb-68ee9a2988c3.png"
                            alt="Logo"
                            className="h-10 w-10 rounded-full"
                        />
                    </Link>

                    {/* Desktop Navigation */}
                    <div className="hidden md:flex items-center gap-4">
                        <Link to="/" className="text-gray-600 hover:text-[#6E59A5] flex items-center gap-1">
                            <Home size={16}/>
                            <span>Home</span>
                        </Link>

                        {isLoggedIn && (
                            <>
                                <Link to="/order"
                                      className="text-gray-600 hover:text-[#6E59A5] flex items-center gap-1">
                                    <ShoppingBag size={16}/>
                                    <span>Order</span>
                                </Link>
                                <Link to="/account"
                                      className="text-gray-600 hover:text-[#6E59A5] flex items-center gap-1">
                                    <User size={16}/>
                                    <span>Account</span>
                                </Link>
                                <Button
                                    variant="outline"
                                    size="sm"
                                    className="text-red-500 border-red-500 hover:bg-red-50"
                                    onClick={handlesLogout}
                                >
                                    <LogOut size={16} className="mr-1"/>
                                    Logout
                                </Button>
                            </>
                        )}

                        {!isLoggedIn && (
                            <>
                                <Link to="/login">
                                    <Button variant="ghost" size="sm"
                                            className="bg-[#076836] hover:bg-[#076836]/90 text-white rounded-full px-6 py-2">Log
                                        In</Button>
                                </Link>
                                <div className="w-[1px] h-6 bg-[#2C2E2A]"></div>
                                <Link to="/register">
                                    <Button size="sm" variant="ghost">Register</Button>
                                </Link>
                            </>
                        )}
                    </div>

                    {/* Mobile Menu Button */}
                    <button
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                        className="md:hidden p-2"
                    >
                        {isMobileMenuOpen ? <X size={24}/> : <Menu size={24}/>}
                    </button>
                </div>

                {/* Mobile Navigation Menu */}
                {isMobileMenuOpen && (
                    <div className="md:hidden fixed inset-x-0 top-[64px] z-50 bg-white border-b shadow-lg">
                        <div className="flex flex-col p-4 space-y-4">
                            <Link
                                to="/"
                                className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded"
                                onClick={() => setIsMobileMenuOpen(false)}
                            >
                                <Home size={16}/>
                                <span>Home</span>
                            </Link>

                            {isLoggedIn ? (
                                <>
                                    <Link
                                        to="/order"
                                        className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded"
                                        onClick={() => setIsMobileMenuOpen(false)}
                                    >
                                        <ShoppingBag size={16}/>
                                        <span>Order</span>
                                    </Link>
                                    <Link
                                        to="/account"
                                        className="flex items-center gap-2 p-2 hover:bg-gray-100 rounded"
                                        onClick={() => setIsMobileMenuOpen(false)}
                                    >
                                        <User size={16}/>
                                        <span>Account</span>
                                    </Link>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        className="text-red-500 border-red-500 hover:bg-red-50 w-full"
                                        onClick={handlesLogout}
                                    >
                                        <LogOut size={16} className="mr-1"/>
                                        Logout
                                    </Button>
                                </>
                            ) : (
                                <div className="space-y-2">
                                    <Link
                                        to="/login"
                                        className="w-full"
                                        onClick={() => setIsMobileMenuOpen(false)}
                                    >
                                        <Button variant="ghost" size="sm"
                                                className="w-full bg-[#076836] hover:bg-[#076836]/90 text-white">
                                            Log In
                                        </Button>
                                    </Link>
                                    <Link
                                        to="/register"
                                        className="w-full"
                                        onClick={() => setIsMobileMenuOpen(false)}
                                    >
                                        <Button size="sm" variant="ghost" className="w-full">
                                            Register
                                        </Button>
                                    </Link>
                                </div>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Navbar;
