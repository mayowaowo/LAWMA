import {useState} from 'react';
import {Dialog, DialogContent, DialogHeader, DialogTitle} from "@/components/ui/dialog";
import {Button} from "@/components/ui/button";
import {Input} from "@/components/ui/input";
import {Label} from "@/components/ui/label";
import {Loader2} from "lucide-react";

// Verification Modal Component
interface VerificationModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (data: { bvn: string; nin: string }) => void;
}

export const VerificationModal = ({isOpen, onClose, onSubmit}: VerificationModalProps) => {
    const [bvn, setBvn] = useState("");
    const [nin, setNin] = useState("");
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);

        if (bvn.length !== 11 || nin.length !== 11) {
            setError("BVN and NIN must be 11 digits each");
            return;
        }

        try {
            setLoading(true);
            await onSubmit({bvn, nin});
            onClose();
        } catch (error) {
            setError("Verification failed. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle className="text-xl font-semibold text-center">
                        Verify for Installment Payment
                    </DialogTitle>
                    <p className="text-center text-sm text-gray-500">
                        Please provide your BVN and NIN to proceed with installment payment
                    </p>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <Label htmlFor="bvn">BVN</Label>
                            <Input
                                id="bvn"
                                type="text"
                                value={bvn}
                                onChange={(e) => {
                                    const value = e.target.value.replace(/[^0-9]/g, '');
                                    if (value.length <= 11) setBvn(value);
                                }}
                                placeholder="Enter 11-digit BVN"
                                maxLength={11}
                                required
                            />
                        </div>

                        <div className="space-y-2">
                            <Label htmlFor="nin">NIN</Label>
                            <Input
                                id="nin"
                                type="text"
                                value={nin}
                                onChange={(e) => {
                                    const value = e.target.value.replace(/[^0-9]/g, '');
                                    if (value.length <= 11) setNin(value);
                                }}
                                placeholder="Enter 11-digit NIN"
                                maxLength={11}
                                required
                            />
                        </div>
                    </div>

                    {error && (
                        <p className="text-sm text-red-500 text-center">{error}</p>
                    )}

                    <Button
                        type="submit"
                        className="w-full bg-[#076836] hover:bg-[#076836]/90"
                        disabled={loading || bvn.length !== 11 || nin.length !== 11}
                    >
                        {loading ? (
                            <div className="flex items-center gap-2">
                                <Loader2 className="h-4 w-4 animate-spin"/>
                                <span>Verifying...</span>
                            </div>
                        ) : (
                            'Verify'
                        )}
                    </Button>
                </form>
            </DialogContent>
        </Dialog>
    );
};

