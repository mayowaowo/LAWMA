import React, {useState} from "react";
import {useForm} from "react-hook-form";
import {Button} from "@/components/ui/button";
import {Form, FormField, FormItem, FormLabel, FormMessage} from "@/components/ui/form";
import {Input} from "@/components/ui/input";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";

export const RepaymentModal = ({
                                   open,
                                   onClose,
                                   order,
                                   handleRepayment,
                               }: {
    open: boolean;
    onClose: () => void;
    order;
    handleRepayment: (data) => void;
}) => {
    const form = useForm();
    const [loading, setLoading] = useState(false);

        const onSubmit = (data) => {
        const payload = {
            "order_reference": order?.orderReference || '',
            "amount": data.amount
        }
        handleRepayment(payload); // Pass the form data to the parent function
        // onClose(); // Close Modal
    };




    // If modal is not open, don't render it
    if (!open) return null;

    return (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="bg-white p-6 max-w-xl w-3/6 rounded-lg shadow-lg relative">
                {/* Modal Header */}
                <div className="flex items-center justify-between pb-4 border-b">
                    <h3 className="text-lg font-medium">Repayment Details</h3>
                    <button
                        onClick={onClose}
                        className="w-6 h-6 text-gray-500 hover:text-gray-800"
                        aria-label="Close"
                    >
                        ✕
                    </button>
                </div>

                {/* Modal Form */}
                <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        {/* Payment Type Dropdown */}
                        {/*<FormField*/}
                        {/*    control={form.control}*/}
                        {/*    name="type"*/}
                        {/*    render={({field}) => (*/}
                        {/*        <FormItem>*/}
                        {/*            <FormLabel>Repayment Type</FormLabel>*/}
                        {/*            <Select onValueChange={field.onChange} defaultValue={field.value}>*/}
                        {/*                <SelectTrigger className="w-full">*/}
                        {/*                    <SelectValue placeholder="Select repayment type"/>*/}
                        {/*                </SelectTrigger>*/}
                        {/*                <SelectContent>*/}
                        {/*                    <SelectItem value="partial">Partial</SelectItem>*/}
                        {/*                    <SelectItem value="full">Full</SelectItem>*/}
                        {/*                </SelectContent>*/}
                        {/*            </Select>*/}
                        {/*            <FormMessage/>*/}
                        {/*        </FormItem>*/}
                        {/*    )}*/}
                        {/*/>*/}

                        {/* Payment Amount */}
                        <FormField
                            control={form.control}
                            name="amount"
                            render={({field}) => (
                                <FormItem>
                                    <FormLabel>Amount</FormLabel>
                                    <Input
                                        placeholder="Enter amount"
                                        {...field}
                                        className="pl-10"
                                        type="number"
                                    />
                                    <FormMessage/>
                                </FormItem>
                            )}
                        />

                        {/* Submit and Cancel Buttons */}
                        <div className="mt-6 flex justify-end space-x-2">
                            <Button variant="outline" onClick={onClose} className="text-gray-700">
                                Cancel
                            </Button>
                            <Button type="submit" className="bg-blue-500 text-white hover:bg-blue-600">
                                {
                                    loading ? 'Loading' : 'Confirm Repayment'
                                }

                            </Button>
                        </div>
                    </form>
                </Form>
            </div>
        </div>
    );
};
