
import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import AdminSidebar from "./AdminSidebar";

interface AdminLayoutProps {
  children: ReactNode;
}

const AdminLayout = ({ children }: AdminLayoutProps) => {
  // Check if user is admin
  const userInfo = localStorage.getItem("userInfo");
  let isAdmin = false;
  
  if (userInfo) {
    try {
      const user = JSON.parse(userInfo);
      isAdmin = user.isAdmin === true;
    } catch (error) {
      console.error("Failed to parse user info:", error);
    }
  }

  // Redirect non-admin users
  if (!isAdmin) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      <AdminSidebar />
      <div className="flex-1 p-6">
        {children}
      </div>
    </div>
  );
};

export default AdminLayout;
