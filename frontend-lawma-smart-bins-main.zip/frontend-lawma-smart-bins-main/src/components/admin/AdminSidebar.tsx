
import { Link } from "react-router-dom";
import { Users, ShoppingBag, Settings, Home } from "lucide-react";

const AdminSidebar = () => {
  const menuItems = [
    { name: "Dashboard", path: "/admin", icon: Home },
    { name: "Users", path: "/admin/users", icon: Users },
    { name: "Orders", path: "/admin/orders", icon: ShoppingBag },
    { name: "Settings", path: "/admin/settings", icon: Settings },
  ];

  return (
    <div className="w-64 bg-[#1A1F2C] text-white min-h-screen">
      <div className="p-4 border-b border-gray-700">
        <Link to="/admin" className="flex items-center gap-2">
          <img 
            src="/lovable-uploads/64c46b42-4d7d-498c-94bb-68ee9a2988c3.png" 
            alt="Logo" 
            className="h-10 w-10 rounded-full"
          />
          <span className="text-xl font-bold">Admin Portal</span>
        </Link>
      </div>
      <nav className="p-4">
        <ul className="space-y-2">
          {menuItems.map((item) => (
            <li key={item.name}>
              <Link
                to={item.path}
                className="flex items-center gap-3 px-4 py-2 rounded-md hover:bg-[#6E59A5]/20 transition-colors"
              >
                <item.icon size={18} />
                <span>{item.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </div>
  );
};

export default AdminSidebar;
