
import { useState } from "react";
import { Card } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Banknote } from "lucide-react";
import {useDispatch, useSelector} from "react-redux";
import {handleInstallmentPeriod, handlePaymentType} from "@/services/constant/actions.ts";
import {PRODUCTS} from "@/config/products.ts";
import {RootState} from "@/services/reducers/rootReducer.ts";

type PaymentType = "ONEOFF" | "INSTALLMENT";
type InstallmentPeriod = "3" | "4" | "5";

interface PaymentOptionsProps {
  onSubmit?: (paymentType) => void;
}

const PaymentOptions = ({ onSubmit }: PaymentOptionsProps) => {
  const [paymentType, setPaymentType] = useState<PaymentType>("ONEOFF");
  const [installmentPeriod, setInstallmentPeriod] = useState<InstallmentPeriod>("3");
  const dispatch = useDispatch();
  const initialPaymentPercentage = 25;
  const OrderState = useSelector((state: RootState) => state.orders);
  const {orders} = OrderState
  // const totalAmount = baseAmount;
  const totalAmount = orders.reduce((total, item) => {
    const product = PRODUCTS.find(p => p.id === item.productId);
    if (product) {
      total += product.price * item.quantity;
    }
    return total;
  }, 0);
  const initialPayment = paymentType === "INSTALLMENT" ?
    (totalAmount * initialPaymentPercentage / 100) : totalAmount;

  const calculateMonthlyPayment = () => {
    if (paymentType === "ONEOFF") return 0;
    const remainingBalance = totalAmount - initialPayment;
    return Math.round(remainingBalance / Number(installmentPeriod));
  };

  const handleProceed = () => {
    // localStorage.setItem("paymentType", paymentType);
    dispatch(handlePaymentType(paymentType));
    // localStorage.setItem("paymentMethod", "transfer");
    if (paymentType === "INSTALLMENT") {
      dispatch(handleInstallmentPeriod(installmentPeriod));
      // localStorage.setItem("installmentPeriod", installmentPeriod);
    }
    if (onSubmit) onSubmit(paymentType);
  };

  return (
    <Card className="p-6 max-w-xl mx-auto mt-6">
      <h3 className="text-xl font-semibold mb-4">Payment Options</h3>
      <RadioGroup value={paymentType} onValueChange={(value) => setPaymentType(value as PaymentType)} className="space-y-4">
        <div className="flex items-center space-x-2 p-3 rounded-md border border-gray-200 bg-gray-50">
          <RadioGroupItem value="ONEOFF" id="ONEOFF" />
          <Label htmlFor="ONEOFF" className="flex-1 cursor-pointer">
            <div className="font-medium">One-time Payment</div>
            <div className="text-gray-500 text-sm">
              Pay ₦{totalAmount.toLocaleString()}
            </div>
          </Label>
        </div>

        <div className={`p-3 rounded-md border ${paymentType === "INSTALLMENT" ? "border-[#6E59A5]" : "border-gray-200"} bg-gray-50`}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="INSTALLMENT" id="INSTALLMENT" />
            <Label htmlFor="INSTALLMENT" className="flex-1 cursor-pointer">
              <div className="font-medium">Installment Payment</div>
              <div className="text-gray-500 text-sm">Initial payment (25%): ₦{initialPayment.toLocaleString()}</div>
            </Label>
          </div>

          {paymentType === "INSTALLMENT" && (
            <div className="mt-4 ml-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="period">Select payment period</Label>
                <Select value={installmentPeriod} onValueChange={(value) => setInstallmentPeriod(value as InstallmentPeriod)}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select months" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="3">3 months</SelectItem>
                    <SelectItem value="5">5 months</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="p-3 bg-white rounded border border-gray-200">
                <p className="font-bold">
                  NOTICE:
                </p>
                <p className="text-sm">
                  As part of your installment payment plan, a secure payment link will be sent to the email address you
                  provided during registration. Please check your inbox and your spam or junk folder, just in case to
                  ensure you don't miss it.

                </p>

                <p className="text-sm pt-5"> Your installment payment option is:</p>
                <p className="text-sm font-medium">
                  ₦{calculateMonthlyPayment().toLocaleString()} monthly for a {installmentPeriod}-month plan.
                </p>
                {/*<p className="text-gray-500 text-sm mt-1">Delivery upon completion of payment</p>*/}
              </div>
            </div>
          )}
        </div>
      </RadioGroup>

      {/*<div className="mt-6">*/}
      {/*  <div className="flex items-center space-x-2 p-3 rounded-md border border-[#6E59A5] bg-gray-50">*/}
      {/*    <Banknote className="h-4 w-4 text-[#6E59A5]" />*/}
      {/*    <span className="text-[#6E59A5]">Virtual Account Payment</span>*/}
      {/*  </div>*/}
      {/*</div>*/}

      <Button onClick={handleProceed} className="w-full mt-6 bg-[#6E59A5] hover:bg-[#6E59A5]/90">
        Proceed with Payment
      </Button>
    </Card>
  );
};

export default PaymentOptions;
