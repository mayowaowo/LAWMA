
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const Hero = ({ onOrderClick }: { onOrderClick: () => void }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] bg-gradient-to-b from-[#F2FCE2] to-white px-4">
      <h1 className="text-4xl md:text-5xl font-bold text-[#1A1F2C] text-center mb-6">
        Introducing Technology Into
        <br />
        Waste Management
      </h1>
      <p className="text-lg text-gray-600 text-center max-w-2xl mb-8">
        From simple ordering to flexible payments, we've made keeping the environment 
        clean - easy and smart.
      </p>
      <Button 
        onClick={onOrderClick}
        className="bg-[#0EA5E9] hover:bg-[#0EA5E9]/90 text-white px-8 py-6 rounded-lg text-lg flex items-center gap-2"
      >
        Order Your Waste Bin
        <ArrowRight className="w-5 h-5" />
      </Button>
    </div>
  );
};

export default Hero;
