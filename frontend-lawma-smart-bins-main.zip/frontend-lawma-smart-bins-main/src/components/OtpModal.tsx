import {useState, useEffect} from 'react'
import {Dialog, DialogContent, DialogHeader, DialogTitle} from "@/components/ui/dialog"
import {Button} from "@/components/ui/button"
import {OTPInput} from "input-otp"
import {Slot} from "@radix-ui/react-slot"
import {put} from "redux-saga/effects";
import {handleSaveUserData} from "@/services/constant/actions.ts";
import {emailVerification, getOtp} from "@/services/api/hooks/Register.ts";
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {Loader2} from "lucide-react";

interface OtpModalProps {
    isOpen: boolean
    onClose: () => void
    onSubmit: (otp: string) => void
    email?: string,
    loading: boolean// Optional email to show in the header
}

const OtpModal = ({isOpen, onClose, onSubmit, email, loading}: OtpModalProps) => {
    const [otp, setOtp] = useState<string>("")
    const [countdown, setCountdown] = useState<number>(0)
    const [canResend, setCanResend] = useState<boolean>(false)
    const UserState = useSelector((state: RootState) => state.user);
    const {user} = UserState;
    useEffect(() => {
        let timer: NodeJS.Timeout
        if (isOpen && countdown > 0) {
            timer = setInterval(() => {
                setCountdown((prev) => prev - 1)
            }, 1000)
        }

        if (countdown === 0) {
            setCanResend(true)
        }

        return () => {
            if (timer) clearInterval(timer)
        }
    }, [countdown, isOpen])

    const handleResendCode = async () => {
        try {
            // Add your resend token API call here
            const res = await getOtp(user.uuid)
            if (res.success) {
                setCountdown(30)
                setCanResend(false)
            }


        } catch (error) {
            console.error('Error resending code:', error)
        }
    }

    const handleSubmit = () => {
        if (otp.length === 6) {
            onSubmit(otp)
        }
    }

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                    <DialogTitle className="text-center">Enter Verification Code</DialogTitle>
                    {email && (
                        <p className="text-center text-sm text-gray-500">
                            We sent a code to {user.email}
                        </p>
                    )}
                </DialogHeader>

                <div className="flex flex-col items-center space-y-6">
                    <OTPInput
                        maxLength={6}
                        value={otp}
                        onChange={setOtp}
                        render={({slots}) => (
                            <div className="flex gap-2">
                                {slots.map((slot, idx) => (
                                    <Slot key={idx} {...slot}>
                                        <div
                                            className={`
                            w-12 h-12 
                            border-2 
                            rounded-md 
                            flex 
                            items-center 
                            justify-center 
                            text-lg 
                            font-semibold 
                            bg-white
                            relative
                            ${slot.isActive ? 'border-[#076836]' : 'border-gray-200'}
                        `}
                                        >
                                            {slot.char || ''}
                                            {slot.isActive && (
                                                <div
                                                    className="absolute bottom-1 w-6 h-0.5 bg-[#076836] animate-pulse"
                                                    aria-hidden="true"
                                                />
                                            )}
                                        </div>
                                    </Slot>
                                ))}
                            </div>
                        )}
                    />

                    <div className="flex flex-col items-center gap-2">
                        {countdown > 0 ? (
                            <p className="text-sm text-gray-500">
                                Resend code in {countdown}s
                            </p>
                        ) : (
                            <Button
                                variant="ghost"
                                className="text-[#076836] hover:text-[#076836]/90"
                                onClick={handleResendCode}
                                disabled={!canResend}
                            >
                                Resend Code
                            </Button>
                        )}
                    </div>

                    <Button
                        className="w-full bg-[#076836] hover:bg-[#076836]/90"
                        onClick={handleSubmit}
                        disabled={otp.length !== 6  || loading}
                    >
                        {loading ? (
                            <div className="flex items-center gap-2">
                                <Loader2 className="h-4 w-4 animate-spin"/>
                                <span>Verifying...</span>
                            </div>
                        ) : (
                            'Verify'
                        )}

                    </Button>
                </div>
            </DialogContent>
        </Dialog>
    )
}

export default OtpModal
