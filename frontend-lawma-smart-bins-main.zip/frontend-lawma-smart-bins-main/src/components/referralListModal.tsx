import {useState} from 'react';
import {Dialog, DialogContent, DialogHeader, DialogTitle} from "@/components/ui/dialog";
import {Table, TableBody, TableCell, TableHead, TableHeader, TableRow} from "@/components/ui/table";
import {format} from 'date-fns';
import {List} from 'lucide-react';

interface Referral {
    uuid: string;
    user_name: string;
    status: string;
    created_at: string;
}

interface ReferralListModalProps {
    isOpen: boolean;
    onClose: () => void;
    referrals: Referral[];
}

export const ReferralListModal = ({isOpen, onClose, referrals}: ReferralListModalProps) => {
    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-[800px]">
                <DialogHeader>
                    <DialogTitle>Referral List</DialogTitle>
                </DialogHeader>
                <div className="mt-4">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Username</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Date</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {referrals.map((referral) => (
                                <TableRow key={referral.uuid}>
                                    <TableCell>{referral.user_name}</TableCell>
                                    <TableCell>
                    <span className={`px-2 py-1 rounded-full text-xs ${
                        referral.status === 'ACTIVE'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                    }`}>
                      {referral.status}
                    </span>
                                    </TableCell>
                                    <TableCell>
                                        {format(new Date(referral.created_at), 'MMM dd, yyyy')}
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </DialogContent>
        </Dialog>
    );
};
