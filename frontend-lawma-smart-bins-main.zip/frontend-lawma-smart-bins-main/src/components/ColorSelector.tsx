
import { useState, useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";

const colors = [
  {
    id: "green-general",
    label: "Green (General Waste)",
    value: "green-general",
    class: "bg-green-500",
    lidColor: "bg-orange-500"
  },
  {
    id: "blue-recycle",
    label: "Blue (Recyclables)",
    value: "blue-recycle",
    class: "bg-blue-500",
    lidColor: "bg-orange-500"
  }
];

interface ColorSelectorProps {
  onColorSelect: (color: string) => void;
}

const ColorSelector = ({ onColorSelect }: ColorSelectorProps) => {
  const [selectedColor, setSelectedColor] = useState(colors[0].value);
  const OrderState = useSelector((state: RootState) => state.orders);
  const {color: storedColor} = OrderState;
  // Initialize from localStorage if available
  useEffect(() => {
    if (storedColor && (storedColor === "green-general" || storedColor === "blue-recycle")) {
      setSelectedColor(storedColor);
    }
  }, []);

  const handleColorChange = (value: string) => {
    setSelectedColor(value);
    // Store color in localStorage
    localStorage.setItem("selectedBinColor", value);
    onColorSelect(value);
  };

  return (
    <div className="space-y-4">
      <Label>Select Bin Color</Label>
      <RadioGroup
        value={selectedColor}
        onValueChange={handleColorChange}
        className="flex gap-4"
      >
        {colors.map((color) => (
          <div key={color.id} className="flex items-center space-x-2">
            <RadioGroupItem value={color.value} id={color.id} />
            <Label htmlFor={color.id} className="flex items-center gap-2">
              <div className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded-full ${color.class}`} />
                <div className={`w-4 h-4 rounded-full ${color.lidColor}`} />
              </div>
              {color.label}
            </Label>
          </div>
        ))}
      </RadioGroup>
    </div>
  );
};

export default ColorSelector;
