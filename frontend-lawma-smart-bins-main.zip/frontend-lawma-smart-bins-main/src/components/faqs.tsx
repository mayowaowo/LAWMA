import {useState} from "react";
import {ReactComponent as Add} from '@/assets/add.svg';


export default function FrequentlyAskedQuestions() {
    const [openIndex, setOpenIndex] = useState<number | null>(null);

    const toggleAccordion = (index: number) => {
        setOpenIndex(openIndex === index ? null : index);
    };

    const items = [
        {
            title: "What are LAWMA Smart Bins?",
            content: "LAWMA Smart Bins are advanced waste management containers equipped with geotagging technology for easy tracking. They are durable, weather-resistant, and designed specifically for Lagos State tenements to improve waste collection efficiency and environmental cleanliness."
        },
        {
            title: "What types of bins are available?",
            content: "We offer two main types of bins:\n" +
                "Green General Waste Bins - For regular household waste\n" +
                "Blue Recycle Bins - For recyclable materials like plastic, paper, and glass"
        },
        {
            title: "How much do the Smart Bins cost?",
            content: "Bin prices vary depending on size and type. Our standard bins start at ₦100,000 for a single bin. Discounts are available. Please check the ordering page for current pricing."
        },
        {
            title: "What payment options are available?",
            content: "We offer two payment options:\n" +
                "One-time full payment\n" +
                "Installment payment (25% initial payment with the remainder spread over 3 & 5 months)\n" +
                "Payment can be made through our virtual account system."
        },
        {
            title: "Is delivery included in the price?",
            content: "Yes, delivery is free within Lagos State. Our delivery team will coordinate with you to ensure prompt delivery to your specified address once payment is confirmed."
        },
        {
            title: "How long does delivery take?",
            content: "Delivery typically takes 3–5 business days after payment is confirmed. For installment payments, bins will be delivered after the final installment is paid, unless otherwise arranged."
        },
        {
            title: "What is the geotagging feature?",
            content: "The geotagging technology embedded in our Smart Bins allows LAWMA to track bin locations, optimize collection routes, and ensure proper waste management. This feature helps improve service efficiency and reduces instances of bin misplacement or theft."
        },
        {
            title: "Can I order bins for someone else?",
            content: "Yes, our platform allows you to order bins for others. During the checkout process, select the 'Order for Someone Else' option and provide the recipient's details for delivery."
        },
        {
            title: "How do I track my order?",
            content: "You can track your order through your account dashboard. After placing an order, you'll receive an order ID that you can use to check the status of your order at any time."
        },
        {
            title: "Are the bins for residential use only?",
            content: "No, our Smart Bins are suitable for various settings including:\n" +
                "Residential homes\n" +
                "Businesses and offices\n" +
                "Schools and educational institutions\n" +
                "Worship centers\n" +
                "Community areas"
        },
        {
            title: "How do I clean and maintain my bin?",
            content: "For optimal maintenance:\n" +
                "Rinse with water and mild detergent as needed\n" +
                "Keep the lid closed when not in use\n" +
                "Avoid placing extremely heavy items that could damage the bin\n" +
                "Keep away from open flames or extreme heat\n" +
                "Periodically check wheels and hinges for proper functionality"
        },
        {
            title: "What if my bin is damaged or stolen?",
            content: "If your bin is damaged under normal use, contact our customer service through your account to initiate a warranty claim. For stolen bins, report to your local police station first, then contact us with the police report. The geotagging technology may help in locating and recovering stolen bins."
        }
    ];

    return (
        <div className="w-[92%] lg:w-10/12 2xl:w-9/12 mx-auto flex flex-wrap md:flex-nowrap justify-between md:gap-y-0 gap-y-10 my-10 md:my-20">
            <div className={'flex flex-col gap-y-5 md:gap-y-10 w-full md:w-5/12'}>
                <h1 className={'text-3xl xl:text-5xl font-bold'}>Frequently Asked Questions</h1>
                <p className={'font-extralight text-sm'}>
                    Check out the LAWMA Smart Bin FAQ for quick answers
                    to commonly asked questions. We're here to support you every step of the way for a smooth,
                    hassle-free experience.</p>
                <img
                    src={'/lovable-uploads/assets/faq.png'}
                    alt={"faq"}
                    className="object-contain w-[80%] mx-auto"
                />
                {/*<a href={'/faq'} className={'text-[#009444] font-semibold'}>View All FAQ</a>*/}
            </div>
            <div className={'w-full md:w-6/12 flex flex-col gap-y-2'}>
                {items.map((item, index) => (
                    <div key={index} className="">
                        {/* Accordion Header */}
                        <button
                            onClick={() => toggleAccordion(index)}
                            className="w-full flex justify-between items-center p-2.5  text-left text-lg cursor-pointer bg-white rounded-lg  transition"
                        >
                            <span className={'flex gap-x-1.5 items-start w-[80%]'}>
                                            <span>
                                                {index + 1}.
                                            </span>
                                            <span>{item.title}</span>
                                        </span>
                            <span
                                className={`transform transition-transform ${openIndex === index ? "rotate-180" : "rotate-0"}`}>
                            <Add className="w-4 h-4 hidden md:block"
                                    preserveAspectRatio="xMidYMid meet"/>
                        </span>
                        </button>

                        {/* Accordion Content */}
                        <div
                            className={`overflow-hidden transition-all duration-300 ${openIndex === index ? "max-h-40 p-4" : "max-h-0 p-0"}`}
                        >
                            {(() => {
                                const lines = item.content.split('\n').filter(line => line.trim() !== '');
                                return (
                                    <div className="text-gray-700">
                                        <p>{lines[0]}</p>
                                        {lines.length > 1 && (
                                            <ul className="list-disc list-inside space-y-1 mt-2">
                                                {lines.slice(1).map((line, i) => (
                                                    <li key={i}>{line}</li>
                                                ))}
                                            </ul>
                                        )}
                                    </div>
                                );
                            })()}

                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
