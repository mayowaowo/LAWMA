
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useState, FormEvent, useEffect } from "react";
import { MapPin } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { handleSaveDeliveryAddress } from "@/services/constant/actions.ts";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/services/reducers/rootReducer.ts";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select.tsx";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group.tsx";
import * as z from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

const deliverySchema = z.object({
  phoneNumber: z
    .string()
    .min(11, "Phone number must be 11 digits")
    .max(11, "Phone number must be 11 digits")
    .regex(/^[0-9]+$/, "Must contain only numbers"),
});

type FormData = {
  phoneNumber: string;
};


type DeliveryType = "MYSELF" | "SOMEONEELSE";

interface DeliveryFormProps {
  onSubmit?: () => void;
}

const DeliveryForm = ({ onSubmit }: DeliveryFormProps) => {
  const [formData, setFormData] = useState({
    address: "",
    city: "",
    postalCode: "",
  });
  const [deliveryType, setDeliveryType] = useState<DeliveryType>("MYSELF");

  const [addressType, setAddressType] = useState("");
  const dispatch = useDispatch();
  const deliveryAddress = useSelector((state: RootState) => state.orders);
  const UserState = useSelector((state: RootState) => state.user);
  const { delivery } = deliveryAddress;
  const { user } = UserState
  const [orderForOthers, setOrderForOthers] = useState(false);
  const [recipientData, setRecipientData] = useState({
    fullName: "",
    phoneNumber: "",
  });
  const [phoneError, setPhoneError] = useState<string | null>(null);

  const { register, handleSubmit: hookFormSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(deliverySchema),
  });

    const validatePhoneNumber = (value: string) => {
    const result = deliverySchema.safeParse({ phoneNumber: value });
    if (!result.success) {
      setPhoneError(result.error.errors[0].message);
    } else {
      setPhoneError(null);
    }
    setRecipientData({...recipientData, phoneNumber: value});
  };


  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

     if (deliveryType === "SOMEONEELSE") {
      const validation = deliverySchema.safeParse({
        phoneNumber: recipientData.phoneNumber
      });
      
      if (!validation.success) {
        toast.error("Please fix phone number errors");
        setPhoneError(validation.error.errors[0].message);
        return;
      }
    }


    dispatch(handleSaveDeliveryAddress({
      ...formData,
      orderForOthers,
      recipient: deliveryType === "SOMEONEELSE" ? recipientData : null
    }))

    toast.success("Delivery details saved");

    if (onSubmit) {
      onSubmit();
    }
  };

  // console.log(delivery)

  useEffect(() => {
    if (deliveryAddress) {
      setFormData((prevState) => ({
        ...prevState,
        ...delivery, // Merge Redux address into local formData
      }));
    }
  }, [deliveryAddress]);


  return (
    <Card className="p-6 max-w-xl mx-auto bg-white/50 backdrop-blur-sm shadow-lg">
      <div className={'flex items-center gap-4 justify-between mb-4'}>
        <div className="flex items-center gap-2 ">
          <MapPin className="w-5 h-5 text-[#6E59A5]" />
          <h3 className="text-xl font-semibold text-[#1A1F2C]">Delivery Details</h3>
        </div>
        {/*<div className="flex col-span-2 items-center space-x-2 pt-4 border-t border-gray-100">*/}
        {/*  <Label htmlFor="order-for-others" className={`font-medium flex items-center gap-2 ${orderForOthers ? "" : "text-[#6E59A5]"}`}>*/}
        {/*    Myself*/}
        {/*  </Label>*/}
        {/*  <Switch*/}
        {/*      id="order-for-others"*/}
        {/*      checked={orderForOthers}*/}
        {/*      onCheckedChange={setOrderForOthers}*/}
        {/*  />*/}
        {/*  <Label htmlFor="order-for-others" className={`font-medium flex items-center gap-2 ${!orderForOthers ? '' : "text-[#6E59A5]"}`}>*/}
        {/*    <UserPlus size={16} className={`${!orderForOthers ? '' : "text-[#6E59A5]"} font-medium`}/>*/}
        {/*    Order for someone else*/}
        {/*  </Label>*/}
        {/*</div>*/}
        {/*<div className="flex items-center gap-2">*/}
        {/*  <input*/}
        {/*      type="checkbox"*/}
        {/*      id="orderingForSomeoneElse"*/}
        {/*      className="w-4 h-4 accent-[#6E59A5]"*/}
        {/*      checked={orderForOthers}*/}
        {/*      onChange={(e) => setOrderForOthers(e.target.checked)}*/}
        {/*  />*/}
        {/*  <Label htmlFor="order-for-others" className="font-medium flex items-center gap-2">*/}
        {/*    <UserPlus size={16} className="text-[#6E59A5]"/>*/}
        {/*    Order for someone else*/}
        {/*  </Label>*/}
        {/*</div>*/}

      </div>

      <RadioGroup value={deliveryType} onValueChange={(value) => setDeliveryType(value as DeliveryType)}
        className="space-y-4">

        <div
          className={`p-3 rounded-md border ${deliveryType === "MYSELF" ? "border-[#6E59A5]" : "border-gray-200"} bg-gray-50`}>
          <div className="flex items-center space-x-2 p-3 rounded-md">
            <RadioGroupItem value="MYSELF" id="MYSELF" />
            <Label htmlFor="MYSELF" className="flex-1 cursor-pointer">
              <div className="font-medium">Order for Myself</div>
              <div className="text-gray-500 text-sm">
                When you order for yourself, the Smart Bin is registered in your name and delivered directly to your
                home address.
              </div>
            </Label>
          </div>

          {deliveryType === "MYSELF" && (
            <form onSubmit={handleSubmit} className="space-y-4 py-4">

              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">Street Address</label>
                <Input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Enter your street address"
                  required
                  className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">

                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700">Local Government</label>
                  <Select onValueChange={(value) => setFormData({ ...formData, city: value })}
                    value={formData.city}>
                    <SelectTrigger className="w-full pl-10">
                      <SelectValue placeholder="Select LGA in Lagos" />
                    </SelectTrigger>
                    <SelectContent>
                      {/* Manually adding Lagos LGAs */}
                      <SelectItem value="Agege">Agege</SelectItem>
                      <SelectItem value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</SelectItem>
                      <SelectItem value="Alimosho">Alimosho</SelectItem>
                      <SelectItem value="Amuwo-Odofin">Amuwo-Odofin</SelectItem>
                      <SelectItem value="Apapa">Apapa</SelectItem>
                      <SelectItem value="Badagry">Badagry</SelectItem>
                      <SelectItem value="Epe">Epe</SelectItem>
                      <SelectItem value="Eti-Osa">Eti-Osa</SelectItem>
                      <SelectItem value="Ibeju-Lekki">Ibeju-Lekki</SelectItem>
                      <SelectItem value="Ifako-Ijaiye">Ifako-Ijaiye</SelectItem>
                      <SelectItem value="Ikeja">Ikeja</SelectItem>
                      <SelectItem value="Ikorodu">Ikorodu</SelectItem>
                      <SelectItem value="Kosofe">Kosofe</SelectItem>
                      <SelectItem value="Lagos Island">Lagos Island</SelectItem>
                      <SelectItem value="Lagos Mainland">Lagos Mainland</SelectItem>
                      <SelectItem value="Mushin">Mushin</SelectItem>
                      <SelectItem value="Ojo">Ojo</SelectItem>
                      <SelectItem value="Oshodi-Isolo">Oshodi-Isolo</SelectItem>
                      <SelectItem value="Shomolu">Shomolu</SelectItem>
                      <SelectItem value="Surulere">Surulere</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700">Postal Code</label>
                  <Input
                    type="text"
                    value={formData.postalCode}
                    onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                    placeholder="Enter postal code"
                    required
                    maxLength={6}
                    className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"
                  />
                </div>
              </div>

              {/*<div className="flex items-center space-x-2 pt-4 border-t border-gray-100">*/}
              {/*  <Switch*/}
              {/*      id="order-for-others"*/}
              {/*      checked={orderForOthers}*/}
              {/*      onCheckedChange={setOrderForOthers}*/}
              {/*  />*/}
              {/*  <Label htmlFor="order-for-others" className="font-medium flex items-center gap-2">*/}
              {/*    <UserPlus size={16} className="text-[#6E59A5]"/>*/}
              {/*    Order for someone else*/}
              {/*  </Label>*/}
              {/*</div>*/}

              {/*{orderForOthers && (*/}
              {/*    <div*/}
              {/*        className="rounded-md border border-dashed border-[#6E59A5]/50 p-4 bg-[#6E59A5]/5 space-y-4 mt-2">*/}
              {/*      <div className="flex items-center gap-2 mb-2">*/}
              {/*        <User className="w-4 h-4 text-[#6E59A5]"/>*/}
              {/*        <h4 className="font-medium text-[#1A1F2C]">Recipient Information</h4>*/}
              {/*      </div>*/}

              {/*      <div>*/}
              {/*        <label className="block text-sm font-medium mb-1 text-gray-700">Full Name</label>*/}
              {/*        <Input*/}
              {/*            type="text"*/}
              {/*            value={recipientData.fullName}*/}
              {/*            onChange={(e) => setRecipientData({...recipientData, fullName: e.target.value})}*/}
              {/*            placeholder="Enter recipient's full name"*/}
              {/*            required={orderForOthers}*/}
              {/*            className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
              {/*        />*/}
              {/*      </div>*/}

              {/*      <div>*/}
              {/*        <label className="block text-sm font-medium mb-1 text-gray-700">Phone Number</label>*/}
              {/*        <Input*/}
              {/*            type="tel"*/}
              {/*            value={recipientData.phoneNumber}*/}
              {/*            onChange={(e) => setRecipientData({...recipientData, phoneNumber: e.target.value})}*/}
              {/*            placeholder="Enter recipient's phone number"*/}
              {/*            required={orderForOthers}*/}
              {/*            className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
              {/*        />*/}
              {/*      </div>*/}
              {/*    </div>*/}
              {/*)}*/}

              <Button type="submit" className="w-full mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90">
                Save Delivery Details
              </Button>
            </form>

          )}

        </div>

        <div
          className={`p-3 rounded-md border ${deliveryType === "SOMEONEELSE" ? "border-[#6E59A5]" : "border-gray-200"} bg-gray-50`}>
          <div className="flex items-center space-x-2 p-3">
            <RadioGroupItem value="SOMEONEELSE" id="SOMEONEELSE" />
            <Label htmlFor="SOMEONEELSE" className="flex-1 cursor-pointer">
              <div className="font-medium">Order for Someone Else</div>
              <div className="text-gray-500 text-sm">
                When you order for someone else, the Smart Bin is registered in their name and delivered to their
                address. They’ll receive the bin, while you take care of the purchase.
              </div>
            </Label>
          </div>

          {deliveryType === "SOMEONEELSE" && (
            <form onSubmit={handleSubmit} className="space-y-4 py-4">

              <div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700">Full Name</label>
                  <Input
                    type="text"
                    value={recipientData.fullName}
                    onChange={(e) => setRecipientData({ ...recipientData, fullName: e.target.value })}
                    placeholder="Enter recipient's full name"
                    required={orderForOthers}
                    className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700">Phone Number</label>
                   <Input
                    type="tel"
                    maxLength={11}
                    value={recipientData.phoneNumber}
                    onChange={(e) => validatePhoneNumber(e.target.value)}
                    placeholder="Enter recipient's phone number"
                    className={`border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5] ${phoneError ? "border-red-500" : ""
                      }`}
                  />
                  {phoneError && (
                    <p className="text-red-500 text-xs mt-1">{phoneError}</p>
                  )}

                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1 text-gray-700">Street Address</label>
                <Input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  placeholder="Enter your street address"
                  required
                  className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">

                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700">Local Government</label>
                  <Select onValueChange={(value) => setFormData({ ...formData, city: value })}
                    value={formData.city}>
                    <SelectTrigger className="w-full pl-10">
                      <SelectValue placeholder="Select LGA in Lagos" />
                    </SelectTrigger>
                    <SelectContent>
                      {/* Manually adding Lagos LGAs */}
                      <SelectItem value="Agege">Agege</SelectItem>
                      <SelectItem value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</SelectItem>
                      <SelectItem value="Alimosho">Alimosho</SelectItem>
                      <SelectItem value="Amuwo-Odofin">Amuwo-Odofin</SelectItem>
                      <SelectItem value="Apapa">Apapa</SelectItem>
                      <SelectItem value="Badagry">Badagry</SelectItem>
                      <SelectItem value="Epe">Epe</SelectItem>
                      <SelectItem value="Eti-Osa">Eti-Osa</SelectItem>
                      <SelectItem value="Ibeju-Lekki">Ibeju-Lekki</SelectItem>
                      <SelectItem value="Ifako-Ijaiye">Ifako-Ijaiye</SelectItem>
                      <SelectItem value="Ikeja">Ikeja</SelectItem>
                      <SelectItem value="Ikorodu">Ikorodu</SelectItem>
                      <SelectItem value="Kosofe">Kosofe</SelectItem>
                      <SelectItem value="Lagos Island">Lagos Island</SelectItem>
                      <SelectItem value="Lagos Mainland">Lagos Mainland</SelectItem>
                      <SelectItem value="Mushin">Mushin</SelectItem>
                      <SelectItem value="Ojo">Ojo</SelectItem>
                      <SelectItem value="Oshodi-Isolo">Oshodi-Isolo</SelectItem>
                      <SelectItem value="Shomolu">Shomolu</SelectItem>
                      <SelectItem value="Surulere">Surulere</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1 text-gray-700">Postal Code</label>
                  <Input
                    type="text"
                    value={formData.postalCode}
                    onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                    placeholder="Enter postal code"
                    required
                    maxLength={6}
                    className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"
                  />
                </div>
              </div>

              {/*<div className="flex items-center space-x-2 pt-4 border-t border-gray-100">*/}
              {/*  <Switch*/}
              {/*      id="order-for-others"*/}
              {/*      checked={orderForOthers}*/}
              {/*      onCheckedChange={setOrderForOthers}*/}
              {/*  />*/}
              {/*  <Label htmlFor="order-for-others" className="font-medium flex items-center gap-2">*/}
              {/*    <UserPlus size={16} className="text-[#6E59A5]"/>*/}
              {/*    Order for someone else*/}
              {/*  </Label>*/}
              {/*</div>*/}

              {/*{orderForOthers && (*/}
              {/*    <div*/}
              {/*        className="rounded-md border border-dashed border-[#6E59A5]/50 p-4 bg-[#6E59A5]/5 space-y-4 mt-2">*/}
              {/*      <div className="flex items-center gap-2 mb-2">*/}
              {/*        <User className="w-4 h-4 text-[#6E59A5]"/>*/}
              {/*        <h4 className="font-medium text-[#1A1F2C]">Recipient Information</h4>*/}
              {/*      </div>*/}

              {/*      <div>*/}
              {/*        <label className="block text-sm font-medium mb-1 text-gray-700">Full Name</label>*/}
              {/*        <Input*/}
              {/*            type="text"*/}
              {/*            value={recipientData.fullName}*/}
              {/*            onChange={(e) => setRecipientData({...recipientData, fullName: e.target.value})}*/}
              {/*            placeholder="Enter recipient's full name"*/}
              {/*            required={orderForOthers}*/}
              {/*            className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
              {/*        />*/}
              {/*      </div>*/}

              {/*      <div>*/}
              {/*        <label className="block text-sm font-medium mb-1 text-gray-700">Phone Number</label>*/}
              {/*        <Input*/}
              {/*            type="tel"*/}
              {/*            value={recipientData.phoneNumber}*/}
              {/*            onChange={(e) => setRecipientData({...recipientData, phoneNumber: e.target.value})}*/}
              {/*            placeholder="Enter recipient's phone number"*/}
              {/*            required={orderForOthers}*/}
              {/*            className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
              {/*        />*/}
              {/*      </div>*/}
              {/*    </div>*/}
              {/*)}*/}

              <Button type="submit" className="w-full mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90">
                Save Delivery Details
              </Button>
            </form>

          )}

        </div>
      </RadioGroup>


      {/*{*/}
      {/*  user.savedDispatchDetails.length > 0 ? (*/}
      {/*      <div>*/}
      {/*        <label className="block text-sm font-medium mb-1 text-gray-700">Select Address</label>*/}
      {/*        <div className={'flex gap-2'}>*/}
      {/*          <Card*/}
      {/*              className={'p-6 max-w-xl mx-auto flex flex-col items-center gap-y-5 justify-center backdrop-blur-sm shadow-lg'}>*/}
      {/*            <PlusIcon className="w-5 h-5 text-[#6E59A5]"/>*/}
      {/*            <p>Add New Address</p>*/}
      {/*          </Card>*/}
      {/*          <Card*/}
      {/*              className={'p-6 max-w-xl mx-auto flex flex-col items-center gap-y-5 justify-center backdrop-blur-sm shadow-lg'}>*/}
      {/*            <BookmarkCheck*/}
      {/*                className="w-5 h-5 text-[#6E59A5]"/>*/}
      {/*            <p>Saved Address</p>*/}
      {/*          </Card>*/}
      {/*        </div>*/}
      {/*      </div>*/}
      {/*       ) : (*/}
      {/*          <div>*/}
      {/*            {*/}
      {/*              addressType === 'savedaddress' ?*/}
      {/*                <form onSubmit={handleSubmit} className="space-y-4">*/}
      {/*                  <div>*/}
      {/*                    <label className="block text-sm font-medium mb-1 text-gray-700">Local Government</label>*/}
      {/*                    <Select onValueChange={(value) => setFormData({...formData, city: value})}*/}
      {/*                    defaultValue={formData.city}>*/}
      {/*                      <SelectTrigger className="w-full pl-10">*/}
      {/*                        <SelectValue placeholder="Select LGA in Lagos"/>*/}
      {/*                      </SelectTrigger>*/}
      {/*                      <SelectContent>*/}
      {/*                      /!* Manually adding Lagos LGAs *!/*/}
      {/*                      <SelectItem value="Agege">Agege</SelectItem>*/}
      {/*                      <SelectItem value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</SelectItem>*/}
      {/*                      <SelectItem value="Alimosho">Alimosho</SelectItem>*/}
      {/*                      <SelectItem value="Amuwo-Odofin">Amuwo-Odofin</SelectItem>*/}
      {/*                      <SelectItem value="Apapa">Apapa</SelectItem>*/}
      {/*                      <SelectItem value="Badagry">Badagry</SelectItem>*/}
      {/*                      <SelectItem value="Epe">Epe</SelectItem>*/}
      {/*                      <SelectItem value="Eti-Osa">Eti-Osa</SelectItem>*/}
      {/*                      <SelectItem value="Ibeju-Lekki">Ibeju-Lekki</SelectItem>*/}
      {/*                      <SelectItem value="Ifako-Ijaiye">Ifako-Ijaiye</SelectItem>*/}
      {/*                      <SelectItem value="Ikeja">Ikeja</SelectItem>*/}
      {/*                      <SelectItem value="Ikorodu">Ikorodu</SelectItem>*/}
      {/*                      <SelectItem value="Kosofe">Kosofe</SelectItem>*/}
      {/*                      <SelectItem value="Lagos Island">Lagos Island</SelectItem>*/}
      {/*                      <SelectItem value="Lagos Mainland">Lagos Mainland</SelectItem>*/}
      {/*                      <SelectItem value="Mushin">Mushin</SelectItem>*/}
      {/*                      <SelectItem value="Ojo">Ojo</SelectItem>*/}
      {/*                      <SelectItem value="Oshodi-Isolo">Oshodi-Isolo</SelectItem>*/}
      {/*                      <SelectItem value="Shomolu">Shomolu</SelectItem>*/}
      {/*                      <SelectItem value="Surulere">Surulere</SelectItem>*/}
      {/*                    </SelectContent>*/}
      {/*                    </Select>*/}
      {/*                  </div>*/}
      {/*                </form> :*/}
      {/*                <form onSubmit={handleSubmit} className="space-y-4">*/}
      {/*                  <div>*/}
      {/*                    <label className="block text-sm font-medium mb-1 text-gray-700">Street Address</label>*/}
      {/*                    <Input*/}
      {/*                        type="text"*/}
      {/*                        value={formData.address}*/}
      {/*                        onChange={(e) => setFormData({...formData, address: e.target.value})}*/}
      {/*                        placeholder="Enter your street address"*/}
      {/*                        required*/}
      {/*                        className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*                    />*/}
      {/*                  </div>*/}

      {/*                  <div className="grid grid-cols-2 gap-4">*/}
      {/*                    <div>*/}
      {/*                      <label className="block text-sm font-medium mb-1 text-gray-700">Local Government</label>*/}
      {/*                      <Select onValueChange={(value) => setFormData({...formData, city: value})}*/}
      {/*                              defaultValue={formData.city}>*/}
      {/*                        <SelectTrigger className="w-full pl-10">*/}
      {/*                          <SelectValue placeholder="Select LGA in Lagos"/>*/}
      {/*                        </SelectTrigger>*/}
      {/*                        <SelectContent>*/}
      {/*                          /!* Manually adding Lagos LGAs *!/*/}
      {/*                          <SelectItem value="Agege">Agege</SelectItem>*/}
      {/*                          <SelectItem value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</SelectItem>*/}
      {/*                          <SelectItem value="Alimosho">Alimosho</SelectItem>*/}
      {/*                          <SelectItem value="Amuwo-Odofin">Amuwo-Odofin</SelectItem>*/}
      {/*                          <SelectItem value="Apapa">Apapa</SelectItem>*/}
      {/*                          <SelectItem value="Badagry">Badagry</SelectItem>*/}
      {/*                          <SelectItem value="Epe">Epe</SelectItem>*/}
      {/*                          <SelectItem value="Eti-Osa">Eti-Osa</SelectItem>*/}
      {/*                          <SelectItem value="Ibeju-Lekki">Ibeju-Lekki</SelectItem>*/}
      {/*                          <SelectItem value="Ifako-Ijaiye">Ifako-Ijaiye</SelectItem>*/}
      {/*                          <SelectItem value="Ikeja">Ikeja</SelectItem>*/}
      {/*                          <SelectItem value="Ikorodu">Ikorodu</SelectItem>*/}
      {/*                          <SelectItem value="Kosofe">Kosofe</SelectItem>*/}
      {/*                          <SelectItem value="Lagos Island">Lagos Island</SelectItem>*/}
      {/*                          <SelectItem value="Lagos Mainland">Lagos Mainland</SelectItem>*/}
      {/*                          <SelectItem value="Mushin">Mushin</SelectItem>*/}
      {/*                          <SelectItem value="Ojo">Ojo</SelectItem>*/}
      {/*                          <SelectItem value="Oshodi-Isolo">Oshodi-Isolo</SelectItem>*/}
      {/*                          <SelectItem value="Shomolu">Shomolu</SelectItem>*/}
      {/*                          <SelectItem value="Surulere">Surulere</SelectItem>*/}
      {/*                        </SelectContent>*/}
      {/*                      </Select>*/}
      {/*                    </div>*/}
      {/*                    <div>*/}
      {/*                      <label className="block text-sm font-medium mb-1 text-gray-700">Postal Code</label>*/}
      {/*                      <Input*/}
      {/*                          type="text"*/}
      {/*                          value={formData.postalCode}*/}
      {/*                          onChange={(e) => setFormData({...formData, postalCode: e.target.value})}*/}
      {/*                          placeholder="Enter postal code"*/}
      {/*                          required*/}
      {/*                          maxLength={6}*/}
      {/*                          className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*                      />*/}
      {/*                    </div>*/}
      {/*                  </div>*/}

      {/*                  <div className="flex items-center space-x-2 pt-4 border-t border-gray-100">*/}
      {/*                    <Switch*/}
      {/*                        id="order-for-others"*/}
      {/*                        checked={orderForOthers}*/}
      {/*                        onCheckedChange={setOrderForOthers}*/}
      {/*                    />*/}
      {/*                    <Label htmlFor="order-for-others" className="font-medium flex items-center gap-2">*/}
      {/*                      <UserPlus size={16} className="text-[#6E59A5]"/>*/}
      {/*                      Order for someone else*/}
      {/*                    </Label>*/}
      {/*                  </div>*/}

      {/*                  {orderForOthers && (*/}
      {/*                      <div*/}
      {/*                          className="rounded-md border border-dashed border-[#6E59A5]/50 p-4 bg-[#6E59A5]/5 space-y-4 mt-2">*/}
      {/*                        <div className="flex items-center gap-2 mb-2">*/}
      {/*                          <User className="w-4 h-4 text-[#6E59A5]"/>*/}
      {/*                          <h4 className="font-medium text-[#1A1F2C]">Recipient Information</h4>*/}
      {/*                        </div>*/}

      {/*                        <div>*/}
      {/*                          <label className="block text-sm font-medium mb-1 text-gray-700">Full Name</label>*/}
      {/*                          <Input*/}
      {/*                              type="text"*/}
      {/*                              value={recipientData.fullName}*/}
      {/*                              onChange={(e) => setRecipientData({...recipientData, fullName: e.target.value})}*/}
      {/*                              placeholder="Enter recipient's full name"*/}
      {/*                              required={orderForOthers}*/}
      {/*                              className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*                          />*/}
      {/*                        </div>*/}

      {/*                        <div>*/}
      {/*                          <label className="block text-sm font-medium mb-1 text-gray-700">Phone Number</label>*/}
      {/*                          <Input*/}
      {/*                              type="tel"*/}
      {/*                              value={recipientData.phoneNumber}*/}
      {/*                              onChange={(e) => setRecipientData({...recipientData, phoneNumber: e.target.value})}*/}
      {/*                              placeholder="Enter recipient's phone number"*/}
      {/*                              required={orderForOthers}*/}
      {/*                              className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*                          />*/}
      {/*                        </div>*/}
      {/*                      </div>*/}
      {/*                  )}*/}

      {/*                  <Button type="submit" className="w-full mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90">*/}
      {/*                    Save Delivery Details*/}
      {/*                  </Button>*/}
      {/*                </form>*/}

      {/*            }*/}

      {/*          </div>*/}
      {/*  )*/}
      {/*}*/}


      {/*<form onSubmit={handleSubmit} className="space-y-4">*/}
      {/*  {orderForOthers && (*/}
      {/*      <div>*/}
      {/*        <div>*/}
      {/*          <label className="block text-sm font-medium mb-1 text-gray-700">Full Name</label>*/}
      {/*          <Input*/}
      {/*              type="text"*/}
      {/*              value={recipientData.fullName}*/}
      {/*              onChange={(e) => setRecipientData({...recipientData, fullName: e.target.value})}*/}
      {/*              placeholder="Enter recipient's full name"*/}
      {/*              required={orderForOthers}*/}
      {/*              className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*          />*/}
      {/*        </div>*/}

      {/*        <div>*/}
      {/*          <label className="block text-sm font-medium mb-1 text-gray-700">Phone Number</label>*/}
      {/*          <Input*/}
      {/*              type="tel"*/}
      {/*              value={recipientData.phoneNumber}*/}
      {/*              onChange={(e) => setRecipientData({...recipientData, phoneNumber: e.target.value})}*/}
      {/*              placeholder="Enter recipient's phone number"*/}
      {/*              required={orderForOthers}*/}
      {/*              className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*          />*/}
      {/*        </div>*/}
      {/*      </div>*/}
      {/*  )}*/}
      {/*  <div>*/}
      {/*    <label className="block text-sm font-medium mb-1 text-gray-700">Street Address</label>*/}
      {/*    <Input*/}
      {/*        type="text"*/}
      {/*        value={formData.address}*/}
      {/*        onChange={(e) => setFormData({...formData, address: e.target.value})}*/}
      {/*        placeholder="Enter your street address"*/}
      {/*        required*/}
      {/*        className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*    />*/}
      {/*  </div>*/}
      {/*  <div className="grid grid-cols-2 gap-4">*/}

      {/*    <div>*/}
      {/*      <label className="block text-sm font-medium mb-1 text-gray-700">Local Government</label>*/}
      {/*      <Select onValueChange={(value) => setFormData({...formData, city: value})}*/}
      {/*              value={formData.city}>*/}
      {/*        <SelectTrigger className="w-full pl-10">*/}
      {/*          <SelectValue placeholder="Select LGA in Lagos"/>*/}
      {/*        </SelectTrigger>*/}
      {/*        <SelectContent>*/}
      {/*          /!* Manually adding Lagos LGAs *!/*/}
      {/*          <SelectItem value="Agege">Agege</SelectItem>*/}
      {/*          <SelectItem value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</SelectItem>*/}
      {/*          <SelectItem value="Alimosho">Alimosho</SelectItem>*/}
      {/*          <SelectItem value="Amuwo-Odofin">Amuwo-Odofin</SelectItem>*/}
      {/*          <SelectItem value="Apapa">Apapa</SelectItem>*/}
      {/*          <SelectItem value="Badagry">Badagry</SelectItem>*/}
      {/*          <SelectItem value="Epe">Epe</SelectItem>*/}
      {/*          <SelectItem value="Eti-Osa">Eti-Osa</SelectItem>*/}
      {/*          <SelectItem value="Ibeju-Lekki">Ibeju-Lekki</SelectItem>*/}
      {/*          <SelectItem value="Ifako-Ijaiye">Ifako-Ijaiye</SelectItem>*/}
      {/*          <SelectItem value="Ikeja">Ikeja</SelectItem>*/}
      {/*          <SelectItem value="Ikorodu">Ikorodu</SelectItem>*/}
      {/*          <SelectItem value="Kosofe">Kosofe</SelectItem>*/}
      {/*          <SelectItem value="Lagos Island">Lagos Island</SelectItem>*/}
      {/*          <SelectItem value="Lagos Mainland">Lagos Mainland</SelectItem>*/}
      {/*          <SelectItem value="Mushin">Mushin</SelectItem>*/}
      {/*          <SelectItem value="Ojo">Ojo</SelectItem>*/}
      {/*          <SelectItem value="Oshodi-Isolo">Oshodi-Isolo</SelectItem>*/}
      {/*          <SelectItem value="Shomolu">Shomolu</SelectItem>*/}
      {/*          <SelectItem value="Surulere">Surulere</SelectItem>*/}
      {/*        </SelectContent>*/}
      {/*      </Select>*/}
      {/*    </div>*/}
      {/*    <div>*/}
      {/*      <label className="block text-sm font-medium mb-1 text-gray-700">Postal Code</label>*/}
      {/*      <Input*/}
      {/*          type="text"*/}
      {/*          value={formData.postalCode}*/}
      {/*          onChange={(e) => setFormData({...formData, postalCode: e.target.value})}*/}
      {/*          placeholder="Enter postal code"*/}
      {/*          required*/}
      {/*          maxLength={6}*/}
      {/*          className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*/}
      {/*      />*/}
      {/*    </div>*/}
      {/*  </div>*/}

      {/*  /!*<div className="flex items-center space-x-2 pt-4 border-t border-gray-100">*!/*/}
      {/*  /!*  <Switch*!/*/}
      {/*  /!*      id="order-for-others"*!/*/}
      {/*  /!*      checked={orderForOthers}*!/*/}
      {/*  /!*      onCheckedChange={setOrderForOthers}*!/*/}
      {/*  /!*  />*!/*/}
      {/*  /!*  <Label htmlFor="order-for-others" className="font-medium flex items-center gap-2">*!/*/}
      {/*  /!*    <UserPlus size={16} className="text-[#6E59A5]"/>*!/*/}
      {/*  /!*    Order for someone else*!/*/}
      {/*  /!*  </Label>*!/*/}
      {/*  /!*</div>*!/*/}

      {/*  /!*{orderForOthers && (*!/*/}
      {/*  /!*    <div*!/*/}
      {/*  /!*        className="rounded-md border border-dashed border-[#6E59A5]/50 p-4 bg-[#6E59A5]/5 space-y-4 mt-2">*!/*/}
      {/*  /!*      <div className="flex items-center gap-2 mb-2">*!/*/}
      {/*  /!*        <User className="w-4 h-4 text-[#6E59A5]"/>*!/*/}
      {/*  /!*        <h4 className="font-medium text-[#1A1F2C]">Recipient Information</h4>*!/*/}
      {/*  /!*      </div>*!/*/}

      {/*  /!*      <div>*!/*/}
      {/*  /!*        <label className="block text-sm font-medium mb-1 text-gray-700">Full Name</label>*!/*/}
      {/*  /!*        <Input*!/*/}
      {/*  /!*            type="text"*!/*/}
      {/*  /!*            value={recipientData.fullName}*!/*/}
      {/*  /!*            onChange={(e) => setRecipientData({...recipientData, fullName: e.target.value})}*!/*/}
      {/*  /!*            placeholder="Enter recipient's full name"*!/*/}
      {/*  /!*            required={orderForOthers}*!/*/}
      {/*  /!*            className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*!/*/}
      {/*  /!*        />*!/*/}
      {/*  /!*      </div>*!/*/}

      {/*  /!*      <div>*!/*/}
      {/*  /!*        <label className="block text-sm font-medium mb-1 text-gray-700">Phone Number</label>*!/*/}
      {/*  /!*        <Input*!/*/}
      {/*  /!*            type="tel"*!/*/}
      {/*  /!*            value={recipientData.phoneNumber}*!/*/}
      {/*  /!*            onChange={(e) => setRecipientData({...recipientData, phoneNumber: e.target.value})}*!/*/}
      {/*  /!*            placeholder="Enter recipient's phone number"*!/*/}
      {/*  /!*            required={orderForOthers}*!/*/}
      {/*  /!*            className="border-gray-200 focus:border-[#6E59A5] focus:ring-[#6E59A5]"*!/*/}
      {/*  /!*        />*!/*/}
      {/*  /!*      </div>*!/*/}
      {/*  /!*    </div>*!/*/}
      {/*  /!*)}*!/*/}

      {/*  <Button type="submit" className="w-full mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90">*/}
      {/*    Save Delivery Details*/}
      {/*  </Button>*/}
      {/*</form>*/}

    </Card>
  );
};

export default DeliveryForm;
