
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Minus } from "lucide-react";
import { PRODUCTS } from "@/config/products";
import type { OrderItem } from "@/types/product";
import { useDispatch, useSelector } from "react-redux";
import { addOrder, handleSelectedColor } from "@/services/constant/actions.ts";
import { RootState } from "@/services/reducers/rootReducer.ts";
import { Auth } from "@/services/constant/actionTypes.ts";

interface ProductSelectorProps {
  onProductSelect: (items: OrderItem[]) => void;
}

export const ProductSelector = ({ onProductSelect }: ProductSelectorProps) => {
  const [quantities, setQuantities] = useState<Record<string, number>>({
    "single-bin-general": 0,
    "single-bin-recycle": 0
  });
  const OrderState = useSelector((state: RootState) => state.orders);
  const { color: storedColor, orders: storedItems } = OrderState;
  const [selectedColor, setSelectedColor] = useState<"green-general" | "blue-recycle">("green-general");
  const dispatch = useDispatch();
  // Get selected color from localStorage if available
  useEffect(() => {
    const initialQuantities: Record<string, number> = {};
    storedItems.forEach((item) => {
      initialQuantities[item.productId] = item.quantity;
    });


    // Set local quantities and color
    setQuantities(initialQuantities);

    if (storedColor && (storedColor === "green-general" || storedColor === "blue-recycle")) {
      setSelectedColor(storedColor as "green-general" | "blue-recycle");
    }
  }, []);

  const updateQuantity = (productId: string, delta: number) => {
    const newQuantity = Math.max(0, (quantities[productId] || 0) + delta);
    const newQuantities = { ...quantities, [productId]: newQuantity };
    setQuantities(newQuantities);

    const items: OrderItem[] = Object.entries(newQuantities)
      .filter(([_, qty]) => qty > 0)
      .map(([id, quantity]) => ({
        productId: id,
        quantity,
        color: id === 'single-bin-general' ? 'green-general' : 'blue-recycle' // Use the current selected color
      }));

    // Store the selected color in localStorage
    // localStorage.setItem("selectedBinColor", selectedColor);
    dispatch(handleSelectedColor(selectedColor))
    // Store the selected items in localStorage
    dispatch(addOrder(items))
    // localStorage.setItem("selectedItems", JSON.stringify(items));

    onProductSelect(items);
  };

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-lg font-medium mb-4">Select Your Bins</h2>
        <div className="space-y-4">
          {PRODUCTS.map((product) => (
            <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className={'flex items-center'}>
                <img
                  src={product.idType === "RECYCLABLES" ? '/lovable-uploads/assets/bluebin.png' : '/lovable-uploads/assets/greenbin.png'}
                  alt={product.idType === "RECYCLABLES" ? "Blue/Orange bin" : "Green/Orange bin"}
                  className="rounded-lg w-16 h-16 object-contain bg-white"
                />
                <div>
                  <h3 className="font-medium">{product.name}</h3>
                  <p className="text-sm text-gray-500">₦{product.price.toLocaleString()}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 product-controls">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => updateQuantity(product.id, -1)}
                  disabled={quantities[product.id] === 0}
                  className="decrement-button"
                  data-testid={`decrement-${product.id}`}
                >
                  <Minus className="h-4 w-4" />
                </Button>

                <Input
                  type="number"
                  value={quantities[product.id] || 0}
                  className="w-16 text-center quantity-input"
                  min={0}
                  readOnly
                />

                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => updateQuantity(product.id, 1)}
                  className="increment-button"
                  data-testid={`increment-${product.id}`} 
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
