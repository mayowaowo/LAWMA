import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import {format} from "date-fns";

interface OrderDetailsModalProps {
    order: {
        account_number: string;
        totalAmount: string;
        binPurchaseItems: [];
        bin_type: string;
        color: string;
        createdAt: string;
        dispatch_details: string;
        expectedAmount: string;
        id: number;
        orderReference: string;
        payment_period: string | null;
        payment_status: string;
        payment_type: string;
        receiver_details: string | null;
        remitted_totalAmount: string | null;
        status: string;
        store_dispatch_details: number;
        total_totalAmount: string;
        updated_at: string;
        user_id: number;
    };
    isOpen: boolean;
    onClose: () => void;
}

const OrderDetailsModal = ({order, isOpen, onClose}: OrderDetailsModalProps) => {
    const binPurchase: [] = order.binPurchaseItems
    // const dispatchDetails = JSON.parse(order.dispatch_details || "{}");

    const DetailColumn = ({label, value}: { label: string; value: React.ReactNode }) => (
        <div className="py-3 ">
            <span className="font-medium text-gray-500">{label}</span>
            <div className="col-span-2 text-sm pt-1">{value}</div>
        </div>
    );

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-[700px] max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Order Details</DialogTitle>
                </DialogHeader>

                <div className="space-y-6">
                    {/* Order Information */}
                    <div>
                        <h3 className="font-semibold mb-4">Order Information</h3>
                        <div className="grid grid-cols-3 space-y-0">
                            <DetailColumn label="Reference" value={order.orderReference}/>
                            <DetailColumn
                                label="Order Status"
                                value={
                                    <span className={`px-2 py-1 rounded-full text-sm ${
                                        order.status === 'COMPLETED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                                    }`}>
                                        {order.status}
                                    </span>
                                }
                            />
                            <DetailColumn
                                label="Created"
                                value={format(new Date(order.createdAt), 'PPp')}
                            />
                        </div>
                    </div>

                    {/* Payment Information */}
                    <div>
                        <h3 className="font-semibold mb-4">Payment Information</h3>
                        <div className="grid grid-cols-3 space-y-0">
                            <DetailColumn
                                label="Amount"
                                value={`₦${parseFloat(order.totalAmount).toLocaleString()}`}
                            />
                            <DetailColumn
                                label="Expected Amount"
                                value={`₦${parseFloat(order.expectedAmount).toLocaleString()}`}
                            />
                            {/*<DetailColumn*/}
                            {/*    label="Payment Status"*/}
                            {/*    value={*/}
                            {/*        <span className={`px-2 py-1 rounded-full text-sm ${*/}
                            {/*            order.payment_status === 'COMPLETED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'*/}
                            {/*        }`}>*/}
                            {/*            {order.payment_status}*/}
                            {/*        </span>*/}
                            {/*    }*/}
                            {/*/>*/}
                            <DetailColumn label="Payment Type" value={order.payment_type}/>
                        </div>
                    </div>

                    {/* Bin Details */}
                    <div>
                        <h3 className="font-semibold mb-4">Bin Details</h3>
                        <div className="grid grid-cols-3  space-y-0">
                            <DetailColumn label="Bin Type" value={order.bin_type}/>
                            {binPurchase.map((bin: { category: string; quantity: number }, index: number) => (
                                <DetailColumn
                                    key={index}
                                    label={`${bin.category} Bins`}
                                    value={`${bin.quantity} unit(s)`}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Dispatch Information */}
                    {/*<div>*/}
                    {/*    <h3 className="font-semibold mb-4">Dispatch Information</h3>*/}
                    {/*    <div className="grid grid-cols-3  space-y-0">*/}
                    {/*        <DetailColumn label="Address" value={dispatchDetails.dispatch_address}/>*/}
                    {/*        <DetailColumn label="City" value={dispatchDetails.dispatch_city}/>*/}
                    {/*        <DetailColumn label="Postal Code" value={dispatchDetails.dispatch_postal}/>*/}
                    {/*    </div>*/}
                    {/*</div>*/}
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default OrderDetailsModal;

