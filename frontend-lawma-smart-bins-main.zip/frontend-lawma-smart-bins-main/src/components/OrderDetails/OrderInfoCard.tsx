
import { Card, CardContent } from "@/components/ui/card";
import { UserPlus } from "lucide-react";
import {User} from "@/services/constant/actionTypes.ts";

interface DeliveryInfo {
  address: string;
  city: string;
  postalCode: string;
  orderForOthers: boolean;
  recipient: {
    fullName: string;
    phoneNumber: string;
  } | null;
}

interface UserInfo {
  fullName: string;
  phoneNumber: string;
  address: string;
  city: string;
  postalCode: string;
}

interface OrderInfoCardProps {
  userInfo: User;
  deliveryInfo: DeliveryInfo | null;
}

export const OrderInfoCard = ({ userInfo, deliveryInfo }: OrderInfoCardProps) => {
    return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-lg font-medium mb-4">Customer Information</h2>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Purchaser Name</p>
            <p className="font-medium">{userInfo.name}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Phone Number</p>
            <p className="font-medium">{userInfo.phone}</p>
          </div>

          {deliveryInfo?.orderForOthers && deliveryInfo.recipient && (
            <div className="md:col-span-2 border-t border-dashed border-gray-200 pt-4 mt-2">
              <div className="flex items-center gap-2 mb-3">
                <UserPlus size={16} className="text-[#6E59A5]" />
                <p className="font-medium text-[#6E59A5]">Recipient Information</p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Recipient Name</p>
                  <p className="font-medium">{deliveryInfo.recipient.fullName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Recipient Phone</p>
                  <p className="font-medium">{deliveryInfo.recipient.phoneNumber}</p>
                </div>
              </div>
            </div>
          )}

          <div className="md:col-span-2">
            <p className="text-sm text-gray-500">Delivery Address</p>
            <p className="font-medium">
              {deliveryInfo?.address || userInfo.address},
              {deliveryInfo?.city || userInfo.city},
              {deliveryInfo?.postalCode || userInfo.postalCode}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
