
import { Card, CardContent } from "@/components/ui/card";
import { Check } from "lucide-react";
import { PRODUCTS } from "@/config/products";
import type { OrderItem } from "@/types/product";

interface ProductDetailsCardProps {
  items: OrderItem[];
}

const binImages: Record<string, string> = {
  "blue-recycle": "/lovable-uploads/fb95c06e-0e53-40f8-a684-80d70ae366f0.png",
  "green-general": "/lovable-uploads/7f2d91da-eb64-49bd-ba08-d4c2e7f17b1a.png"
};

export const ProductDetailsCard = ({ items }: ProductDetailsCardProps) => {
  // Only include the allowed features (matches your latest 4 items)
  const sharedFeatures = [
    "10-year Warranty",
    "Geotagging Technology",
    "Smooth Rolling Wheels",
    "Withstand Harsh Weather Conditions"
  ];

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-lg font-medium mb-4">Product Details</h2>
        <div className="space-y-6">
          {items.map((item, index) => {
            const product = PRODUCTS.find(p => p.id === item.productId);
            if (!product) return null;

            // Get the correct image based on the item's color
            const imgUrl = binImages[item.color];
            
            return (
              <div key={index} className="flex flex-col md:flex-row gap-4 mb-4">
                <div className="flex flex-col items-center">
                  <img
                    src={imgUrl}
                    alt={item.color === "blue-recycle" ? "Blue/Orange bin" : "Green/Orange bin"}
                    className="rounded-lg w-32 h-32 object-contain bg-white"
                  />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">{product.name}</h3>
                  <p className="text-sm text-gray-500 mb-2">
                    Quantity: {item.quantity}
                  </p>
                  <p className="text-sm text-gray-500 mb-2">
                    Color: <span className="font-medium capitalize">{item.color.replace('-', ' ')}</span>
                  </p>
                  <ul className="mt-2 space-y-1 text-gray-600">
                    {sharedFeatures.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2">
                        <Check size={16} className="text-green-500" /> {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};
