
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CreditCard } from "lucide-react";
import { cn } from "@/lib/utils";

interface PaymentDetailsCardProps {
  paymentType: string;
  period: string;
  selectedColor: string;
  totalAmount: number;
  baseAmount: number;
  initialPayment: number;
  remainingBalance: number;
  monthlyPayment: number;
  loading: boolean;
  onVirtualAccountPayment: () => void;
}

export const PaymentDetailsCard = ({
  paymentType,
  period,
  selectedColor,
  totalAmount,
  baseAmount,
  initialPayment,
  remainingBalance,
  monthlyPayment,
  loading,
  onVirtualAccountPayment
}: PaymentDetailsCardProps) => {
  const paymentTypeText = paymentType === "ONEOFF" ? "Full Payment" : "Installment";
  const installmentDetails = paymentType === "INSTALLMENT" ? `(${period}-month plan)` : "";

  // Calculate discount
  const discountPercentage = paymentType === "ONEOFF" ? 0 : (period === "3" ? 0 : 0);
  const discountAmount = baseAmount * (discountPercentage / 100);

  // Calculate transaction fee (1.25%)
  const transactionFee = (baseAmount - discountAmount) * 0.0125;

  // Final amount after discount and transaction fee
  const finalAmount = baseAmount - discountAmount + transactionFee;

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-lg font-medium mb-4">Payment Details</h2>

        <div className="space-y-4">
          <div className="flex justify-between">
            <span>Base Amount:</span>
            <span>₦{baseAmount.toLocaleString()}</span>
          </div>

          {discountPercentage > 0 && (
            <div className="flex justify-between text-green-600">
              <span>Discount ({discountPercentage}%):</span>
              <span>-₦{discountAmount.toLocaleString()}</span>
            </div>
          )}

          <div className="flex justify-between text-gray-600">
            <span>Transaction Fee (1.25%):</span>
            <span>+₦{transactionFee.toLocaleString()}</span>
          </div>

          <div className="flex justify-between font-semibold border-t border-gray-200 pt-3">
            <span>Final Amount:</span>
            <span>₦{finalAmount.toLocaleString()}</span>
          </div>

          <div className="flex justify-between">
            <span>Payment Type:</span>
            <span>{paymentTypeText} {installmentDetails}</span>
          </div>

          {/*<div className="flex justify-between">*/}
          {/*  <span>Color Selected:</span>*/}
          {/*  <span className="capitalize">{selectedColor.replace('-', ' ')}</span>*/}
          {/*</div>*/}

          {paymentType === "INSTALLMENT" && (
            <>
              <div className="flex justify-between">
                <span>Initial Payment (25%):</span>
                <span>₦{initialPayment.toLocaleString()}</span>
              </div>

              <div className="flex justify-between">
                <span>Remaining Balance:</span>
                <span>₦{remainingBalance.toLocaleString()}</span>
              </div>

              <div className="flex justify-between">
                <span>Monthly Payment:</span>
                <span>₦{monthlyPayment.toLocaleString()}</span>
              </div>
            </>
          )}
        </div>

        <Button
          onClick={onVirtualAccountPayment}
          disabled={loading}
          className={cn(
            "w-full mt-6 bg-[#6E59A5] hover:bg-[#6E59A5]/90 flex items-center justify-center gap-2",
            loading && "cursor-not-allowed opacity-50"
          )}
        >
          <CreditCard className="h-4 w-4" />
          {loading ? 'Loading...' : 'Pay with Virtual Account'}
        </Button>

        {/*{paymentType === "INSTALLMENT" && (*/}
        {/*  <div className="mt-6 text-yellow-700 text-sm font-semibold border-t pt-3 border-yellow-200">*/}
        {/*    <span>*/}
        {/*      Bin will only be despatched once the final payment has been made.*/}
        {/*    </span>*/}
        {/*  </div>*/}
        {/*)}*/}
      </CardContent>
    </Card>
  );
};
