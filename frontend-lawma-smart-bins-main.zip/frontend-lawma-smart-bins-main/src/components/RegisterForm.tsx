
import { useState } from "react";
import {useNavigate} from "react-router-dom";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {User, Phone, Home, MapPin, Mail, Lock, UserCheck, Link, EyeOff, Eye} from "lucide-react";
import {Select, SelectTrigger, SelectContent, SelectItem, SelectValue} from "@/components/ui/select.tsx";
import {handleRegisterRequest} from "@/services/constant/actions.ts";
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from "@/services/reducers/rootReducer.ts";
import {Auth} from "@/services/constant/actionTypes.ts";
import OtpModal from "@/components/OtpModal.tsx";
import {postEmailVerification} from "@/services/api/services/authservices.ts";
import {emailVerification} from "@/services/api/hooks/Register.ts";

// export enum UserType {
//     USER = "user",
//     AGENT = "agent"
// }


const formSchema = z.object({
    type: z.enum(["USER", "AGENT"] as const),
    referral: z.string().optional(),
    fullname: z.string().min(2, "Full name must be at least 2 characters"),
    email: z.string().email("Invalid email address"),
    password: z
        .string()
        .min(8, "Password must be at least 8 characters")
        .max(100, "Password is too long")
        .regex(
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/,
            "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
        ),
    phone: z
        .string()
        .regex(/^\d+$/, "Phone number must contain only digits")
        .length(11, "Phone number must be exactly 11 digits")
        .transform((val) => val.replace(/\D/g, '')),
    address: z.string().min(5, "Address must be at least 5 characters"),
    city: z.string().min(2, "City must be at least 2 characters"),
    postal: z.string().min(6, "Postal code must be at least 6 characters").max(6, "Postal code can not be more than 6 characters"),
});

type FormValues = z.infer<typeof formSchema>;

const RegisterForm = () => {
    const dispatch = useDispatch();
    const [isOtpModalOpen, setIsOtpModalOpen] = useState(false)
    const [showPassword, setShowPassword] = useState(false);

    const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
    const [submitLoading, setSubmitLoading] = useState(false);

    const AuthState = useSelector((state: RootState) => state.auth as Auth);
    const UserState = useSelector((state: RootState) => state.user);
    const {user} = UserState;
    const {loading} = AuthState;
    const form = useForm<FormValues>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            type: "USER",
            referral: "",
            fullname: "",
            email: "",
            password: "",
            phone: "",
            address: "",
            city: "",
            postal: "",
        },
    });

  const onSubmit = (data: FormValues) => {
          setIsLoading(true);

      const registerData = {
          type: data.type,
          referral: data.referral || '',
          fullname: data.fullname,
          email: data.email,
          password: data.password,
          phone: data.phone,
          address: data.address,
          city: data.city,
          postal: data.postal,
          password_confirmation: data.password
      };

      dispatch(handleRegisterRequest({payload: registerData, navigate: navigate, onSuccess: () => setIsOtpModalOpen(true) }))
      setIsLoading(false);

  };

    const handleOtpSubmit = async (otp: string) => {
                setSubmitLoading(true)
        const payload = {
            uuid: user.uuid,
            otp: otp,
        }
        const res = await emailVerification(payload, navigate)
        if (res.success ) {
            setSubmitLoading(false)
            setIsOtpModalOpen(false)
        }
        setSubmitLoading(false)

    }

    return (
    <div className="min-h-screen bg-gradient-to-b from-[#F2FCE2] to-white py-10 px-4">
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Create Your Account</CardTitle>
          <CardDescription>
            Register to start your journey with smart waste management
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                  {/*<FormField*/}
                  {/*    control={form.control}*/}
                  {/*    name="type"*/}
                  {/*    render={({field}) => (*/}
                  {/*        <FormItem className={form.watch("type") !== "USER" ? "md:col-span-2" : ""}>*/}
                  {/*            <FormLabel>Choose Type</FormLabel>*/}
                  {/*            <div className="relative">*/}
                  {/*                <UserCheck*/}
                  {/*                className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>*/}
                  {/*                <FormControl>*/}
                  {/*                    <Select onValueChange={field.onChange} defaultValue={field.value}>*/}
                  {/*                        <SelectTrigger className="w-full pl-10">*/}
                  {/*                            <SelectValue placeholder="Select a role"/>*/}
                  {/*                        </SelectTrigger>*/}
                  {/*                        <SelectContent>*/}
                  {/*                            <SelectItem value="USER">User</SelectItem>*/}
                  {/*                            <SelectItem value="AGENT">Agent</SelectItem>*/}
                  {/*                        </SelectContent>*/}
                  {/*                    </Select>*/}
                  {/*                </FormControl>*/}
                  {/*            </div>*/}
                  {/*            <FormMessage/>*/}
                  {/*        </FormItem>*/}
                  {/*    )}*/}
                  {/*/>*/}



                      <FormField
                          control={form.control}
                          name="referral"
                          render={({field}) => (
                              <FormItem>
                                  <FormLabel>Referral Code</FormLabel>
                                  <div className="relative">
                                      <Link className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                      <FormControl>
                                          <Input placeholder="Enter referral code" {...field} className="pl-10"/>
                                      </FormControl>
                                  </div>
                                  <FormMessage/>
                              </FormItem>
                          )}
                      />



                <FormField
                  control={form.control}
                  name="fullname"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <div className="relative">
                        <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <FormControl>
                          <Input placeholder="John Doe" {...field} className="pl-10" />
                        </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <FormControl>
                          <Input type="email" placeholder="your@email.com" {...field} className="pl-10" />
                        </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                  <FormField
                      control={form.control}
                      name="password"
                      render={({field}) => (
                          <FormItem>
                              <FormLabel>Password</FormLabel>
                              <div className="relative">
                                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                  <FormControl>
                                      <Input
                                          type={showPassword ? "text" : "password"}
                                          {...field}
                                          className="pl-10 pr-10" // Added right padding for eye icon
                                      />
                                  </FormControl>
                                  <button
                                      type="button"
                                      onClick={() => setShowPassword(!showPassword)}
                                      className="absolute right-3 top-3 h-4 w-4 text-gray-400 cursor-pointer hover:text-gray-600"
                                  >
                                      {showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}
                                  </button>
                              </div>
                              <FormMessage/>
                          </FormItem>
                      )}
                  />

                  <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <div className="relative">
                        <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <FormControl>
                          <Input placeholder="+234 800 000 0000" {...field} className="pl-10" />
                        </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem className="md:col-span-1">
                      <FormLabel>Address</FormLabel>
                      <div className="relative">
                        <Home className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <FormControl>
                          <Input placeholder="123 Main St" {...field} className="pl-10" />
                        </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="city"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Local Government</FormLabel>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                          <FormControl>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                  <SelectTrigger className="w-full pl-10">
                                      <SelectValue placeholder="Select LGA in Lagos"/>
                                  </SelectTrigger>
                                  <SelectContent>
                                      {/* Manually adding Lagos LGAs */}
                                      <SelectItem value="Agege">Agege</SelectItem>
                                      <SelectItem value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</SelectItem>
                                      <SelectItem value="Alimosho">Alimosho</SelectItem>
                                      <SelectItem value="Amuwo-Odofin">Amuwo-Odofin</SelectItem>
                                      <SelectItem value="Apapa">Apapa</SelectItem>
                                      <SelectItem value="Badagry">Badagry</SelectItem>
                                      <SelectItem value="Epe">Epe</SelectItem>
                                      <SelectItem value="Eti-Osa">Eti-Osa</SelectItem>
                                      <SelectItem value="Ibeju-Lekki">Ibeju-Lekki</SelectItem>
                                      <SelectItem value="Ifako-Ijaiye">Ifako-Ijaiye</SelectItem>
                                      <SelectItem value="Ikeja">Ikeja</SelectItem>
                                      <SelectItem value="Ikorodu">Ikorodu</SelectItem>
                                      <SelectItem value="Kosofe">Kosofe</SelectItem>
                                      <SelectItem value="Lagos Island">Lagos Island</SelectItem>
                                      <SelectItem value="Lagos Mainland">Lagos Mainland</SelectItem>
                                      <SelectItem value="Mushin">Mushin</SelectItem>
                                      <SelectItem value="Ojo">Ojo</SelectItem>
                                      <SelectItem value="Oshodi-Isolo">Oshodi-Isolo</SelectItem>
                                      <SelectItem value="Shomolu">Shomolu</SelectItem>
                                      <SelectItem value="Surulere">Surulere</SelectItem>
                                  </SelectContent>
                              </Select>
                          </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="postal"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Postal Code</FormLabel>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                        <FormControl>
                          <Input placeholder="100001" {...field} className="pl-10" maxLength={6} type={"number"} />
                        </FormControl>
                      </div>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-[#6E59A5] hover:bg-[#6E59A5]/90"
                disabled={loading}
              >
                {loading ? "Creating account..." : "Create Account"}
              </Button>

              <div className="text-center mt-4">
                <p className="text-sm text-gray-600">
                  Already have an account?{" "}
                  <button
                    type="button"
                    onClick={() => navigate("/login")}
                    className="text-[#6E59A5] hover:underline"
                  >
                    Sign in
                  </button>
                </p>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
        <OtpModal
            isOpen={isOtpModalOpen}
            onClose={() => setIsOtpModalOpen(false)}
            onSubmit={handleOtpSubmit}
            email="user@example.com" // Optional
            loading={submitLoading}        />

    </div>
  );
};

export default RegisterForm;
