
import { useNavigate } from "react-router-dom";
import { ProductDetailsCard } from "@/components/OrderDetails/ProductDetailsCard";
import { OrderInfoCard } from "@/components/OrderDetails/OrderInfoCard";
import { PaymentDetailsCard } from "@/components/OrderDetails/PaymentDetailsCard";
import { useOrderManagement } from "@/hooks/useOrderManagement";
import { usePaymentHandling } from "@/hooks/usePaymentHandling";

const OrderSummary = () => {
  const navigate = useNavigate();
  const {
    userInfo,
    deliveryInfo,
    paymentType,
    period,
    loading,
    setLoading,
    selectedColor,
    items,
    totalAmount,
    initialPayment,
    remainingBalance,
    monthlyPayment,
    baseAmount
  } = useOrderManagement();

  const { handleVirtualAccountPayment, loading: isLoading, } = usePaymentHandling({
    items,
    totalAmount: baseAmount,
    paymentType,
    period,
    deliveryInfo,
    setLoading
  });


  if (!userInfo) {
    return <div className="flex justify-center p-8">Loading...</div>;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <button
        onClick={() => navigate("/order", {state: {showOrderForm: true}})}
        className="text-[#6E59A5] hover:underline mb-4 flex items-center gap-2"
      >
        ← Back to Order
      </button>

      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-2xl font-semibold mb-6">Order Summary</h1>

        <ProductDetailsCard items={items} />

        <OrderInfoCard userInfo={userInfo} deliveryInfo={deliveryInfo} />

        <PaymentDetailsCard
          paymentType={paymentType}
          period={period}
          selectedColor={selectedColor}
          totalAmount={totalAmount}
          baseAmount={baseAmount}
          initialPayment={initialPayment}
          remainingBalance={remainingBalance}
          monthlyPayment={monthlyPayment}
          loading={isLoading}
          onVirtualAccountPayment={handleVirtualAccountPayment}
        />
      </div>
    </div>
  );
};

export default OrderSummary;
