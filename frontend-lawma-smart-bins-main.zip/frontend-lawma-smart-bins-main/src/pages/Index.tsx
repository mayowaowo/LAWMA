import { useState, useEffect } from "react";
import {useLocation, useNavigate} from "react-router-dom";
import Hero from "@/components/Hero";
import ProductDisplay from "@/components/ProductDisplay";
import DeliveryForm from "@/components/DeliveryForm";
import PaymentOptions from "@/components/PaymentOptions";
import ColorSelector from "@/components/ColorSelector";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { ProductSelector } from "@/components/ProductSelector";
import { PRODUCTS, calculateDiscount } from "@/config/products";
import type { OrderItem } from "@/types/product";
import { Card, CardContent } from "@/components/ui/card";
import {addOrder, handleSaveVerification, handleSelectedColor} from "@/services/constant/actions.ts";
import {useDispatch, useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {VerificationModal} from "@/components/VerificationModal.tsx";

const Index = () => {
  const location = useLocation();
  const [showOrderForm, setShowOrderForm] = useState(false);
    const [isRegistered, setIsRegistered] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [submitAddress, setSubmitAddress] = useState(false);
  const orderState = useSelector((state: RootState) => state.orders );
  const userState = useSelector((state: RootState) => state.user);
const {user} = userState;
  const {orders, delivery, paymentType, installmentPeriod} = orderState;
    useEffect(() => {
    if (location.state?.showOrderForm === true) {
      setShowOrderForm(true); // Update showOrderForm if the state from location is passed
    }
  }, [location.state]);

    useEffect(() => {
    setIsRegistered(true);
  }, [navigate]);

  const handleOrderClick = () => {
    if (isRegistered) {
      setShowOrderForm(true);
    } else {
      navigate("/register");
    }
  };

  const [selectedColor, setSelectedColor] = useState<"green-general" | "blue-recycle">("green-general");
  const [selectedItems, setSelectedItems] = useState<OrderItem[]>([]);
  const [verified, setVerified] = useState(false);

  const checkUservalidation = (paymentType) => {
        if(paymentType === 'INSTALLMENT'){

      if (!user.installmentVerificationStatus){
                setVerified(true);
        return false
      }else {
        return true
      }

    }
    return true;
  }

  const handlePaymentSubmit = async (paymentType) => {
    // Check if delivery information is filled

    if (!selectedItems || selectedItems.length === 0) {
      toast.error("Please select at least one item to proceed with the order");
      return;
    }

    if (!delivery || !delivery.address || delivery.address.trim() === '') {
      toast.error("Please provide a delivery address");
      return;
    }

    if (!submitAddress) {
      toast.error("Please save delivery address");

      return
    }


    const deliveryForm = document.querySelector("form");
    if (deliveryForm) {
      const isValid = deliveryForm.checkValidity();
      if (!isValid) {
        toast.error("Please fill all required delivery information");
        deliveryForm.reportValidity();
        return;
      }
      const submitEvent = new Event("submit", {cancelable: true});
      deliveryForm.dispatchEvent(submitEvent);
    }
    const existingOrders = orders || "[]";
    const deliveryInfo = delivery;




    const totalAmount = selectedItems.reduce((total, item) => {
      const product = PRODUCTS.find(p => p.id === item.productId);
      if (product) {
        total += product.price * item.quantity;
      }
      return total;
    }, 0);


    const discountedAmount = calculateDiscount(
        totalAmount,
        paymentType,
        installmentPeriod ? parseInt(installmentPeriod) : undefined
    );

    const isValid = await checkUservalidation(paymentType);

    if (!isValid) {
      // Stop execution here if validation fails
      return;
    }

    // const newOrder = {
    //   orderId: "ORD" + Math.floor(Math.random() * 1000000),
    //   items: selectedItems,
    //   amount: discountedAmount,
    //   paymentType,
    //   period: installmentPeriod || undefined,
    //   status: "pending",
    //   date: new Date().toISOString(),
    //   orderForOthers: deliveryInfo.orderForOthers || false,
    //   recipient: deliveryInfo.orderForOthers ? deliveryInfo.recipient : null
    // };
    //
    // localStorage.setItem("orders", JSON.stringify([...existingOrders, newOrder]));
    navigate("/order-summary");
  };
  useEffect(() => {
    setSelectedItems(orders)
  }, []);
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F2FCE2] to-white">
      {!showOrderForm ? (
        <div>
          <div className="flex flex-col items-center justify-center min-h-[60vh] bg-gradient-to-b from-[#F2FCE2] to-white px-4">
            <h1 className="text-4xl md:text-5xl font-bold text-[#1A1F2C] text-center mb-6">
              Introducing SMART BIN Technology into Waste Management
            </h1>
            {/* Removed ...FREE DELIVERY WITHIN LAGOS and bin is meant for Lagos line */}
            <p className="text-lg text-gray-600 text-center max-w-2xl mb-8">
              From simple ordering to flexible payments, we’ve made keeping the environment clean - easy and smart.
            </p>
            <Button
              onClick={handleOrderClick}
              className="bg-[#0EA5E9] hover:bg-[#0EA5E9]/90 text-white px-8 py-6 rounded-lg text-lg flex items-center gap-2"
            >
              Order Your Waste Bin
              <ArrowRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      ) : (
        <div className="container mx-auto py-8 px-4 space-y-8">
          <button
            onClick={() => setShowOrderForm(false)}
            className="text-[#6E59A5] hover:underline mb-4 flex items-center gap-2"
          >
            ← Back
          </button>
          <div className="grid md:grid-cols-2 gap-8 items-start">
            {/* LEFT: Info cards */}
            <div className="space-y-6">
              <Card className="mb-3 shadow-sm border border-[#E3E9DB]">
                <CardContent className="pt-6">
                  <h2 className="text-2xl font-semibold text-[#1A1F2C] mb-3">What We Offer</h2>
                  <ul className="list-disc pl-6 text-gray-700 text-base space-y-1">
                    <li>10-year Warranty</li>
                    <li>Geotagging Technology</li>
                    <li>Smooth Rolling Wheels</li>
                    <li>Withstand Harsh Weather Conditions</li>
                  </ul>
                </CardContent>
              </Card>
              <Card className="shadow-sm border border-[#E3E9DB]">
                <CardContent className="pt-6">
                  <div className="flex flex-col items-center">
                    <img
                      src="https://placehold.co/600x400/F2FCE2/1A1F2C/png?text=SMART+BIN"
                      alt="Smart Bin"
                      className="rounded-lg w-full max-w-md mx-auto"
                    />
                    <div className="mt-6 w-full">
                      <h3 className="text-xl font-semibold text-[#1A1F2C] mb-2">
                        Our Smart Solution
                      </h3>
                      <p className="text-gray-600 text-sm">
                        Our affordable smart bins are built for durability and equipped with advanced technology including geotagging, and a unique tracking system. Backed by a 10-year warranty, we offer you a reliable and intelligent solution for managing waste at home, in businesses, schools, worship centre and beyond.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* RIGHT: Order forms/cards */}
            <div className="space-y-6">
              <ProductSelector onProductSelect={setSelectedItems} />
              {/*<ColorSelector onColorSelect={(color) => {*/}
              {/*  setSelectedColor(color as "green-general" | "blue-recycle");*/}
              {/*  dispatch(handleSelectedColor(color as "green-general" | "blue-recycle"));*/}
              {/*  setSelectedItems(items =>*/}
              {/*    items.map(item => ({ ...item, color: color as "green-general" | "blue-recycle" }))*/}
              {/*  );*/}
              {/*}} />*/}
              <DeliveryForm onSubmit={() => setSubmitAddress(true)} />
              <PaymentOptions onSubmit={handlePaymentSubmit} />
              <Button
                onClick={handlePaymentSubmit}
                className="w-full bg-[#6E59A5] hover:bg-[#6E59A5]/90 text-white"
                disabled={selectedItems.length === 0}
              >
                Continue to Order Summary
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
      <VerificationModal isOpen={verified} onClose={() => setVerified(false) } onSubmit={(data: { bvn: string; nin: string; }) => {
        dispatch(handleSaveVerification(data))
        navigate("/order-summary");

      } } />
    </div>
  );
};

export default Index;
