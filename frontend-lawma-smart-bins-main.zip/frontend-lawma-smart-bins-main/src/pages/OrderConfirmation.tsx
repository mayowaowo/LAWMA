
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, UserPlus } from "lucide-react";
import { useEffect, useState } from "react";

interface DeliveryInfo {
  address: string;
  city: string;
  postalCode: string;
  orderForOthers: boolean;
  recipient: {
    fullName: string;
    phoneNumber: string;
  } | null;
}

const OrderConfirmation = () => {
  const navigate = useNavigate();
  const [deliveryInfo, setDeliveryInfo] = useState<DeliveryInfo | null>(null);
  
  useEffect(() => {
    // Get delivery information from localStorage
    const storedDeliveryInfo = localStorage.getItem("deliveryInfo");
    if (storedDeliveryInfo) {
      setDeliveryInfo(JSON.parse(storedDeliveryInfo));
    }
  }, []);
  
  // Get the latest order from localStorage
  const orders = JSON.parse(localStorage.getItem("orders") || "[]");
  const latestOrder = orders.length > 0 ? orders[orders.length - 1] : null;
  
  if (!latestOrder) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center">
          <p>No order information found.</p>
          <Button 
            onClick={() => navigate("/")} 
            className="mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90"
          >
            Return to Home
          </Button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-md mx-auto text-center">
        <div className="flex justify-center mb-6">
          <CheckCircle size={80} className="text-green-500" />
        </div>
        
        <h1 className="text-2xl font-semibold mb-2">Order Confirmed!</h1>
        <p className="text-gray-600 mb-8">
          Thank you for your purchase. Your order has been confirmed.
        </p>
        
        <Card className="mb-8">
          <CardContent className="p-6 text-left">
            <h2 className="font-medium mb-4">Order Details</h2>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-gray-500">Order ID:</span>
                <span className="font-medium">{latestOrder.orderId}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-500">Product:</span>
                <span className="font-medium">{latestOrder.productName}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-500">Amount Paid:</span>
                <span className="font-medium">₦{latestOrder.amount.toLocaleString()}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-500">Payment Status:</span>
                <span className="text-green-600 font-medium capitalize">{latestOrder.status}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-500">Date:</span>
                <span className="font-medium">
                  {new Date(latestOrder.date).toLocaleDateString()}
                </span>
              </div>
              
              {latestOrder.paymentType === "installment" && latestOrder.period && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Payment Plan:</span>
                  <span className="font-medium">
                    Installment ({latestOrder.period} months)
                  </span>
                </div>
              )}
              
              {deliveryInfo?.orderForOthers && deliveryInfo.recipient && (
                <div className="border-t border-dashed border-gray-200 pt-3 mt-3">
                  <div className="flex items-center gap-2 mb-3">
                    <UserPlus size={16} className="text-[#6E59A5]" />
                    <span className="font-medium text-[#6E59A5]">Recipient Information</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-500">Recipient Name:</span>
                    <span className="font-medium">{deliveryInfo.recipient.fullName}</span>
                  </div>
                  
                  <div className="flex justify-between mt-1">
                    <span className="text-gray-500">Recipient Phone:</span>
                    <span className="font-medium">{deliveryInfo.recipient.phoneNumber}</span>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        <div className="space-y-4">
          <Button 
            onClick={() => navigate("/account")} 
            className="w-full bg-[#6E59A5] hover:bg-[#6E59A5]/90"
          >
            View Order in My Account
          </Button>
          
          <Button 
            onClick={() => navigate("/")} 
            variant="outline"
            className="w-full border-[#6E59A5] text-[#6E59A5] hover:bg-[#6E59A5]/10"
          >
            Return to Home
          </Button>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;
