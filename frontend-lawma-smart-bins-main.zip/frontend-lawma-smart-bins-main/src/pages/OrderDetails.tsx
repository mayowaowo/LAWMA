
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Package, MapPin, Calendar, CreditCard, UserPlus, User, Palette } from "lucide-react";

interface Order {
  orderId: string;
  productName: string;
  color?: string; // Make color optional for backwards compatibility
  amount: number;
  paymentType: string;
  period?: string;
  status: string;
  date: string;
  orderForOthers?: boolean;
  recipient?: {
    fullName: string;
    phoneNumber: string;
  } | null;
}

const OrderDetails = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    const foundOrder = orders.find((o: Order) => o.orderId === orderId);
    if (foundOrder) {
      setOrder(foundOrder);
    }
  }, [orderId]);

  if (!order) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center">
          <p>Order not found.</p>
          <Button 
            onClick={() => navigate("/account")} 
            className="mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90"
          >
            Back to My Account
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <button
        onClick={() => navigate("/account")}
        className="text-[#6E59A5] hover:underline mb-4 flex items-center gap-2"
      >
        ← Back to My Account
      </button>

      <div className="max-w-3xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-semibold">Order Details</h1>
          <div className="flex items-center gap-2">
            <span className={`px-3 py-1 rounded-full text-sm font-medium
              ${order.status === 'paid' ? 'bg-green-100 text-green-800' : 
                order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 
                order.status === 'processing' ? 'bg-blue-100 text-blue-800' : 
                'bg-gray-100 text-gray-800'}`}
            >
              {order.status}
            </span>
          </div>
        </div>

        <Card>
          <CardContent className="p-6">
            <div className="grid gap-6">
              <div className="flex items-start gap-4">
                <div className="bg-[#6E59A5]/10 p-3 rounded-full">
                  <Package className="h-6 w-6 text-[#6E59A5]" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">Order Information</h3>
                  <div className="mt-2 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Order ID:</span>
                      <span>{order.orderId}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Product:</span>
                      <span>{order.productName}</span>
                    </div>
                    {order.color && (
                      <div className="flex justify-between text-sm items-center">
                        <span className="text-gray-500">Color:</span>
                        <div className="flex items-center gap-2">
                          <span className="capitalize">{order.color}</span>
                          <span 
                            className="inline-block w-4 h-4 rounded-full"
                            style={{ backgroundColor: order.color }}
                          ></span>
                        </div>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Amount:</span>
                      <span>₦{order.amount.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Date:</span>
                      <span>{new Date(order.date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Payment Type:</span>
                      <span>
                        {order.paymentType === "installment" 
                          ? `Installment (${order.period} months)`
                          : "One-off"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {order.orderForOthers && order.recipient && (
                <div className="flex items-start gap-4">
                  <div className="bg-[#6E59A5]/10 p-3 rounded-full">
                    <UserPlus className="h-6 w-6 text-[#6E59A5]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">Recipient Information</h3>
                    <div className="mt-2 space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Name:</span>
                        <span>{order.recipient.fullName}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Phone Number:</span>
                        <span>{order.recipient.phoneNumber}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {!order.orderForOthers && (
                <div className="flex items-start gap-4">
                  <div className="bg-gray-100 p-3 rounded-full">
                    <User className="h-6 w-6 text-gray-500" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium">Order Type</h3>
                    <p className="mt-2 text-sm text-gray-500">
                      This order was placed for yourself
                    </p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {order.paymentType === "installment" && (
          <Card>
            <CardContent className="p-6">
              <h3 className="font-medium mb-4">Installment Payments</h3>
              <Button 
                onClick={() => navigate(`/pay-installment/${order.orderId}`)}
                className="bg-[#6E59A5] hover:bg-[#6E59A5]/90 w-full"
              >
                Pay Next Installment
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="flex justify-center">
          <Button
            onClick={() => navigate("/account")}
            variant="outline"
            className="border-[#6E59A5] text-[#6E59A5] hover:bg-[#6E59A5]/10"
          >
            Back to Orders
          </Button>
        </div>
      </div>
    </div>
  );
};

export default OrderDetails;
