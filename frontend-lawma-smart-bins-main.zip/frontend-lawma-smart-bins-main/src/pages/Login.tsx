
import {useEffect, useState} from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {UserCircle, Lock, Mail, EyeOff, Eye} from "lucide-react";
import {handleLoginRequest, handleRegisterRequest, updateEmailVerification} from "@/services/constant/actions.ts";
import {useDispatch, useSelector} from "react-redux";
import {Auth} from "@/services/constant/actionTypes.ts";
import {RootState} from "@/services/reducers/rootReducer.ts";
import OtpModal from "@/components/OtpModal.tsx";
import {emailVerification} from "@/services/api/hooks/Register.ts";

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isOtpModalOpen, setIsOtpModalOpen] = useState(false)
  const [submitLoading, setSubmitLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  // const [email, setEmail] = useState("admin@pcxff.com");
  // const [password, setPassword] = useState("@Habeeb4life");
  const [isLoading, setIsLoading] = useState(false);
  const AuthState = useSelector((state: RootState) => state.auth as Auth);
  const UserState = useSelector((state: RootState) => state.user);
  const {user} = UserState;
  const {loading, emailVerified} = AuthState;

  const handleOtpSubmit = async (otp: string) => {
        setSubmitLoading(true)
    const payload = {
      uuid: user.uuid,
      otp: otp,
    }
    const res = await emailVerification(payload, navigate)
    if (res.success) {
      setSubmitLoading(false)
      dispatch(updateEmailVerification(false))
      setIsOtpModalOpen(false)
    }
    setSubmitLoading(false)

  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault(); // Prevent the form from refreshing the page
            setIsLoading(true); // Log here

    // Check if email or password is missing
    if (!email || !password) {
      toast.error("Please fill in all fields");
      return;
    }


    try {
      const loginData = {
        email: email,
        password: password,
      };

      // Dispatch login request and handle the success callback
      dispatch(
          handleLoginRequest({
            payload: loginData,
            navigate: navigate,
            onSuccess: () => {
              navigate("/order"); // Redirect to the /order route after successful login
            },
          })
      );
    } catch (error) {
      // Handle errors (if the `handleLoginRequest` action fails)
      toast.error("Login failed. Please try again.");
      console.error("Error during login:", error);
    } finally {
      // Ensure setIsLoading(false) is always executed
      setIsLoading(false);
    }
  };
  useEffect(() => {
    // setIsOtpModalOpen(emailVerified)

  }, [isLoading, isOtpModalOpen]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F2FCE2] to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Welcome Back</CardTitle>
          <CardDescription>
            Sign in to your BinSmart account
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label htmlFor="password">Password</Label>
                <button
                  type="button"
                  onClick={() => navigate("/forgot-password")}
                  className="text-sm text-[#6E59A5] hover:underline"
                >
                  Forgot passwords?
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <div className={'relative'}>
                  <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="pl-10"
                      required
                  />
                  <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 h-4 w-4 text-gray-400 cursor-pointer hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}
                  </button>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-[#6E59A5] hover:bg-[#6E59A5]/90"
              disabled={loading}
            >
              {loading ? "Signing in..." : "Sign In"}
            </Button>

            <div className="text-center mt-4">
              <p className="text-sm text-gray-600">
                Don't have an account?{" "}
                <button
                  type="button"
                  onClick={() => navigate("/register")}
                  className="text-[#6E59A5] hover:underline"
                >
                  Register
                </button>
              </p>
            </div>
          </form>
        </CardContent>
      </Card>
      <OtpModal
          isOpen={emailVerified}
          onClose={() => {
            dispatch(updateEmailVerification(false))
            setIsOtpModalOpen(false)
          }}
          onSubmit={handleOtpSubmit}
          loading={submitLoading}/>
    </div>
  );
};

export default Login;
