import {useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import {Button} from "@/components/ui/button";
import {ArrowRight, Package, Truck, Calendar, MapPin, Printer, Phone, AtSign} from "lucide-react";
import {ReactComponent as MapSvg} from '@/assets/map.svg';
import {ReactComponent as ArrowSvg} from '@/assets/arrow.svg';
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import FrequentlyAskedQuestions from "@/components/faqs.tsx";

const Landing = () => {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(false);
    const AuthState = useSelector((state: RootState) => state.auth);
    const {isAuthenticated} = AuthState;
    const handleGetStarted = () => {
        setIsLoading(true);
        navigate("/order");
    };

    return (
        <div className="min-h-screen bg-[#F5F5F5] pt-8 md:pt-14 flex flex-col gap-y-12 md:gap-y-24">
            {/* Hero Section */}
            <div
                className="rounded-3xl w-[92%] lg:w-10/12 2xl:9/12 mx-auto bg-[#076836] relative h-auto md:h-[50rem] lg:h-[30rem] xl:h-[40rem] 2xl:h-[45rem] px-4 md:px-0">
                <div className="w-full h-full flex items-center justify-center">
                    <MapSvg className="w-full h-full object-contain hidden md:block"
                            preserveAspectRatio="xMidYMid meet"/>
                </div>
                <div
                    className="w-full h-full flex flex-col lg:flex-row items-center justify-center md:absolute md:top-0 py-8 md:py-0">
                    <div
                        className="flex flex-col gap-y-5 justify-start w-full md:w-[65%] xl:w-[55%] md:py-5 2xl:w-[45%] px-4 lg:px-5 text-center lg:text-left">
                        <h1 className="text-xl lg:text-2xl font-bold text-white">Welcome</h1>
                        <h2 className="lg:text-4xl xl:text-5xl 2xl:text-6xl md:text-3xl font-bold text-white leading-tight lg:leading-[2.5rem] xl:leading-[4.5rem]">
                            Your First Step to a Cleaner Community Starts Here
                        </h2>
                        <p className="text-sm md:text-base text-white font-light">
                            From simple ordering to flexible payments, we've made keeping the environment clean – easy
                            and smart
                        </p>
                        <Link to={'register'}
                            className="rounded-full flex items-center w-fit px-3 py-3 justify-between text-white bg-[#DD7E0F] mx-auto lg:mx-0">
                            <span>Contact us</span>
                            <span className="ml-2">
                <ArrowSvg className="w-2 h-2 object-contain"/>
              </span>
                        </Link>
                    </div>
                    <div className="w-full md:w-auto mt-8 md:mt-0">
                        <div className="w-full h-full flex items-center justify-center">
                            <img
                                src="/lovable-uploads/assets/bin.png"
                                alt="Waste Bin"
                                className="w-[80%] lg:w-[90%] xl:w-full h-auto object-contain"
                            />
                        </div>
                    </div>
                </div>
            </div>

            {/* Features Section */}
            <div className="w-[92%] lg:w-10/12   mx-auto px-4 lg:px-0">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-16 w-full md:grid-cols-2 xl:w-10/12 2xl:w-9/12 mx-auto">
                    {/* Easy Ordering Card */}
                    <div className="p-6 bg-white rounded-lg shadow-lg flex flex-col gap-y-5">
                        <div
                            className="w-12 h-12 bg-[#F2FCE2] rounded-full flex items-center justify-center mx-auto mb-4">
                            <Package className="text-[#6E59A5]"/>
                        </div>
                        <h3 className="text-xl font-semibold mb-2 text-center">Easy Ordering</h3>
                        <p className="text-gray-600 text-center">
                            Simple and quick process to order your waste bins
                        </p>
                        <p className="text-[#FE6200] text-sm font-medium text-center">
                            *The bin is meant for Lagos State tenements ONLY
                        </p>
                    </div>

                    {/* Fast Delivery Card */}
                    <div className="p-6 bg-white rounded-lg shadow-lg flex flex-col gap-y-5">
                        <div
                            className="w-12 h-12 bg-[#F2FCE2] rounded-full flex items-center justify-center mx-auto mb-4">
                            <Truck className="text-[#6E59A5]"/>
                        </div>
                        <h3 className="text-xl font-semibold mb-2 text-center">Fast Delivery</h3>
                        <p className="text-gray-600 text-center">
                            Quick delivery to your specified location
                        </p>
                        <p className="text-[#FE6200] text-sm font-medium text-center">
                            *The bin is meant for Lagos State tenements ONLY
                        </p>
                    </div>

                    {/* Flexible Payments Card */}
                    <div className="p-6 bg-white rounded-lg shadow-lg flex flex-col gap-y-5">
                        <div
                            className="w-12 h-12 bg-[#F2FCE2] rounded-full flex items-center justify-center mx-auto mb-4">
                            <Calendar className="text-[#6E59A5]"/>
                        </div>
                        <h3 className="text-xl font-semibold mb-2 text-center">Flexible Payments</h3>
                        <p className="text-gray-600 text-center">
                            Choose between full payments or installment options
                        </p>
                        <p className="text-[#FE6200] text-sm font-medium text-center">
                            *The bin is meant for Lagos State tenements ONLY
                        </p>
                    </div>
                </div>
            </div>

            {/* CTA Section */}
            <div
                className="w-[92%] lg:w-10/12 2xl:w-9/12 mx-auto bg-white rounded-3xl h-auto lg:h-[20rem]  2xl:h-[25rem] relative overflow-visible px-4 lg:px-0">
                <div className="flex flex-col lg:flex-row w-full h-full items-center py-8 lg:py-0">
                    <div
                        className="w-full md:w-7/12 text-center lg:text-start flex flex-col gap-y-5 p-4 md:p-6 md:px-9">
                        <h1 className="text-2xl 2xl:text-3xl font-medium">
                            Revolutionize your waste management now
                        </h1>
                        {/*<p className="text-gray-600 text-sm font-light">*/}
                        {/*    Revolutionize your waste management now*/}
                        {/*</p>*/}
                        <Link to={isAuthenticated ? 'order' : `register`}
                            className="rounded-lg flex items-center text-sm font-light w-fit px-3 py-2 text-white bg-[#DD7E0F] mx-auto lg:mx-0">
                            Order Here
                        </Link>
                    </div>
                    <div className="w-[80%] lg:w-[40%] mt-8 lg:mt-0 lg:absolute lg:-top-10 lg:right-0">
                        <img
                            src="/lovable-uploads/assets/greenbin.png"
                            alt="Green Bin"
                            className="w-full h-auto object-contain"
                        />
                    </div>
                </div>
            </div>

            {/* Faq */}
            <FrequentlyAskedQuestions />


            {/* Footer Section */}
            <div className="bg-[#076836] py-8 md:py-14 mt-12 md:mt-0">
                {/* Footer Top */}
                <div
                    className="flex flex-col md:flex-row justify-between gap-y-8 p-4 md:p-6 w-[92%] md:w-10/12 2xl:w-9/12 mx-auto border-t border-b border-[#FFFFFF33] min-h-[12rem]">
                    <div>
                        <Link to="/" className="flex items-center gap-2">
                            <img
                                src="/lovable-uploads/64c46b42-4d7d-498c-94bb-68ee9a2988c3.png"
                                alt="Logo"
                                className="h-10 w-10 rounded-full"
                            />
                        </Link>
                    </div>
                    <div className="w-full md:w-[40%] 2xl:w-4/12">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-y-4 md:gap-y-6 text-xs text-white">
                            <div
                                className="flex items-center gap-3 md:gap-5 text-sm text-white font-light md:col-span-3">
                                <MapPin className="text-white w-4 h-4"/>
                                <span className="text-xs text-white">No. 3 Iddo - Yard, Ijora Olopa, Lagos State.</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm font-light">
                                <Phone className="text-white w-4 h-4"/>
                                <span className="text-xs text-white">0913-388-9535</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm font-light">
                                <Phone className="text-white w-4 h-4"/>
                                <span className="text-xs text-white">07082035413</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm font-light">
                                <Printer className="text-white w-4 h-4"/>
                                <span className="text-xs text-white">0904-663-4801</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm font-light md:col-span-2">
                                <AtSign className="text-white w-4 h-4"/>
                                <span className="text-xs text-white">Customercare@lawmasmartbins.com</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm font-light md:col-span-2">
                                <AtSign className="text-white w-4 h-4"/>
                                <span className="text-xs text-white">Info@lawmasmartbins.com</span>
                            </div>

                        </div>
                    </div>
                </div>

                {/* Footer Bottom */}
                <div
                    className="flex flex-col md:flex-row justify-between gap-y-6 py-3 w-[92%] md:w-9/12 mx-auto px-4 md:px-0">
                    <div
                        className="flex flex-wrap gap-4 md:gap-5 text-sm text-white font-light capitalize justify-center md:justify-start">
                        <span>About us</span>
                        <span>Contact us</span>
                        <span>Help</span>
                        <span>Privacy Policy</span>
                        <span>Disclaimer</span>
                    </div>
                    <div
                        className="flex items-center justify-center md:justify-start gap-5 text-sm text-[#FFFFFF33] font-light capitalize">
                        <span>Copyright © {new Date().getFullYear()} • LAWMA</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Landing;


{/*<div className="container mx-auto px-4 py-12 md:py-24">*/
}
{/*  <div className="max-w-4xl mx-auto text-center">*/
}
{/*    <h1 className="text-4xl md:text-6xl font-bold text-[#1A1F2C] mb-6">*/
}
{/*      Welcome! Your First Step to a Cleaner Community Starts Here*/
}
{/*    </h1>*/
}
{/*    /!* Removed the . . . FREE DELIVERY within Lagos and the Lagos tenements line *!/*/
}
{/*    <p className="text-xl text-gray-600 mb-12">*/
}
{/*      From simple ordering to flexible payments, we've made keeping the environment*/
}
{/*      clean – easy and smart*/
}
{/*    </p>*/
}

{/*    <Button*/
}
{/*      onClick={handleGetStarted}*/
}
{/*      disabled={isLoading}*/
}
{/*      className="bg-[#6E59A5] hover:bg-[#6E59A5]/90 text-lg px-8 py-6"*/
}
{/*    >*/
}
{/*      Get Started*/
}
{/*      <ArrowRight className="ml-2" />*/
}
{/*    </Button>*/
}

{/*    <div className="grid md:grid-cols-3 gap-8 mt-24">*/
}
{/*      <div className="p-6 bg-white rounded-lg shadow-lg">*/
}
{/*        <div className="w-12 h-12 bg-[#F2FCE2] rounded-full flex items-center justify-center mx-auto mb-4">*/
}
{/*          <Package className="text-[#6E59A5]" />*/
}
{/*        </div>*/
}
{/*        <h3 className="text-xl font-semibold mb-2">Easy Ordering</h3>*/
}
{/*        <p className="text-gray-600">*/
}
{/*          Simple and quick process to order your waste bins*/
}
{/*          <br />*/
}
{/*          <span className="text-[#1A1F2C] font-medium">The bin is meant for Lagos State tenements ONLY</span>*/
}
{/*        </p>*/
}
{/*      </div>*/
}

{/*      <div className="p-6 bg-white rounded-lg shadow-lg">*/
}
{/*        <div className="w-12 h-12 bg-[#F2FCE2] rounded-full flex items-center justify-center mx-auto mb-4">*/
}
{/*          <Truck className="text-[#6E59A5]" />*/
}
{/*        </div>*/
}
{/*        <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>*/
}
{/*        <p className="text-gray-600">*/
}
{/*          Quick delivery to your specified location*/
}
{/*          <br />*/
}
{/*          <span className="text-[#1A1F2C] font-medium">FREE DELIVERY WITHIN LAGOS</span>*/
}
{/*        </p>*/
}
{/*      </div>*/
}

{/*      <div className="p-6 bg-white rounded-lg shadow-lg">*/
}
{/*        <div className="w-12 h-12 bg-[#F2FCE2] rounded-full flex items-center justify-center mx-auto mb-4">*/
}
{/*          <Calendar className="text-[#6E59A5]" />*/
}
{/*        </div>*/
}
{/*        <h3 className="text-xl font-semibold mb-2">Flexible Payment</h3>*/
}
{/*        <p className="text-gray-600">*/
}
{/*          Choose between full payment or installment options.<br />*/
}
{/*          /!*<span className="text-red-700 font-medium">Bins will only be dispatched once the final payment has been made.</span>*!/*/
}
{/*        </p>*/
}
{/*      </div>*/
}
{/*    </div>*/
}
{/*  </div>*/
}
{/*</div>*/
}
