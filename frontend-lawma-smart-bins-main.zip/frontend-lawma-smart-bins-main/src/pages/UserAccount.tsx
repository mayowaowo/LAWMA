
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  UserCircle,
  Package,
  LogOut,
  UserPlus,
  User,
  Copy,
  MoreVertical,
  List,
  ChevronRight,
  ChevronLeft
} from "lucide-react";
import { toast } from "sonner";
// import {UserCircle, Copy} from "lucide-react";
import {Tooltip, TooltipContent, TooltipProvider, TooltipTrigger} from "@/components/ui/tooltip";
import {cn} from "@/lib/utils.ts";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {useDispatch, useSelector} from "react-redux";
import {useOrder} from "@/services/api/hooks/order.ts";
import {clearOrders, handleLogoutRequest} from "@/services/constant/actions.ts";
import {format} from "date-fns";
// import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
import {RepaymentModal} from "@/components/ui/repaymentModal.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import OrderDetailsModal from "@/components/OrdersDetailsModal.tsx";
import {ReferralListModal} from "@/components/referralListModal.tsx";

interface Order {
  orderId: string;
  productName: string;
  amount: number;
  paymentType: string;
  period?: string;
  status: string;
  date: string;
  orderForOthers?: boolean;
  recipient?: {
    fullName: string;
    phoneNumber: string;
  } | null;
}

interface UserInfo {
  fullName: string;
  phoneNumber: string;
  address: string;
  city: string;
  postalCode: string;
  email: string;
  referral: string;
}

const getStatusColor = (status: string) => {
  switch (status) {
    case 'paid':
      return 'bg-green-500';
    case 'pending':
      return 'bg-orange-400';
    case 'processing':
      return 'bg-blue-500';
    case 'failed':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
};

const UserAccount = () => {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderInfo, setOrderInfo] = useState(null);
  const UserState = useSelector((state: RootState) => state.user);
  const {user: userInfo } = UserState;
  const [copied, setCopied] = useState(false);
  const [operReferral, setOpenReferral] = useState(false);

  const [open, setOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const {getOrderHistories, orderHistory, loading, repaymentHistory} = useOrder()
  const dispatch = useDispatch();
  // In your table component:
  const [selectedOrder, setSelectedOrder] = useState<null | any>(null);

 // Add this to your row action or wherever you want to trigger the modal
  const handleViewDetails = (order) => {
    setSelectedOrder(order);
  };
  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setOpen(true);
    setTimeout(() => {
      setCopied(false);
      setOpen(false);
    }, 2000);
  };

  const formattedDate = (date) => format(new Date(date), 'dd MMM yyyy, hh:mm a');

  const ITEMS_PER_PAGE = 10;

  // Inside the OrdersTable component, add these state variables
  const [currentPage, setCurrentPage] = useState(1);

  // Add this function to handle page changes
  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };
  const totalPages = Math.ceil(orderHistory.length / ITEMS_PER_PAGE);
  // Calculate paginated orders
  const paginatedOrders = orderHistory.slice(
      (currentPage - 1) * ITEMS_PER_PAGE,
      currentPage * ITEMS_PER_PAGE
  );


  const handleRepayment = (payload) => {
    const res = repaymentHistory(payload)
      }

  const handleLogout = () => {
    dispatch(clearOrders())
    dispatch(handleLogoutRequest());
    toast.success("You have been logged out");
    navigate("/");
  };

  useEffect(() => {
    getOrderHistories()
  },[])

  if (!userInfo) {
    return <div className="flex justify-center p-8">Loading...</div>;
  }

  const PaginationControls = () => {
    return (
        <div className="flex items-center justify-between px-2 py-4">
          <div className="text-sm text-muted-foreground">
            Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, orderHistory.length)} of {orderHistory.length} entries
          </div>
          <div className="flex items-center space-x-2">
            <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4"/>
              Previous
            </Button>
            <div className="flex items-center space-x-1">
              {[...Array(totalPages)].map((_, index) => (
                  <Button
                      key={index + 1}
                      variant={currentPage === index + 1 ? "default" : "outline"}
                      size="sm"
                      onClick={() => handlePageChange(index + 1)}
                  >
                    {index + 1}
                  </Button>
              ))}
            </div>
            <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
            >
              Next
              <ChevronRight className="h-4 w-4"/>
            </Button>
          </div>
        </div>
    );
  };


  return (
    <div className="container mx-auto py-8 px-4">
      <button
        onClick={() => navigate("/")}
        className="text-[#6E59A5] hover:underline mb-4 flex items-center gap-2"
      >
        ← Back to Home
      </button>

      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <h1 className="text-2xl font-semibold">My Account</h1>
          <Button
            variant="outline"
            className="border-red-500 text-red-500 hover:bg-red-50"
            onClick={handleLogout}
          >
            <LogOut size={16} className="mr-2" />
            Logout
          </Button>
        </div>

        {/*<Card>*/}
        {/*  <CardContent className="p-6">*/}
        {/*    <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">*/}
        {/*      <div className="bg-[#6E59A5]/10 p-3 rounded-full">*/}
        {/*        <UserCircle size={48} className="text-[#6E59A5]" />*/}
        {/*      </div>*/}
        {/*      <div>*/}
        {/*        <h2 className="text-xl font-semibold">{userInfo.fullName}</h2>*/}
        {/*        <p className="text-gray-600">{userInfo.phoneNumber}</p>*/}
        {/*      </div>*/}
        {/*    </div>*/}

        {/*    <div className="mt-6 border-t pt-4">*/}
        {/*      <h3 className="font-medium mb-2">Delivery Address</h3>*/}
        {/*      <p className="text-gray-600">*/}
        {/*        {userInfo.address}, {userInfo.city}, {userInfo.postalCode}*/}
        {/*      </p>*/}
        {/*    </div>*/}
        {/*  </CardContent>*/}
        {/*</Card>*/}

        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center mb-6">
              <div className="bg-[#6E59A5]/10 p-3 rounded-full">
                <UserCircle size={48} className="text-[#6E59A5]"/>
              </div>
              <div>
                <h2 className="text-xl font-semibold">{userInfo.fullName}</h2>
                <p className="text-gray-600">{userInfo.phoneNumber}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Personal Information */}
              <div className="space-y-1">
                <label className="text-sm text-gray-500">Full Name</label>
                <p className="font-medium">{userInfo.name}</p>
              </div>

              <div className="space-y-1">
                <label className="text-sm text-gray-500">Phone Number</label>
                <p className="font-medium">{userInfo.phone}</p>
              </div>

              <div className="space-y-1">
                <label className="text-sm text-gray-500">Email</label>
                <p className="font-medium">{userInfo.email}</p>
              </div>


              <div className="space-y-1">
                <label className="text-sm text-gray-500">City</label>
                <p className="font-medium">{userInfo.city}</p>
              </div>

              {/*<div className="space-y-1">*/}
              {/*  <label className="text-sm text-gray-500">Postal Code</label>*/}
              {/*  <p className="font-medium">{userInfo.referalCode}</p>*/}
              {/*</div>*/}

              {/* Referral Code */}
              {
                userInfo.type === 'AGENT' && (
                      <div className="space-y-1">
                        <label className="text-sm text-gray-500">Referral Code</label>
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{userInfo.referalCode || "ABC123"}</p>
                          <TooltipProvider>
                            <Tooltip open={open} onOpenChange={setOpen}>
                              <TooltipTrigger asChild>
                                <button
                                    onClick={() => handleCopy(userInfo.referalCode || "ABC123")}
                                    className="hover:text-[#6E59A5] transition-colors"
                                >
                                  <Copy size={16}/>
                                </button>
                              </TooltipTrigger>
                              <TooltipContent
                                  className={cn(
                                      copied ? "bg-[#6E59A5] text-white" : "bg-white text-foreground",
                                      "transition-colors"
                                  )}
                              >
                                <p>{copied ? "Copied!" : "Copy code"}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </div>
                      </div>
                  )
              }
            </div>
          </CardContent>
        </Card>


        <div>


          <div className="flex flex-col md:flex-row justify-between items-center md:items-center gap-4 pb-3">
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Package size={20} className="mr-2"/>
              Order History
            </h2>
            {
                userInfo.type === 'AGENT' && (
                    <Button
                        variant="outline"
                        className="border-black text-black hover:bg-red-50"
                        onClick={() => setOpenReferral(true)}
                    >
                      <List
                          size={16} className="mr-2"/>
                      Referral List
                    </Button>
                )}

          </div>

          {loading ? (
                  <Card>
                    <CardContent className="p-6 text-center">
                      <div className="flex justify-center items-center">
                        <div className="loader border-t-[#6E59A5] border-4 w-8 h-8 rounded-full animate-spin"></div>
                        <p className="ml-3">Loading your orders...</p>
                      </div>
                    </CardContent>
                  </Card>
              ) :
              paginatedOrders.length === 0 ? (
            <Card>
              <CardContent className="p-6 text-center">
                <p className="text-gray-500">You haven't placed any orders yet.</p>
                <Button
                  onClick={() => navigate("/order")}
                  className="mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90"
                >
                  Browse Products
                </Button>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order reference</TableHead>
                      <TableHead>Quantity</TableHead>
                      {/*<TableHead>Product</TableHead>*/}
                      <TableHead>Date</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Payment Type</TableHead>
                      {/*<TableHead>Payment Status</TableHead>*/}
                      <TableHead>Status</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedOrders.map((order) => (
                      <TableRow key={order.orderReference}>
                        <TableCell className="font-medium">
                          <div className="flex flex-col">
                            <span>{order.orderReference}</span>
                            {order.orderForOthers && order.recipient && (
                              <span className="text-xs text-gray-500">
                                For: {order.recipient.fullName}
                              </span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{order.binPurchaseItems.length > 1 ? order.binPurchaseItems[0].quantity + order.binPurchaseItems[1].quantity : order.binPurchaseItems[0].quantity}</TableCell>

                        <TableCell>{formattedDate(order.createdAt)}</TableCell>
                        <TableCell>₦{order.expectedAmount.toLocaleString()}</TableCell>

                        <TableCell>
                          {order.paymentPeriod === "3"
                            ? `Installment (${order.paymentPeriod} months)`
                            : "One-off"}
                        </TableCell>
                        {/*<TableCell>*/}
                        {/*  <Badge className={getStatusColor(order.paymentStatus)}>*/}
                        {/*    {order.paymentStatus}*/}
                        {/*  </Badge>*/}
                        {/*</TableCell>*/}
                        <TableCell>
                          <Badge className={getStatusColor(order.status)}>
                            {order.status}
                          </Badge>
                        </TableCell>
                        {/*<TableCell>*/}
                        {/*  /!* Dropdown Menu *!/*/}
                        {/*  <DropdownMenu.Root>*/}
                        {/*    <DropdownMenu.Trigger asChild>*/}
                        {/*      <Button*/}
                        {/*          variant="ghost"*/}
                        {/*          size="sm"*/}
                        {/*          onClick={() => setOrderInfo(order)}*/}
                        {/*          className="text-[#6E59A5] hover:text-[#6E59A5]/90"*/}
                        {/*      >*/}
                        {/*        Action*/}
                        {/*      </Button>*/}
                        {/*    </DropdownMenu.Trigger>*/}
                        {/*    <DropdownMenu.Content*/}
                        {/*        className="bg-white border border-gray-300 rounded-md shadow-lg p-4 space-y-2"*/}
                        {/*    >*/}
                        {/*      /!*<DropdownMenu.Item>*!/*/}
                        {/*      /!*  <div onClick={() => {*!/*/}
                        {/*      /!*    setOrderInfo(order)*!/*/}
                        {/*      /!*    setIsModalOpen(true)*!/*/}
                        {/*      /!*  }} className="text-sm cursor-pointer">*!/*/}
                        {/*      /!*    Repayment*!/*/}
                        {/*      /!*  </div>*!/*/}
                        {/*      /!*</DropdownMenu.Item>*!/*/}
                        {/*    </DropdownMenu.Content>*/}
                        {/*  </DropdownMenu.Root>*/}

                        {/*</TableCell>*/}
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreVertical
                                    className="h-4 w-4"/>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                                 <div onClick={() => {
                                   setOrderInfo(order)
                                  setIsModalOpen(true)
                                }} className="text-sm cursor-pointer">
                                   Repayment
                                 </div>
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                  onClick={() => handleViewDetails(order)}
                                  className="cursor-pointer"
                              >
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                  className="cursor-pointer text-red-600"
                                  // disabled={order.status === 'delivered' || order.status === 'cancelled'}
                                  disabled={true}
                              >
                                Cancel Order
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>

                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <PaginationControls/>

              </div>
            </Card>
          )}
        </div>
      </div>
      {selectedOrder && (
          <OrderDetailsModal
              order={selectedOrder}
              isOpen={!!selectedOrder}
              onClose={() => setSelectedOrder(null)}
          />
      )}
      <RepaymentModal open={isModalOpen} onClose={() => setIsModalOpen(false)} order={orderInfo} handleRepayment={handleRepayment} />
      {
          userInfo.type === 'AGENT' && (
              <ReferralListModal isOpen={operReferral} onClose={() => setOpenReferral(false)}
                                 referrals={userInfo.referrals}/>
          )}
    </div>
  );
};

export default UserAccount;
