
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Copy, Check, Clock } from "lucide-react";
import { toast } from "sonner";
import {useDispatch, useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {clearOrders} from "@/services/constant/actions.ts";

export interface VirtualAccountInfo {
  accountNumber: string;
  bank: string;
  amount: number;
  reference: string;
  expiresIn: string;
}

interface DeliveryInfo {
  address: string;
  city: string;
  postalCode: string;
  orderForOthers: boolean;
  recipient: {
    fullName: string;
    phoneNumber: string;
  } | null;
}

const VirtualPayment = () => {
  const navigate = useNavigate();
  const [virtualAccountInfo, setVirtualAccountInfo] = useState<VirtualAccountInfo | null>(null);
  const [deliveryInfo, setDeliveryInfo] = useState<DeliveryInfo | null>(null);
  const [countdown, setCountdown] = useState(1800); // 30 minutes in seconds
  const [copied, setCopied] = useState<string | null>(null);
  const [paymentType, setPaymentType] = useState("full");
  const [period, setPeriod] = useState("3");
  const dispatch = useDispatch();
  const OrderState = useSelector((state: RootState) => state.orders);
  const {virtualAccount: storedInfo, paymentType: storedPaymentType, delivery: storedDeliveryInfo, installmentPeriod: storedPeriod} = OrderState;
  useEffect(() => {
    // Get virtual account information from localStorage
    if (storedInfo) {
      setVirtualAccountInfo(storedInfo);
    } else {
      // Redirect to order summary if information is not available
      navigate("/order-summary");
    }

    // Get delivery information
    if (storedDeliveryInfo) {
      setDeliveryInfo(storedDeliveryInfo);
    }

    // Get payment type
    if (storedPaymentType) {
      setPaymentType(storedPaymentType);

      if (storedPeriod) {
        setPeriod(storedPeriod);
      }
    }

    // Set up countdown timer
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [navigate]);


  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
    toast.success(`${type} copied to clipboard`);
  };

  const handleCompletePayment = () => {
    dispatch(clearOrders())
    // Store order information in localStorage for demo purposes
    // const orderInfo = {
    //   productName: "Smart Waste Bin",
    //   orderId: `ORD${Math.floor(Math.random() * 10000000)}`,
    //   amount: virtualAccountInfo?.amount || 0,
    //   paymentType: paymentType,
    //   period: paymentType === "installment" ? period : undefined,
    //   status: "paid",
    //   date: new Date().toISOString(),
    //   orderForOthers: deliveryInfo?.orderForOthers || false,
    //   recipient: deliveryInfo?.orderForOthers ? deliveryInfo.recipient : null
    // };
    //
    // const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    // orders.push(orderInfo);
    // localStorage.setItem("orders", JSON.stringify(orders));

    navigate("/account");
  };

  if (!virtualAccountInfo) {
    return <div className="flex justify-center p-8">Loading...</div>;
  }

  return (
    <div className="container mx-auto py-8 px-4">
      {/*<button*/}
      {/*  onClick={() => navigate("/order-summary")}*/}
      {/*  className="text-[#6E59A5] hover:underline mb-4 flex items-center gap-2"*/}
      {/*>*/}
      {/*  ← Back to Order Summary*/}
      {/*</button>*/}

      <div className="max-w-md mx-auto">
        <h1 className="text-2xl font-semibold mb-6 text-center">Complete Your Payment</h1>

        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-medium">Virtual Account</h2>
              <div className="flex items-center text-amber-600">
                <Clock size={16} className="mr-1" />
                <span>{formatTime(countdown)}</span>
              </div>
            </div>

            <p className="text-sm text-gray-500 mb-6">
              Transfer the exact amount to the account details below to complete your order
            </p>

            <div className="space-y-4">
              <div className="border rounded-md p-4 bg-gray-50">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Amount to Pay</p>
                    <p className="text-xl font-semibold">₦{virtualAccountInfo.amount.toLocaleString()}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2"
                    onClick={() => handleCopy(virtualAccountInfo.amount.toString(), "Amount")}
                  >
                    {copied === "Amount" ? <Check size={16} /> : <Copy size={16} />}
                  </Button>
                </div>
              </div>

              <div className="border rounded-md p-4 bg-gray-50">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Account Number</p>
                    <p className="text-xl font-mono font-semibold">{virtualAccountInfo.accountNumber}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2"
                    onClick={() => handleCopy(virtualAccountInfo.accountNumber, "Account Number")}
                  >
                    {copied === "Account Number" ? <Check size={16} /> : <Copy size={16} />}
                  </Button>
                </div>
              </div>

              <div className="border rounded-md p-4 bg-gray-50">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Bank Name</p>
                    <p className="font-medium">{virtualAccountInfo.bank}</p>
                  </div>
                </div>
              </div>

              <div className="border rounded-md p-4 bg-gray-50">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Reference</p>
                    <p className="font-medium font-mono">{virtualAccountInfo.reference}</p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 px-2"
                    onClick={() => handleCopy(virtualAccountInfo.reference, "Reference")}
                  >
                    {copied === "Reference" ? <Check size={16} /> : <Copy size={16} />}
                  </Button>
                </div>
              </div>
            </div>

            <div className="mt-6 text-sm text-gray-500 text-center">
              <p>This account will expire in {virtualAccountInfo.expiresIn}</p>
            </div>
          </CardContent>
        </Card>

        {/* For demo purposes - in a real app this would be handled via webhooks */}
        <div className="text-center">
          <Button
            onClick={handleCompletePayment}
            className="bg-[#6E59A5] hover:bg-[#6E59A5]/90"
          >
            I have made Payment
          </Button>
        </div>
      </div>
    </div>
  );
};

export default VirtualPayment;
