
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const SettingsPage = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">System Settings</h1>

      <Card className="p-6 bg-white shadow mb-6">
        <h2 className="text-lg font-semibold mb-4">General Settings</h2>
        <Separator className="mb-4" />
        
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Company Name
              </label>
              <input 
                type="text" 
                className="w-full p-2 border rounded-md" 
                defaultValue="LAWMA Waste Bin" 
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Contact Email
              </label>
              <input 
                type="email" 
                className="w-full p-2 border rounded-md" 
                defaultValue="contact@lawmawaste.com" 
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Office Address
            </label>
            <textarea 
              className="w-full p-2 border rounded-md" 
              rows={3} 
              defaultValue="123 Main Street, Lagos, Nigeria"
            />
          </div>
          
          <Button className="bg-[#6E59A5] hover:bg-[#6E59A5]/90">
            Save Changes
          </Button>
        </div>
      </Card>

      <Card className="p-6 bg-white shadow">
        <h2 className="text-lg font-semibold mb-4">Product Configuration</h2>
        <Separator className="mb-4" />
        
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                General Waste Bin Price (₦)
              </label>
              <input 
                type="number" 
                className="w-full p-2 border rounded-md" 
                defaultValue="100000" 
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Recyclables Bin Price (₦)
              </label>
              <input 
                type="number" 
                className="w-full p-2 border rounded-md" 
                defaultValue="100000" 
              />
            </div>
          </div>
          
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="fullPaymentDiscount" 
              className="mr-2" 
              defaultChecked
            />
            <label htmlFor="fullPaymentDiscount" className="text-sm font-medium text-gray-700">
              Enable 5% discount for full payment
            </label>
          </div>
          
          <div className="flex items-center">
            <input 
              type="checkbox" 
              id="installmentDiscount" 
              className="mr-2" 
              defaultChecked
            />
            <label htmlFor="installmentDiscount" className="text-sm font-medium text-gray-700">
              Enable 2% discount for 3-month installment plan
            </label>
          </div>
          
          <Button className="bg-[#6E59A5] hover:bg-[#6E59A5]/90">
            Save Configuration
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default SettingsPage;
