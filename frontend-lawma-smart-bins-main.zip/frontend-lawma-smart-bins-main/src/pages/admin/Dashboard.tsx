
import { Card } from "@/components/ui/card";

const AdminDashboard = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Admin Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6 bg-white shadow">
          <h2 className="text-lg font-semibold text-gray-700">Total Users</h2>
          <p className="text-3xl font-bold mt-2">247</p>
        </Card>
        
        <Card className="p-6 bg-white shadow">
          <h2 className="text-lg font-semibold text-gray-700">Orders</h2>
          <p className="text-3xl font-bold mt-2">58</p>
        </Card>
        
        <Card className="p-6 bg-white shadow">
          <h2 className="text-lg font-semibold text-gray-700">Revenue</h2>
          <p className="text-3xl font-bold mt-2">₦4,350,000</p>
        </Card>
      </div>
      
      <div className="mt-8">
        <Card className="p-6 bg-white shadow">
          <h2 className="text-lg font-semibold mb-4">Recent Orders</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr>
                  <th className="py-2 px-4 border-b text-left">Order ID</th>
                  <th className="py-2 px-4 border-b text-left">Customer</th>
                  <th className="py-2 px-4 border-b text-left">Status</th>
                  <th className="py-2 px-4 border-b text-left">Amount</th>
                  <th className="py-2 px-4 border-b text-left">Date</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td className="py-2 px-4 border-b">#12345</td>
                  <td className="py-2 px-4 border-b">John Doe</td>
                  <td className="py-2 px-4 border-b">
                    <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs">Completed</span>
                  </td>
                  <td className="py-2 px-4 border-b">₦100,000</td>
                  <td className="py-2 px-4 border-b">2025-04-20</td>
                </tr>
                <tr>
                  <td className="py-2 px-4 border-b">#12346</td>
                  <td className="py-2 px-4 border-b">Jane Smith</td>
                  <td className="py-2 px-4 border-b">
                    <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs">Pending</span>
                  </td>
                  <td className="py-2 px-4 border-b">₦100,000</td>
                  <td className="py-2 px-4 border-b">2025-04-21</td>
                </tr>
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
