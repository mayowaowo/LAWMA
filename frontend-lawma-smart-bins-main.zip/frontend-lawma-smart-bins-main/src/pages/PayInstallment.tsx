
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Package, Calendar, CreditCard, ArrowLeft } from "lucide-react";
import { toast } from "sonner";

interface Order {
  orderId: string;
  productName: string;
  color?: string;
  amount: number;
  paymentType: string;
  period?: string;
  status: string;
  date: string;
  orderForOthers?: boolean;
  recipient?: {
    fullName: string;
    phoneNumber: string;
  } | null;
  installmentsPaid?: number;
  nextPaymentDate?: string;
}

interface InstallmentHistory {
  paymentDate: string;
  amount: number;
  status: string;
}

const PayInstallment = () => {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(false);
  const [installmentHistory, setInstallmentHistory] = useState<InstallmentHistory[]>([]);
  
  useEffect(() => {
    // Get the order from localStorage
    const orders = JSON.parse(localStorage.getItem("orders") || "[]");
    const foundOrder = orders.find((o: Order) => o.orderId === orderId);
    
    if (foundOrder) {
      // If the order is found, initialize installmentsPaid if it doesn't exist
      if (!foundOrder.installmentsPaid) {
        foundOrder.installmentsPaid = 0;
      }
      
      // Set the next payment date if it doesn't exist
      if (!foundOrder.nextPaymentDate) {
        const initialDate = new Date(foundOrder.date);
        initialDate.setMonth(initialDate.getMonth() + 1);
        foundOrder.nextPaymentDate = initialDate.toISOString();
      }
      
      setOrder(foundOrder);
      
      // Get installment history from localStorage or initialize empty array
      const history = JSON.parse(localStorage.getItem(`installments-${orderId}`) || "[]");
      setInstallmentHistory(history);
    }
  }, [orderId]);
  
  const getTotalAmount = () => {
    if (!order) return 0;
    return order.paymentType === "installment" ? 100000 : order.amount;
  };
  
  const getInitialPayment = () => {
    return order?.paymentType === "installment" ? 20000 : getTotalAmount();
  };
  
  const getRemainingBalance = () => {
    if (!order) return 0;
    const totalAmount = getTotalAmount();
    const initialPayment = getInitialPayment();
    const paidInstallments = installmentHistory.reduce((sum, item) => sum + item.amount, 0);
    
    return totalAmount - initialPayment - paidInstallments;
  };
  
  const getMonthlyPayment = () => {
    if (!order || !order.period) return 0;
    const remainingAfterInitial = getTotalAmount() - getInitialPayment();
    return Math.round(remainingAfterInitial / Number(order.period));
  };
  
  const getInstallmentsRemaining = () => {
    if (!order || !order.period) return 0;
    const installmentsPaid = order.installmentsPaid || 0;
    return Number(order.period) - installmentsPaid;
  };
  
  const handlePayInstallment = () => {
    if (!order) return;
    
    setLoading(true);
    
    // Generate virtual account data for payment
    const monthlyPayment = getMonthlyPayment();
    const virtualAccountData = {
      accountNumber: "202" + Math.floor(Math.random() * 10000000),
      bank: "PayGate Bank",
      amount: monthlyPayment,
      reference: `INST-${orderId}-${Date.now()}`,
      expiresIn: "30 minutes"
    };
    
    // Simulate payment processing
    setTimeout(() => {
      // Update order information
      const orders = JSON.parse(localStorage.getItem("orders") || "[]");
      const orderIndex = orders.findIndex((o: Order) => o.orderId === orderId);
      
      if (orderIndex !== -1) {
        // Increment installments paid
        const installmentsPaid = (orders[orderIndex].installmentsPaid || 0) + 1;
        orders[orderIndex].installmentsPaid = installmentsPaid;
        
        // Update next payment date (one month from now)
        const nextDate = new Date();
        nextDate.setMonth(nextDate.getMonth() + 1);
        orders[orderIndex].nextPaymentDate = nextDate.toISOString();
        
        // If all installments paid, mark as fully paid
        if (installmentsPaid >= Number(orders[orderIndex].period)) {
          orders[orderIndex].status = "paid";
        }
        
        localStorage.setItem("orders", JSON.stringify(orders));
        
        // Update local state
        setOrder(orders[orderIndex]);
        
        // Add payment to installment history
        const newPayment: InstallmentHistory = {
          paymentDate: new Date().toISOString(),
          amount: monthlyPayment,
          status: "paid"
        };
        
        const updatedHistory = [...installmentHistory, newPayment];
        setInstallmentHistory(updatedHistory);
        localStorage.setItem(`installments-${orderId}`, JSON.stringify(updatedHistory));
        
        // Show success message
        toast.success("Installment payment successful!");
        setLoading(false);
        
        // Check if all installments are paid
        if (installmentsPaid >= Number(orders[orderIndex].period)) {
          navigate(`/order-details/${orderId}`);
        }
      }
    }, 2000);
  };
  
  if (!order) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="text-center">
          <p>Order not found.</p>
          <Button 
            onClick={() => navigate("/account")} 
            className="mt-4 bg-[#6E59A5] hover:bg-[#6E59A5]/90"
          >
            Back to My Account
          </Button>
        </div>
      </div>
    );
  }
  
  // If this is not an installment order, redirect to order details
  if (order.paymentType !== "installment") {
    navigate(`/order-details/${orderId}`);
    return null;
  }
  
  // If all installments are paid, show completion message
  if ((order.installmentsPaid || 0) >= Number(order.period)) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="max-w-3xl mx-auto">
          <button
            onClick={() => navigate(`/order-details/${orderId}`)}
            className="text-[#6E59A5] hover:underline mb-4 flex items-center gap-2"
          >
            <ArrowLeft size={16} /> Back to Order Details
          </button>
          
          <Card className="text-center p-6">
            <CardContent>
              <h2 className="text-xl font-semibold text-green-600 mb-4">All Installments Paid!</h2>
              <p className="mb-4">You have successfully completed all payments for this order.</p>
              <Button 
                onClick={() => navigate("/account")} 
                className="bg-[#6E59A5] hover:bg-[#6E59A5]/90"
              >
                Return to Account
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-8 px-4">
      <button
        onClick={() => navigate(`/order-details/${orderId}`)}
        className="text-[#6E59A5] hover:underline mb-4 flex items-center gap-2"
      >
        <ArrowLeft size={16} /> Back to Order Details
      </button>
      
      <div className="max-w-3xl mx-auto space-y-6">
        <h1 className="text-2xl font-semibold">Pay Installment</h1>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="bg-[#6E59A5]/10 p-3 rounded-full">
                <Package className="h-6 w-6 text-[#6E59A5]" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium">Order Information</h3>
                <div className="mt-2 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Order ID:</span>
                    <span>{order.orderId}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Product:</span>
                    <span>{order.productName}</span>
                  </div>
                  {order.color && (
                    <div className="flex justify-between text-sm items-center">
                      <span className="text-gray-500">Color:</span>
                      <div className="flex items-center gap-2">
                        <span className="capitalize">{order.color}</span>
                        <span 
                          className="inline-block w-4 h-4 rounded-full"
                          style={{ backgroundColor: order.color }}
                        ></span>
                      </div>
                    </div>
                  )}
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Total Amount:</span>
                    <span>₦{getTotalAmount().toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <h3 className="font-medium mb-4">Installment Details</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Payment Plan</p>
                  <p className="font-medium">{order.period} months</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Monthly Payment</p>
                  <p className="font-medium">₦{getMonthlyPayment().toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Initial Payment</p>
                  <p className="font-medium">₦{getInitialPayment().toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Remaining Balance</p>
                  <p className="font-medium">₦{getRemainingBalance().toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Installments Paid</p>
                  <p className="font-medium">{order.installmentsPaid || 0} of {order.period}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Next Payment Due</p>
                  <p className="font-medium">{new Date(order.nextPaymentDate || '').toLocaleDateString()}</p>
                </div>
              </div>
              
              <div className="border-t pt-4">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Calendar size={16} />
                  Payment History
                </h4>
                
                {installmentHistory.length === 0 ? (
                  <p className="text-sm text-gray-500">No installment payments yet. You've only made the initial payment.</p>
                ) : (
                  <div className="space-y-2">
                    {installmentHistory.map((payment, index) => (
                      <div key={index} className="flex justify-between items-center text-sm border-b pb-2">
                        <div>
                          <p>Payment #{index + 1}</p>
                          <p className="text-xs text-gray-500">{new Date(payment.paymentDate).toLocaleDateString()}</p>
                        </div>
                        <div className="text-right">
                          <p>₦{payment.amount.toLocaleString()}</p>
                          <p className="text-xs text-green-600">{payment.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <h3 className="font-medium mb-4 flex items-center gap-2">
              <CreditCard size={16} />
              Pay Next Installment
            </h3>
            
            <div className="p-4 bg-gray-50 rounded-md mb-4">
              <p className="font-medium">Installment #{(order.installmentsPaid || 0) + 1}</p>
              <p className="text-sm text-gray-600">Amount: ₦{getMonthlyPayment().toLocaleString()}</p>
            </div>
            
            <Button
              onClick={handlePayInstallment}
              disabled={loading}
              className="w-full bg-[#6E59A5] hover:bg-[#6E59A5]/90"
            >
              {loading ? "Processing..." : `Pay ₦${getMonthlyPayment().toLocaleString()}`}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PayInstallment;
