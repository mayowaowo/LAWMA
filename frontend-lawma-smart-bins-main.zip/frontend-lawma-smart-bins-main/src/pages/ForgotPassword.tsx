
import {useEffect, useState} from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {ArrowLeft, Mail, CheckCircle, Lock, EyeOff, Eye} from "lucide-react";
import {useForgotPassword} from "@/services/api/hooks/ForgotPassword.ts";
import {updateEmailVerification} from "@/services/constant/actions.ts";
import OtpModal from "@/components/OtpModal.tsx";
import {emailVerification, getOtp} from "@/services/api/hooks/Register.ts";
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [passwords, setPasswords] = useState({
    password: "",
    confirmPassword: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [otp, setOtp] = useState('')
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [resetScreen, setResetScreen] = useState(false);
  const {forgotPassword, resetPassword} = useForgotPassword()
  const [countdown, setCountdown] = useState<number>(0)
  const [canResend, setCanResend] = useState<boolean>(false)

  const UserState = useSelector((state: RootState) => state.user);
  const {user} = UserState;
  const PASSWORD_CRITERIA = {
    minLength: 8,
    hasUpperCase: /[A-Z]/,
    hasLowerCase: /[a-z]/,
    hasNumber: /[0-9]/,
    hasSpecialChar: /[!@#$%^&*(),.?":{}|<>]/,
  };

  const handleResendCode = async () => {
    try {
      // Add your resend token API call here
      const res = await getOtp(user.uuid)
      if (res.success) {
        setCountdown(30)
        setCanResend(false)
      }


    } catch (error) {
      console.error('Error resending code:', error)
    }
  }


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email) {
      toast.error("Please enter your email");
      return;
    }

    setIsLoading(true);


    const payload = {
      email: email,
    }

    const {success} = await forgotPassword(payload);
    if (success) {
      // setIsSubmitted(true);
      setResetScreen(true);
      setIsLoading(false);

    }
    setIsLoading(false);

    // Simulate API call for password reset
    // setTimeout(() => {
    //   setIsLoading(false);
    //   setIsSubmitted(true);
    //   toast.success("Reset link sent to your email");
    // }, 1500);
  };

  const handleOtpSubmit = async (otp: string) => {
    // setSubmitLoading(true)
    setResetScreen(true);
    setOtp(otp)
    // const payload = {
    //   uuid: user.uuid,
    //   otp: otp,
    // }
    // const res = await emailVerification(payload, navigate)
    // if (res.success) {
    //   setSubmitLoading(false)
    //   setIsSubmitted(false)
    //   setResetScreen(true);
    // }
    setSubmitLoading(false)

  }

  const handle2ndOtpSubmit = async (otp: string) => {
    setOtp(otp)
    setIsSubmitted(false)

  }

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    const payload = {
      uuid: user.uuid,
      otp: otp,
      password: passwords.password,
      password_confirmation: passwords.confirmPassword,
    }

    const {success, error} = await resetPassword(payload)

    if (success) {
      setIsLoading(false);
      navigate('/login')
    }
    console.log(error, 'error')
    // if (error === 'Invalid OTP provided' || error === 'OTP has expired') {
    //   setIsSubmitted(true)
    // }
    setIsLoading(false);
  }

  const [errors, setErrors] = useState({
    password: '',
    confirmPassword: '',
  });
  const [passwordStrength, setPasswordStrength] = useState(0);

  // Check password strength
  const checkPasswordStrength = (password: string) => {
    let strength = 0;

    if (password.length >= PASSWORD_CRITERIA.minLength) strength++;
    if (PASSWORD_CRITERIA.hasUpperCase.test(password)) strength++;
    if (PASSWORD_CRITERIA.hasLowerCase.test(password)) strength++;
    if (PASSWORD_CRITERIA.hasNumber.test(password)) strength++;
    if (PASSWORD_CRITERIA.hasSpecialChar.test(password)) strength++;

    return strength;
  };

  // Validate passwords on change
  useEffect(() => {
    const validatePasswords = () => {
      const newErrors = {
        password: '',
        confirmPassword: '',
      };

      // Password validation
      if (passwords.password) {
        if (passwords.password.length < PASSWORD_CRITERIA.minLength) {
          newErrors.password = 'Password must be at least 8 characters long';
        } else if (!PASSWORD_CRITERIA.hasUpperCase.test(passwords.password)) {
          newErrors.password = 'Password must contain at least one uppercase letter';
        } else if (!PASSWORD_CRITERIA.hasLowerCase.test(passwords.password)) {
          newErrors.password = 'Password must contain at least one lowercase letter';
        } else if (!PASSWORD_CRITERIA.hasNumber.test(passwords.password)) {
          newErrors.password = 'Password must contain at least one number';
        } else if (!PASSWORD_CRITERIA.hasSpecialChar.test(passwords.password)) {
          newErrors.password = 'Password must contain at least one special character';
        }
      }

      // Confirm password validation
      if (passwords.confirmPassword && passwords.password !== passwords.confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match';
      }

      setErrors(newErrors);
      setPasswordStrength(checkPasswordStrength(passwords.password));
    };

    validatePasswords();
  }, [passwords]);

  // Add this to your existing JSX, right after the password input
  const getStrengthColor = () => {
    switch (passwordStrength) {
      case 0:
        return 'bg-red-500';
      case 1:
        return 'bg-red-400';
      case 2:
        return 'bg-yellow-500';
      case 3:
        return 'bg-yellow-400';
      case 4:
        return 'bg-green-500';
      case 5:
        return 'bg-green-400';
      default:
        return 'bg-gray-200';
    }
  };
  useEffect(() => {
    let timer: NodeJS.Timeout
    if ( countdown > 0) {
      timer = setInterval(() => {
        setCountdown((prev) => prev - 1)
      }, 1000)
    }

    if (countdown === 0) {
      setCanResend(true)
    }

    return () => {
      if (timer) clearInterval(timer)
    }
  }, [countdown])


  if (resetScreen) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-[#F2FCE2] to-white flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">Reset Password</CardTitle>
            <CardDescription>
              Enter the one-time passcode sent to your email, then set your new password.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleResetPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="otp">One Time Passcode</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                  <Input
                      id="otp"
                      type={'text'}
                      placeholder="otp"
                      autoComplete="new-password"
                      value={otp}
                      onChange={(e) => setOtp( e.target.value)}
                      className="pl-10"
                      required
                  />
                </div>
                <div className="flex justify-end items-center">
                  {countdown > 0 ? (
                          <p className="text-sm text-gray-500">
                            Resend code in {countdown}s
                          </p>
                      ) :
                      <button
                      type="button"
                      onClick={handleResendCode}
                      className="text-sm text-[#6E59A5] hover:underline"
                  >
                    Resend passcode?
                  </button>
                  }
                </div>
              </div>
              <div className="space-y-2 !mt-1">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                  <Input
                      id="password"
                      type={showPassword ? 'text' :"password"}
                      autoComplete="new-password"
                      placeholder="password"
                      value={passwords.password}
                      onChange={(e) => setPasswords({...passwords, password: e.target.value})}
                      className="pl-10"
                      required
                  />
                  <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 h-4 w-4 text-gray-400 cursor-pointer hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}
                  </button>
                </div>
                <div className="mt-2">
                  <div className="h-1 w-full bg-gray-200 rounded-full">
                    <div
                        className={`h-1 rounded-full transition-all ${getStrengthColor()}`}
                        style={{width: `${(passwordStrength / 5) * 100}%`}}
                    />
                  </div>
                  {errors.password && (
                      <p className="text-red-500 text-sm mt-1">{errors.password}</p>
                  )}
                </div>

              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                  <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? 'text' : "password"}
                      placeholder="confirm password"
                      autoComplete="new-password"
                      value={passwords.confirmPassword}
                      onChange={(e) => setPasswords({...passwords, confirmPassword: e.target.value})}
                      className="pl-10"
                      required
                  />
                  <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-3 h-4 w-4 text-gray-400 cursor-pointer hover:text-gray-600"
                  >
                    {showConfirmPassword ? <EyeOff size={16}/> : <Eye size={16}/>}
                  </button>
                </div>
                {errors.confirmPassword && (
                    <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>
                )}

              </div>

              <Button
                  type="submit"
                  className="w-full bg-[#6E59A5] hover:bg-[#6E59A5]/90"
                  disabled={isLoading}
              >
                {isLoading ? "Sending..." : "Reset Password"}
              </Button>

              <Button
                  type="button"
                  onClick={() => navigate("/login")}
                  variant="ghost"
                  className="w-full"
              >
                <ArrowLeft className="mr-2 h-4 w-4"/>
                Back to Sign In
              </Button>
            </form>
          </CardContent>
        </Card>
        <OtpModal
            isOpen={isSubmitted}
            onClose={() => {
              setIsSubmitted(false)
            }}
            onSubmit={handle2ndOtpSubmit}
            loading={submitLoading}/>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F2FCE2] to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Reset Password</CardTitle>
          <CardDescription>
            Enter your email to receive a password reset link
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-[#6E59A5] hover:bg-[#6E59A5]/90"
              disabled={isLoading}
            >
              {isLoading ? "Sending..." : "Send verification code"}
            </Button>

            <Button
              type="button"
              onClick={() => navigate("/login")}
              variant="ghost"
              className="w-full"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Sign In
            </Button>
          </form>
        </CardContent>
      </Card>
      <OtpModal
          isOpen={isSubmitted}
          onClose={() => {
            setIsSubmitted(false)
          }}
          onSubmit={handleOtpSubmit}
          loading={submitLoading}/>
    </div>
  );
};

export default ForgotPassword;
