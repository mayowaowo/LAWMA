
export interface BinProduct {
  id: string;
  idType: string;
  name: string;
  price: number;
  description: string;
  features: string[];
}

export interface OrderItem {
  productId: string;
  quantity: number;
  color: "green-general" | "blue-recycle";
}
