
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Index from "./pages/Index";
import Landing from "./pages/Landing";
import NotFound from "./pages/NotFound";
import RegisterForm from "./components/RegisterForm";
import OrderSummary from "./pages/OrderSummary";
import VirtualPayment from "./pages/VirtualPayment";
import OrderConfirmation from "./pages/OrderConfirmation";
import UserAccount from "./pages/UserAccount";
import Login from "./pages/Login";
import ForgotPassword from "./pages/ForgotPassword";
import OrderDetails from "./pages/OrderDetails";
import PayInstallment from "./pages/PayInstallment";

import AdminLayout from "./components/admin/AdminLayout";
import AdminDashboard from "./pages/admin/Dashboard";
import UsersPage from "./pages/admin/Users";
import OrdersPage from "./pages/admin/Orders";
import SettingsPage from "./pages/admin/Settings";
import store from "@/services/store/store.ts";
import {Provider} from "react-redux";
import {ProtectedRoutes} from "@/services/constant/protectedRoutes.tsx";
import SessionWrapper from "@/lib/SessionWrapper.tsx";

const queryClient = new QueryClient();

function App() {
  return (
      <Provider store={store}>
        <SessionWrapper>
          <BrowserRouter>
            <QueryClientProvider client={queryClient}>
              <TooltipProvider>
                <Toaster/>
                <Sonner/>

                <Routes>
                  {/* Admin routes */}
                  <Route path="/admin" element={<AdminLayout><AdminDashboard/></AdminLayout>}/>
                  <Route path="/admin/users" element={<AdminLayout><UsersPage/></AdminLayout>}/>
                  <Route path="/admin/orders" element={<AdminLayout><OrdersPage/></AdminLayout>}/>
                  <Route path="/admin/settings" element={<AdminLayout><SettingsPage/></AdminLayout>}/>


                  <Route path="/login" element={<><Navbar/><Login/></>}/>
                  <Route path="/forgot-password" element={<><Navbar/><ForgotPassword/></>}/>
                  <Route path="/register" element={<><Navbar/><RegisterForm/></>}/>

                  {/* Public routes */}

                  <Route element={<ProtectedRoutes/>}>
                    <Route path="/order" element={<><Navbar/><Index/></>}/>
                    <Route path="/order-summary" element={<><Navbar/><OrderSummary/></>}/>
                    <Route path="/virtual-payment" element={<><Navbar/><VirtualPayment/></>}/>
                    <Route path="/confirmation" element={<><Navbar/><OrderConfirmation/></>}/>
                    <Route path="/account" element={<><Navbar/><UserAccount/></>}/>
                  </Route>
                  <Route path="/" element={<><Navbar/><Landing/></>}/>
                  <Route path="*" element={<><Navbar/><NotFound/></>}/>
                </Routes>
              </TooltipProvider>
            </QueryClientProvider>
          </BrowserRouter>
        </SessionWrapper>
      </Provider>

  );
}

export default App;
