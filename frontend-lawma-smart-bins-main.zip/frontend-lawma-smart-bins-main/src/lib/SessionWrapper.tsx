import React, {useEffect} from "react";
import {useDispatch} from "react-redux";
import {handleLogoutRequest} from "@/services/constant/actions";

interface Props {
    children: React.ReactNode;
}

const SessionWrapper: React.FC<Props> = ({children} : Props) => {
    const dispatch = useDispatch();

    useEffect(() => {
        let timeoutId: NodeJS.Timeout | null = null;

        const resetTimer = () => {
            if (timeoutId) clearTimeout(timeoutId); // Clear existing timer if user is active

            // Set timer for 10 minutes (10 * 60 * 1000)
            timeoutId = setTimeout(() => {
                dispatch(handleLogoutRequest()); // Dispatch logout if user is inactive
                console.log("User logged out due to inactivity.");
            }, 10 * 60 * 1000); // 10 minutes in milliseconds
        }

        // Add event listeners for user activity
        const activityEvents = ["mousemove", "keydown", "click", "scroll"];
        activityEvents.forEach((event) =>
            window.addEventListener(event, resetTimer)
        );

        // Cleanup on unmount
        return () => {
            activityEvents.forEach((event) =>
                window.removeEventListener(event, resetTimer)
            );
            if (timeoutId) clearTimeout(timeoutId);
        };
    }, [dispatch]);

    return <>{children}</>; // Render the children of ReduxWrapper
};

export default SessionWrapper;
