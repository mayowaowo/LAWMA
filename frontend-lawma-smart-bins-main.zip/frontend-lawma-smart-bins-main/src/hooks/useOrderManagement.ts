import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { OrderItem } from "@/types/product";
import { PRODUCTS, calculateDiscount } from "@/config/products";
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {Auth} from "@/services/constant/actionTypes.ts";
import {Address} from "@/services/reducers/orderReducer.ts";

interface UserInfo {
  fullName: string;
  phoneNumber: string;
  address: string;
  city: string;
  postalCode: string;
}

interface DeliveryInfo {
  address: string;
  city: string;
  postalCode: string;
  orderForOthers: boolean;
  recipient: {
    fullName: string;
    phoneNumber: string;
  } | null;
}

export const useOrderManagement = () => {
  const navigate = useNavigate();
  const [userInfo, setUserInfo] = useState({});
  const [deliveryInfo, setDeliveryInfo] = useState<Address | null>(null);
  const [paymentType, setPaymentType] = useState<"ONEOFF" | "INSTALLMENT">("ONEOFF");
  const [period, setPeriod] = useState<string>("3");
  const [loading, setLoading] = useState(false);
  const [selectedColor, setSelectedColor] = useState<"green-general" | "blue-recycle">("green-general");
  const [items, setItems] = useState<OrderItem[]>([]);
  const AuthState = useSelector((state: RootState) => state.auth as Auth);
  const UserState = useSelector((state: RootState) => state.user);
  const {user} = UserState;
  const OrderState = useSelector((state: RootState) => state.orders);
  const {isAuthenticated} = AuthState;
  const {delivery: storedDeliveryInfo, orders: storedItems, installmentPeriod: storedPeriod, color: storedColor, paymentType: storedPaymentType} = OrderState;

  useEffect(() => {

    if (isAuthenticated) {
      setUserInfo(user)
    } else {
      navigate("/register");
    }

    // Get delivery information from localStorage
    if (storedDeliveryInfo) {
      setDeliveryInfo(storedDeliveryInfo);
    }

    // Get payment information from localStorage
    if (storedPaymentType) {
      setPaymentType(storedPaymentType);

      if (storedPeriod) {
        setPeriod(storedPeriod);
      }
    }

    // Get selected color from localStorage
    if (storedColor && (storedColor === "green-general" || storedColor === "blue-recycle")) {
      setSelectedColor(storedColor);
    }

    // Get selected items from localStorage
    if (storedItems) {
      setItems(storedItems);
    } else {
      const defaultItem: OrderItem = {
        productId: "single-bin-general",
        quantity: 1,
        color: "green-general"
      };
      setItems([defaultItem]);
    }

    const storedPaymentMethod = 'transfer';
    if (!storedPaymentMethod) {
      localStorage.setItem("paymentMethod", "transfer");
    }
  }, [navigate]);

  // Calculate totals with discounts and transaction fee
  const baseAmount = items.reduce((total, item) => {
    const product = PRODUCTS.find(p => p.id === item.productId);
    if (product) {
      total += product.price * item.quantity;
    }
    return total;
  }, 0);

  const totalAmount = calculateDiscount(baseAmount, paymentType, paymentType === "INSTALLMENT" ? Number(period) : undefined);

  const initialPayment = paymentType === "INSTALLMENT" ? totalAmount * 0.25 : totalAmount;
  const remainingBalance = totalAmount - initialPayment;
  const monthlyPayment = Math.round(remainingBalance / Number(period));

  return {
    userInfo,
    deliveryInfo,
    paymentType,
    period,
    loading,
    setLoading,
    selectedColor,
    items,
    totalAmount,
    initialPayment,
    remainingBalance,
    monthlyPayment,
    baseAmount
  };
};
