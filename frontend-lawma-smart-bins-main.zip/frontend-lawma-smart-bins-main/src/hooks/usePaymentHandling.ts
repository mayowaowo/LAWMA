
import { useNavigate } from "react-router-dom";
import { OrderItem } from "@/types/product";
import {postOrder} from "@/services/api/services/userService.ts";
import {Address} from "@/services/reducers/orderReducer.ts";
import {useDispatch, useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {clearOrders, handleAddVirtualAccount} from "@/services/constant/actions.ts";
import {toast} from "sonner";
import {useState} from "react";
import {useOrder} from "@/services/api/hooks/order.ts";


interface TransformedItem {
  category: "GENERAL" | "RECYCLABLES";
  quantity: number;
}


interface PaymentHandlingProps {
  items: OrderItem[];
  totalAmount: number;
  paymentType: string;
  period: string;
  deliveryInfo: Address;
  setLoading: (loading: boolean) => void;
}

export const usePaymentHandling = ({
  items,
  totalAmount,
  paymentType,
  period,
  deliveryInfo,

                                   }: PaymentHandlingProps) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const OrderState = useSelector((state: RootState) => state.orders);
  const AuthState = useSelector((state: RootState) => state.auth);
  const {verification} = AuthState;
  const [loading, setLoading] = useState(false);
  const {color, paymentType: paymentTypes, orders, installmentPeriod, delivery } = OrderState
const {submitOrder} = useOrder()
    const transformItems = (items: OrderItem[]): TransformedItem[] => {
    const groupedItems = items.reduce((acc, item) => {
      const category = item.color === "green-general" ? "GENERAL" : "RECYCLABLES";

      const existingItem = acc.find(i => i.category === category);

      if (existingItem) {
        existingItem.quantity += item.quantity;
      } else {
        acc.push({
          category,
          quantity: item.quantity
        });
      }

      return acc;
    }, [] as TransformedItem[]);

    return groupedItems;
  };


  const handleCardPayment = () => {
    const orderId = `ORD-${Date.now()}`;
    const orderData = {
      orderId,
      items,
      amount: totalAmount,
      paymentType,
      period: paymentType === "installment" ? period : undefined,
      status: "processing",
      date: new Date().toISOString(),
      orderForOthers: deliveryInfo?.orderForOthers || false,
      recipient: deliveryInfo?.orderForOthers ? deliveryInfo?.recipient : null,
    };

    const existingOrders = JSON.parse(localStorage.getItem("orders") || "[]");
    const updatedOrders = [...existingOrders, orderData];

    localStorage.setItem("orders", JSON.stringify(updatedOrders));
    localStorage.setItem("currentOrderId", orderId);

    setTimeout(() => {
      navigate("/confirmation");
    }, 1500);
  };

  const handleVirtualAccountPayment = async () => {
        setLoading(true);
    const Payload = {
      color: color,
      bin_purchase: transformItems(items),
      dispatch_address: deliveryInfo.address,
      dispatch_city: deliveryInfo.city,
      dispatch_postal: deliveryInfo.postalCode,
      receiver_name: deliveryInfo.recipient?.fullName || "",
      receiver_phone: deliveryInfo.recipient?.phoneNumber || "",
      save_dispatch_details: true,
      payment_type: paymentTypes,
      postal: deliveryInfo.postalCode,
      amount: totalAmount,
      payment_period: installmentPeriod,
      bvn: verification?.bvn || '',
      nin: verification?.nin || '',
    };


    const {success, results} = await submitOrder(Payload)

        const data = results
        if(success) {
            const virtualAccountData = {
        accountNumber: data.account_number,
        bank: data.bankName,
        amount: data.amountTopay,
        reference: data.reference,
        expiresIn: "30 minutes"
      };
      dispatch(handleAddVirtualAccount(virtualAccountData))
          dispatch(clearOrders())
          setLoading(false);

          navigate("/virtual-payment");
    }

    setLoading(false);


    // const virtualAccountData = {
    //   accountNumber: "202" + Math.floor(Math.random() * 10000000),
    //   bank: "PayGate Bank",
    //   amount: paymentType === "full" ? totalAmount : totalAmount * 0.25,
    //   reference: `REF${Math.floor(Math.random() * 1000000)}`,
    //   expiresIn: "30 minutes"
    // };

    // const orderId = `ORD-${Date.now()}`;
    // const orderData = {
    //   orderId,
    //   items,
    //   amount: virtualAccountData.amount,
    //   paymentType,
    //   period: paymentType === "installment" ? period : undefined,
    //   status: "processing",
    //   date: new Date().toISOString(),
    //   orderForOthers: deliveryInfo?.orderForOthers || false,
    //   recipient: deliveryInfo?.orderForOthers ? deliveryInfo?.recipient : null,
    // };
    //
    // const existingOrders = JSON.parse(localStorage.getItem("orders") || "[]");
    // const updatedOrders = [...existingOrders, orderData];
    //
    // localStorage.setItem("orders", JSON.stringify(updatedOrders));
    // localStorage.setItem("virtualAccountInfo", JSON.stringify(virtualAccountData));
    // localStorage.setItem("currentOrderId", orderId);

  };

  return {
    loading,
    handleCardPayment,
    handleVirtualAccountPayment
  };
};
