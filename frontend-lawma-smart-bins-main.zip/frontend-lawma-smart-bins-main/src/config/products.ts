
import { BinProduct } from "@/types/product";

export const PRODUCTS: BinProduct[] = [
  {
    id: "single-bin-general",
    name: "General Waste Bin",
    idType: 'GENERAL',
    price: 100000,
    description: "Smart waste bin for general waste",
    features: [
      "10-year Warranty",
      "Geotagging Technology",
      "Smooth Rolling Wheels",
      "Withstand Harsh Weather Conditions"
    ]
  },
  {
    id: "single-bin-recycle",
    name: "Recyclables Bin",
    idType: 'RECYCLABLES',
    price: 100000,
    description: "Smart waste bin for recyclable materials",
    features: [
      "10-year Warranty",
      "Geotagging Technology",
      "Smooth Rolling Wheels",
      "Withstand Harsh Weather Conditions"
    ]
  }
];

export const calculateDiscount = (amount: number, paymentType: string, months?: number): number => {
  let discountedAmount = amount;

  if (paymentType === "ONEOFF") {
    // 5% discount for full payment
    discountedAmount = amount * 0.95;
  } else if (paymentType === "INSTALLMENT" && months === 3) {
    // 2% discount for 3-month plan
    // discountedAmount = amount * 0.98;
  }

  // Add 1.25% transaction fee
  return discountedAmount;
};
