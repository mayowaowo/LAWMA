import {Navigate, Outlet} from 'react-router-dom';
import {useSelector} from 'react-redux';
import {RootState} from "@/services/reducers/rootReducer.ts";
import {Auth} from "@/services/constant/actionTypes.ts";


export const ProtectedRoutes = () => {
    const AuthState = useSelector((state: RootState) => state.auth as Auth);
    const {isAuthenticated} = AuthState;
        return (
        isAuthenticated ? <Outlet/> : <Navigate to='/login'/>
    );
};
