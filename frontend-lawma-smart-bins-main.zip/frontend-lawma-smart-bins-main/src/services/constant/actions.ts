import { createAction } from '@reduxjs/toolkit';
import { NavigateFunction } from 'react-router-dom';
import {ForgotPassword, Login, Register, User} from "@/services/constant/actionTypes.ts";
import {OrderItem} from "@/types/product.ts";
import {Address} from "@/services/reducers/orderReducer.ts";
import {VirtualAccountInfo} from "@/pages/VirtualPayment.tsx";
import {verificationPayload} from "@/services/reducers/authReducer.ts";

export const handleLoginRequest = createAction<{
  payload: Login,
  navigate: NavigateFunction,
  onSuccess: () => void
}>('LOGIN_REQUEST');
export const handleLoginSuccess = createAction<{ token: string, email: string }>('LOGIN_SUCCESS');
export const handleLoginFailure = createAction<string>('LOGIN_FAILURE');
export const handleLogoutRequest = createAction('REQUEST_LOGOUT');
export const handleLogout = createAction('LOGOUT');
export const handleRegisterRequest = createAction<{
  payload: Register,
  navigate: NavigateFunction
  onSuccess: () => void
}>('REGISTER_REQUEST');
export const handleRegisterSuccess = createAction<{ token: string }>('REGISTER_SUCCESS');
export const handleSuccess = createAction('SUCCESS');
export const handleStart = createAction('START');
export const handleFailure = createAction('FAILURE');
export const handleForgotPassword = createAction<{ ForgotPassword: ForgotPassword; navigate: () => void }>('FORGOT_PASSWORD');
export const handleSaveVerification = createAction<verificationPayload>('SAVE_VERIFICATION');
export const handleDeleteVerification = createAction('DELETE_VERIFICATION');
export const updateEmailVerification = createAction<boolean>('UPDATE_EMAIL_VERIFICATION');

export const resetOtpState = createAction('RESET_OTP_STATE');

export const handleSaveUserData = createAction<User>('SAVE_USER_DATA');
export const handlePageLoading = createAction<boolean>('PAGE_LOADER');


export const addOrder = createAction<OrderItem[]>('addOrder');
export const clearOrders = createAction('clearOrders');
export const handleSelectedColor = createAction<"green-general" | "blue-recycle">('selectedColor');
export const handleSaveDeliveryAddress = createAction<Address>('addDeliveryAddress');
export const handlePaymentType = createAction<"ONEOFF" | "INSTALLMENT">('paymentType');
export const handleInstallmentPeriod = createAction<string>('installmentPeriod');
export const handleAddVirtualAccount = createAction<VirtualAccountInfo>('addvirtualAccount');


