import { combineReducers } from 'redux';
import authReducer from './authReducer';
import userReducer from './userReducer';
import orderReducer from "@/services/reducers/orderReducer.ts";

const rootReducer = combineReducers({
  auth: authReducer,
  user: userReducer,
  orders: orderReducer
});

export type RootState = ReturnType<typeof rootReducer>;
export default rootReducer;
