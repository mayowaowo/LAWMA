import { createReducer } from '@reduxjs/toolkit';
import {
  addOrder,
  clearOrders, handleAddVirtualAccount, handleInstallmentPeriod,
  handlePaymentType,
  handleSaveDeliveryAddress,
  handleSelectedColor
} from '../constant/actions.ts';
import {OrderItem} from "@/types/product.ts";
import {VirtualAccountInfo} from "@/pages/VirtualPayment.tsx";

type Order = {
  orderId: string;
  items: Array<{ productId: number; quantity: number }>;
  amount: number;
  paymentType: string;
  period?: number | undefined;
  status: string;
  date: string;
  orderForOthers: boolean;
  recipient: string | null;
};

export type Address = {
  address: string;
  city: string;
  postalCode: string;
  orderForOthers: boolean;
  recipient: {
        fullName: string;
        phoneNumber: string;
      } | null;
}

interface OrderState {
  orders: OrderItem[];
  color: "green-general" | "blue-recycle";
  deliveryAddress: Address[]
  delivery: Address
  paymentType: "ONEOFF" | "INSTALLMENT";
  installmentPeriod: string
  virtualAccount: VirtualAccountInfo
}

const initialState: OrderState = {
  orders: [],
  color: "green-general",
  deliveryAddress: [],
  delivery: {
    address: '',
    city: '',
    postalCode: '',
    orderForOthers: false,
    recipient: {
      fullName: '',
      phoneNumber: ''
    }
  },
  paymentType: "ONEOFF",
  installmentPeriod: '',
  virtualAccount: {
    accountNumber: '',
    bank: '',
    amount: 0,
    reference: '',
    expiresIn: ''
  }
};

const orderReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(addOrder, (state, action) => {
      state.orders = action.payload;
    })
    .addCase(clearOrders, (state) => {
      state.orders = [];
    })
  .addCase(handleSelectedColor, (state, action) => {
    state.orders = state.orders.map((item) => ({
      ...item,
      color: action.payload, // Replace color with the new selected color
    }));
    state.color= action.payload;

  })
  .addCase(handleSaveDeliveryAddress, (state, action) => {
    state.deliveryAddress.push(action.payload);
    state.delivery = action.payload;
  })
  .addCase(handlePaymentType, (state, action) => {
      state.paymentType = action.payload;
  })
  .addCase(handleInstallmentPeriod, (state, action) => {
    state.installmentPeriod = action.payload;
  })
.addCase(handleAddVirtualAccount, (state, action) => {
    state.virtualAccount = action.payload;
  });
});

export default orderReducer;
