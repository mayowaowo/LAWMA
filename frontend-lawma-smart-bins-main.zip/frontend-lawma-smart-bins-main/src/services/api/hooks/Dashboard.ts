import {getDashboard} from "@/services/api/services/userService.ts";

export const getDashboardData = async (id: string | number) => {
  let userResponse = null;
  try {
    const response = await getDashboard(id);
    //     userResponse = response;
    if (userResponse) {
      return { success: true, result: response.data.data };
    }
  } catch (e) {
    //     return { success: false, error: e.response?.data?.message };
  }

  return userResponse;
};
