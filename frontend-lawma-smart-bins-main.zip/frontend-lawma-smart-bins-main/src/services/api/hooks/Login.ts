import { Login } from '@/services/constant/actionTypes';
import { NavigateFunction } from 'react-router-dom';
import {postLogin} from "@/services/api/services/authservices.ts";
import {toast} from "sonner";

export const loginUser = async (payload: Login, navigate: NavigateFunction) => {
  let userResponse = null;
  // const { showToast } = useToast();
  try {
    const response = await postLogin(payload);
    userResponse = response?.data?.status;
        if (userResponse) {
      const access_token = response?.data?.data?.token;
            // console.log('kkdkdk', access_token)
      navigate('/order');
      return { success: true, data: access_token, user: response?.data?.data?.user };
    } else  {
            toast.error(response.data.message);

        }
  } catch (e) {
        // showToast('Error', e.response.data.message, 'error');
    toast.error(e.response.data.message);

    return { success: false, error: e.response.data.message };
  }

  return userResponse;
};

