import {useRef, useState} from "react";
import {useDispatch} from "react-redux";
import {getOrderHistory, postOrder, postRepayment} from "@/services/api/services/userService.ts";
import {toast} from "sonner";

export const useOrder  = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const didFetch = useRef<boolean>(false);
    const [orderHistory, setOrderHistory] = useState([]);
    const dispatch = useDispatch();
    const getOrderHistories = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getOrderHistory();
                        userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setOrderHistory(userResponse[0].data)
                return {success: true, results: userResponse};
            }
        } catch (e) {
                        setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const submitOrder = async (payload) => {
        let userResponse = null;
        // setLoading(true);
        try {
            const response = await postOrder(payload);
            userResponse = response?.data?.data;
            setLoading(false);

            // console.log(userResponse);
            if (response.data.status) {
                setLoading(false);
                // setOrderHistory(userResponse[0].data)
                return {success: true, results: userResponse[0]};
            }
            else {
                toast.error(response.data.message);

                return {success: false};
            }
        } catch (e) {
            setLoading(false);
            toast.error(e.response.data.message);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };


    const repaymentHistory = async (payload) => {
        let userResponse = null;
        // setLoading(true);
        try {
            const response = await postRepayment(payload);
                        userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setOrderHistory(userResponse[0].data)
                return {success: true, results: userResponse};
            }
        } catch (e) {
                        setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };


    return {getOrderHistories, orderHistory, loading, repaymentHistory, submitOrder}
}
