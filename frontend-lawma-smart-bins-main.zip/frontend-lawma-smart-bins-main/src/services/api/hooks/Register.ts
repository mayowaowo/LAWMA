import {getResendOtp, postEmailVerification, postRegister} from '../services/authservices';
import { NavigateFunction } from 'react-router-dom';
import {Register} from "@/services/constant/actionTypes.ts";
import {toast} from "sonner";
import store from "@/services/store/store.ts";

export const registerUser = async (payload: Register, navigate: NavigateFunction) => {
  let userResponse = null;

  try {
    const response = await postRegister(payload);
      // console.log(response);
        userResponse = response?.data?.data[0];
    if (response.data.status) {
            const { uuid } = userResponse;
      toast.success('Registration Successful!');

      // navigate('/account')
      return { success: true, data: uuid, user: userResponse };
    } else {
        toast.error(response.data.message);
        return {success: false, error: response.data.message};

    }
  } catch (e) {
    const allErrors = e?.response?.data?.errors;
    const firstError = allErrors ? Object.values(allErrors).find(error => error) : e.response.data.message;
        toast.error(firstError);

    return { success: false, error: firstError };
  }

  return userResponse;
};

export const getOtp = async (uuid) => {
  let userResponse = null;

  try {
    const response = await getResendOtp(uuid);
        userResponse = response?.data?.data[0];
    if (userResponse) {
      toast.success('Otp Sent Successful!');

      // navigate('/account')
      return {success: true, data: uuid, user: userResponse};
    }
  } catch (e) {
    const allErrors = e?.response?.data?.errors;
    const firstError = allErrors ? Object.values(allErrors).find(error => error) : e.response.data.message;
        return {success: false, error: firstError};
  }

  return userResponse;
};
const stores = store.getState()

export const emailVerification = async (payload, navigate: NavigateFunction, source?: 'register' | 'login'
) => {
  let userResponse = null;

  try {
    const response = await postEmailVerification(payload);
        userResponse = response?.data?.status;
    if (userResponse) {
      const {uuid} = userResponse;
      navigate('/login')

      // if (source === 'register') {
      //   navigate('/login');
      // } else if (source === 'login') {
      //   navigate('/order'); // or whatever your reset password route is
      // } else {
      //   navigate('/login'); // default fallback
      // }

      toast.success(response.data.message);

      return {success: true, data: uuid, user: userResponse};
    } else {
        toast.error(response.data.message);

    }
  } catch (e) {
    const allErrors = e?.response?.data?.message;
    const firstError = allErrors ? Object.values(allErrors).find(error => error) : e.response.data.message;
        toast.error(allErrors);

    return {success: false, error: firstError};
  }

  return userResponse;
};
