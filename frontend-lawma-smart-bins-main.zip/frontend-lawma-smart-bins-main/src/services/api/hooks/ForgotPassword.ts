import {postForgottenPassword, postResetPassword} from "@/services/api/services/authservices.ts";
import {toast} from "sonner";
import {useState} from "react";
import {useDispatch} from "react-redux";
import {handleSaveUserData} from "@/services/constant/actions.ts";

export const useForgotPassword = () => {
    const [isLoading, setIsLoading] = useState(false);
    const dispatch = useDispatch();
    const forgotPassword = async (payload) => {
        try {
            setIsLoading(true);
            const res = await postForgottenPassword(payload)
            if (res.data.data) {
                const userResponse = res.data.data[0];
                setIsLoading(false);
                dispatch(handleSaveUserData(userResponse));
                toast.success("Otp sent to Your Email");
                return {success: true, data: res.data.data}
            } else {
                setIsLoading(false);

                return {success: false, data: res.data.data}
            }
        } catch (error) {
            console.log(error)
            setIsLoading(false);
            toast.error(error.response.data.message);

            setIsLoading(false);
            return {success: false}
        }
    }

    const resetPassword = async (payload) => {
        try {
            setIsLoading(true);
            const res = await postResetPassword(payload)
            console.log(res, 'hhh')
            if (res.data.data) {
                const userResponse = res.data.data[0];
                setIsLoading(false);
                dispatch(handleSaveUserData(userResponse));
                toast.success("Password reset successfully");
                return {success: true, data: res.data.data}
            } else {
                setIsLoading(false);
                return {success: false, data: res.data.data}
            }
        } catch (error) {
            console.log(error)
            setIsLoading(false);
            const allErrors = error?.response?.data?.message;
            const firstError = allErrors ? Object.values(allErrors).find(error => error) : error.response.data.message;
            toast.error(allErrors);
            setIsLoading(false);
            return {success: false, error: allErrors }

        }
    }


    return {forgotPassword, isLoading, resetPassword};
}
