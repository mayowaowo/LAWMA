import {GET_DASHBOARD, ORDER, ORDER_HISTORY, REPAYMENT_ORDER} from "@/services/api/constant/service-routes.ts";
import {authorized, unauthorized} from "@/services/api/constant/axios.ts";
import {OrderPayload} from "@/services/constant/actionTypes.ts";

export const getDashboard = (id: string | number) => {
  return unauthorized.get(`${GET_DASHBOARD}/${id}`);
};

export const postOrder = (payload) => {
  return authorized.post(ORDER, payload);
};


export const getOrderHistory = () => {
  return authorized.get(ORDER_HISTORY);
};

export const postRepayment = (payload) => {
  return authorized.post(REPAYMENT_ORDER, payload);
};
