import {unauthorized} from "@/services/api/constant/axios.ts";
import {
  EMAIL_VERIFICATION,
  FORGOT_PASSWORD,
  LOGIN,
  REGISTER,
  RESEND_OTP, RESET_PASSWORD
} from "@/services/api/constant/service-routes.ts";
import {Login} from "@/services/constant/actionTypes.ts";
import ForgotPassword from "@/pages/ForgotPassword.tsx";
import {Register} from "@tanstack/react-query";


export const postLogin = (payload: Login) => {
  return unauthorized.post(LOGIN, payload);
};

export const postRegister = (payload: Register) => {
  return unauthorized.post(REGISTER, payload);
};


export const getResendOtp = (uuid) => {
  return unauthorized.get(`${RESEND_OTP}/${uuid}`);
};


export const postEmailVerification = (payload) => {
  return unauthorized.post(EMAIL_VERIFICATION, payload);
};

// export const postVerifyOtp = (payload: Otp) => {
//   return unauthorized.post(REGISTER_VERIFY_OTP, payload);
// };

export const postForgottenPassword = (payload) => {
  return unauthorized.post(FORGOT_PASSWORD, payload);
};

export const postResetPassword = (payload) => {
  return unauthorized.post(RESET_PASSWORD, payload);
};
