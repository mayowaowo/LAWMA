import { call, put, takeLatest } from 'redux-saga/effects';
import { NavigateFunction } from 'react-router-dom';
import { PayloadAction } from '@reduxjs/toolkit';
import { purgeStoredState } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import {Login, Otp, Register} from '../constant/actionTypes';
import {
  clearOrders,
  handleFailure, handleLoginRequest,
  handleLoginSuccess,
  handleLogout, handleLogoutRequest, handleRegisterRequest,
  handleRegisterSuccess,
  handleSaveUserData, updateEmailVerification
} from '../constant/actions';
import {emailVerification, registerUser} from "@/services/api/hooks/Register.ts";
import {loginUser} from "@/services/api/hooks/Login.ts";
import {toast} from "sonner";

function* login(action: PayloadAction<{ payload: Login, navigate: NavigateFunction, onSuccess: () => void }>) {
  try {
    const { payload, navigate, onSuccess } = action.payload;
    const { success, data, error, user } = yield call(
      loginUser,
      payload,
      navigate,
    );

      // console.log(success, user);
    if (success && user) {
        console.log(user);
      const email = user.email;
      const token = data;
      yield put(handleSaveUserData(user));
      yield put(handleLoginSuccess({token, email}));

      if (user.emailVerification) {
        yield call(onSuccess); // Call the navigation callback

      } else {
        yield put(updateEmailVerification(true));

      }

      // const { success: success1 } = yield call(
      //   getDashboardData,
      //   user[0].id,
      // );

      // yield put(showToast('Success', 'Login successful!', 'success'));

    } else {
            yield put(handleFailure(error));
      // yield put(showToast('Error', error, 'error'));
    }
  } catch (error) {
        console.log(
      'Auth saga error:',
      error.response?.data.message || error.message,
    );
    yield put(
      handleFailure(error.response?.data?.message || error.message),
    );
  }
}

function* register(action: PayloadAction<{ payload: Register, navigate: NavigateFunction, onSuccess: () => void

}>) {
  try {
    const { payload, navigate, onSuccess } = action.payload;
    const { success, data, error, user } = yield call(
      registerUser,
      payload,
      navigate,
    );
        if (success) {
      const token = data;
      const email = user.email;
      yield put(handleRegisterSuccess({ token }));
      yield put(handleSaveUserData(user));
      yield put(handleLoginSuccess({ token, email }));
      yield call(onSuccess); // Call the navigation callback

      // yield put(toast.success("Registration successful!"))

      // yield put(showToast('Success', 'Registration successful!', 'success'));
    } else {
      yield put(handleFailure(error));
      // yield put(showToast('Error', error, 'error'));
    }
  } catch (error) {
    console.log(
      'Auth saga error:',
      error.response?.data.message || error.message,
    );
    yield put(
      handleFailure(error.response?.data?.message || error.message),
    );
  }
}


function* logout() {
  try {
    yield purgeStoredState({
      key: 'root',
      storage,
    });
    // Clear all localStorage items
    yield call(clearOrders)
    localStorage.clear();

    yield put(handleLogout());
  } catch (error) {
    console.error('Error deleting token', error);
  }
}

function* watchAuthActions() {
  yield takeLatest(handleLoginRequest, login);
  yield takeLatest(handleRegisterRequest, register);
  yield takeLatest(handleLogoutRequest, logout);
}
export default watchAuthActions;
