import {defineConfig} from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import {componentTagger} from "lovable-tagger";
import svgr from 'vite-plugin-svgr';

export default defineConfig(({mode}) => ({
    server: {
        host: "::",
        port: 8080,
    },
    plugins: [
        react(),
        svgr({
            include: "**/*.svg",
            svgrOptions: {
                icon: true,
                exportType: "named",
                ref: true,
                titleProp: true,
            },
        }),
        mode === 'development' && componentTagger(),
    ].filter(Boolean),
    resolve: {
        alias: {
            "@": path.resolve(__dirname, "./src"),
        },
    },
}));
