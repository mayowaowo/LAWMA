import { useEffect, useState } from "react";
import { format } from 'date-fns';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle
} from "@/components/ui/card";
import {
    Activity,
    Search,
    Filter,
    MoreVertical,
    ChevronLeft,
    ChevronRight,
    User
} from "lucide-react";
import { ActivityLog, useActivityLogs } from "@/services/api/hooks/ActivityLog";
import ActivityDetailsModal from "./orders/ActivityDetailsModal";

const ActivityLogTableSkeleton = () => {
    return (
        <Card>
            <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    <span>Activity Log</span>
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="mb-4 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div className="relative w-full md:w-64">
                        <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                        <div className="h-10 bg-gray-200 rounded-md animate-pulse" />
                    </div>

                    <div className="flex flex-col gap-2 md:flex-row">
                        <div className="h-10 w-[180px] bg-gray-200 rounded-md animate-pulse" />
                    </div>
                </div>

                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>ID</TableHead>
                                <TableHead>User</TableHead>
                                <TableHead>Action</TableHead>
                                <TableHead>Description</TableHead>
                                <TableHead>Resource</TableHead>
                                <TableHead className="hidden md:table-cell">IP Address</TableHead>
                                <TableHead className="hidden md:table-cell">Date</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {[...Array(5)].map((_, index) => (
                                <TableRow key={index}>
                                    <TableCell>
                                        <div className="h-4 w-8 bg-gray-200 rounded animate-pulse" />
                                    </TableCell>

                                    <TableCell>
                                        <div className="space-y-2">
                                            <div className="h-4 w-32 bg-gray-200 rounded animate-pulse" />
                                            <div className="h-3 w-24 bg-gray-200 rounded animate-pulse" />
                                        </div>
                                    </TableCell>

                                    <TableCell>
                                        <div className="h-4 w-24 bg-gray-200 rounded animate-pulse" />
                                    </TableCell>

                                    <TableCell>
                                        <div className="h-4 w-48 bg-gray-200 rounded animate-pulse" />
                                    </TableCell>

                                    <TableCell>
                                        <div className="h-4 w-20 bg-gray-200 rounded animate-pulse" />
                                    </TableCell>

                                    <TableCell className="hidden md:table-cell">
                                        <div className="h-4 w-24 bg-gray-200 rounded animate-pulse" />
                                    </TableCell>

                                    <TableCell className="hidden md:table-cell">
                                        <div className="h-4 w-24 bg-gray-200 rounded animate-pulse" />
                                    </TableCell>

                                    <TableCell className="text-right">
                                        <div className="h-8 w-8 bg-gray-200 rounded float-right animate-pulse" />
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
    );
};

const ActivityLogTable = () => {
    const [searchTerm, setSearchTerm] = useState("");
    const [userTypeFilter, setUserTypeFilter] = useState("all");
    const [actionFilter, setActionFilter] = useState("all");
    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 10;

    const [selectedActivity, setSelectedActivity] = useState<ActivityLog | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const { loading, activityLogs, fetchActivityLogs, refreshActivityLogs } = useActivityLogs();

    useEffect(() => {
        fetchActivityLogs();
    }, [fetchActivityLogs]);

    const safeActivityLogs = Array.isArray(activityLogs) && activityLogs.length > 0 && Array.isArray(activityLogs[0])
        ? activityLogs[0]
        : Array.isArray(activityLogs)
            ? activityLogs
            : [];

    // const safeActivityLogs = Array.isArray(activityLogs) ? activityLogs : [];


    const filteredActivities = safeActivityLogs.filter(activity => {
        if (!activity?.user) return false;

        const searchMatch =
            activity.user.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            activity.user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            activity.action?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            activity.description?.toLowerCase().includes(searchTerm.toLowerCase());

        const userTypeMatch = userTypeFilter === 'all' || activity.user.type === userTypeFilter;
        const actionMatch = actionFilter === 'all' || activity.action?.toLowerCase().includes(actionFilter.toLowerCase());

        return searchMatch && userTypeMatch && actionMatch;
    });

    const totalPages = Math.ceil(filteredActivities.length / ITEMS_PER_PAGE);

    const paginatedActivities = filteredActivities.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    );

    const handleViewDetails = (activity: ActivityLog) => {
        setSelectedActivity(activity);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setSelectedActivity(null);
    };

    const handlePageChange = (pageNumber: number) => {
        setCurrentPage(pageNumber);
    };

    const PaginationControls = () => {
        return (
            <div className="flex items-center justify-between px-2 py-4">
                <div className="text-sm text-muted-foreground">
                    Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, filteredActivities.length)} of {filteredActivities.length} entries
                </div>
                <div className="flex items-center space-x-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                    >
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                    </Button>
                    <div className="flex items-center space-x-1">
                        {[...Array(totalPages)].map((_, index) => (
                            <Button
                                key={index + 1}
                                variant={currentPage === index + 1 ? "default" : "outline"}
                                size="sm"
                                onClick={() => handlePageChange(index + 1)}
                            >
                                {index + 1}
                            </Button>
                        ))}
                    </div>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                    >
                        Next
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </div>
        );
    };

    const getUserTypeColor = (type: string) => {
        switch (type) {
            case 'ADMIN':
                return 'bg-purple-100 text-purple-800 hover:bg-purple-200';
            case 'USER':
                return 'bg-blue-100 text-blue-800 hover:bg-blue-200';
            default:
                return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
        }
    };

    const getActionColor = (action: string) => {
        if (!action) return 'bg-gray-100 text-gray-800 hover:bg-gray-200';

        if (action.toLowerCase().includes('create')) {
            return 'bg-green-100 text-green-800 hover:bg-green-200';
        } else if (action.toLowerCase().includes('edit')) {
            return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
        } else if (action.toLowerCase().includes('delete')) {
            return 'bg-red-100 text-red-800 hover:bg-red-200';
        } else {
            return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
        }
    };

    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, userTypeFilter, actionFilter]);

    if (loading) {
        return <ActivityLogTableSkeleton />;
    }

    return (
        <>
            <Card>
                <CardHeader className="pb-2">
                    <CardTitle className="text-xl flex items-center gap-2">
                        <Activity className="h-5 w-5" />
                        <span>Activity Log</span>
                    </CardTitle>
                </CardHeader>

                <CardContent>
                    <div className="mb-4 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                        <div className="relative w-full md:w-64">
                            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input
                                placeholder="Search activities..."
                                className="pl-8"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </div>

                        <div className="flex flex-col gap-2 md:flex-row">
                            <div className="flex items-center gap-2 border border-gray-100 hover:border-gray-300 px-4 rounded-md py-2">
                                <button onClick={refreshActivityLogs}>Refresh</button>
                            </div>
                        </div>
                    </div>

                    <div className="rounded-md border">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>ID</TableHead>
                                    <TableHead>User</TableHead>
                                    <TableHead>Action</TableHead>
                                    <TableHead>Description</TableHead>
                                    <TableHead>Resource</TableHead>
                                    <TableHead className="hidden md:table-cell">IP Address</TableHead>
                                    <TableHead className="hidden md:table-cell">Date</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {paginatedActivities.length > 0 ? (
                                    paginatedActivities.map((activity) => (
                                        <TableRow key={activity.id}>
                                            <TableCell className="font-medium">{activity.id}</TableCell>
                                            <TableCell>
                                                <div className="flex items-center gap-2">
                                                    <div className="flex items-center justify-center h-8 w-8 rounded-full bg-gray-100">
                                                        <User className="h-4 w-4 text-gray-500" />
                                                    </div>
                                                    <div>
                                                        <div>{activity.user.name}</div>
                                                        <div className="text-xs text-gray-500">{activity.user.email}</div>
                                                    </div>
                                                </div>
                                            </TableCell>
                                            <TableCell>
                                                <Badge variant="outline" className={`${getActionColor(activity.action)}`}>
                                                    {activity.action}
                                                </Badge>
                                            </TableCell>
                                            <TableCell>{activity.description}</TableCell>
                                            <TableCell>
                                                <Badge variant="outline">
                                                    {activity.resource.split('\\').pop()}
                                                </Badge>
                                            </TableCell>
                                            <TableCell className="hidden md:table-cell">{activity.ip_address}</TableCell>
                                            <TableCell className="hidden md:table-cell">
                                                {format(new Date(activity.created_at), 'yyyy-MM-dd HH:mm')}
                                            </TableCell>
                                            <TableCell className="text-right">
                                                <DropdownMenu>
                                                    <DropdownMenuTrigger asChild>
                                                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                                            <span className="sr-only">Open menu</span>
                                                            <MoreVertical className="h-4 w-4" />
                                                        </Button>
                                                    </DropdownMenuTrigger>
                                                    <DropdownMenuContent align="end">
                                                        <DropdownMenuItem
                                                            className="cursor-pointer"
                                                            onClick={() => handleViewDetails(activity)}
                                                        >
                                                            View Details
                                                        </DropdownMenuItem>
                                                    </DropdownMenuContent>
                                                </DropdownMenu>
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={8} className="h-24 text-center">
                                            No activities found.
                                        </TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                        {filteredActivities.length > 0 && <PaginationControls />}
                    </div>
                </CardContent>
            </Card>

            <ActivityDetailsModal
                activity={selectedActivity}
                isOpen={isModalOpen}
                onClose={handleCloseModal}
            />
        </>
    );
};

export default ActivityLogTable;