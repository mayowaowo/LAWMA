import {useState, } from 'react'
import {Dialog, DialogContent, DialogHeader, DialogTitle} from "@/components/ui/dialog"
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {Avatar, AvatarFallback, AvatarImage} from "@/components/ui/avatar.tsx";
import {format} from "date-fns";

interface OtpModalProps {
    isOpen: boolean
    onClose: () => void
}

const DetailColumn = ({label, value}: { label: string; value: React.ReactNode }) => (
    <div className="py-3 ">
        <span className="font-medium text-gray-500">{label}</span>
        <div className="col-span-2 text-sm pt-1">{value}</div>
    </div>
);

const ProfileModal = ({isOpen, onClose}: OtpModalProps) => {
    const UserState = useSelector((state: RootState) => state.user);
    const {user} = UserState;
    console.log(user);

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="sm:max-w-md">
                <DialogHeader>
                </DialogHeader>

                <div className="flex flex-col items-center space-y-6">
                    <Avatar className="h-16 w-16">
                        <AvatarImage src={user?.avatar} alt={user?.name}/>
                        <AvatarFallback>{user?.name.charAt(0)}</AvatarFallback>
                    </Avatar>

                    <div className="grid grid-cols-2 gap-4 mb-4 w-full">
                        <DetailColumn
                            label="Full Name"
                            value={user?.name || 'N/A'}
                        />
                        <DetailColumn
                            label="Email"
                            value={user?.email || 'N/A'}
                        />
                        <DetailColumn
                            label="Roles"
                            value={user?.role || 'N/A'}
                        />
                    </div>


                </div>
            </DialogContent>
        </Dialog>
    )
}

export default ProfileModal
