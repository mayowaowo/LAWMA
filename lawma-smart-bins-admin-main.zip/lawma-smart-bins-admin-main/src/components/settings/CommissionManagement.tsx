
import {useEffect, useState} from 'react';
import { useToast } from "@/hooks/use-toast";
import { Agent } from "@/utils/types";
import { agents as mockAgents } from "@/utils/mockData";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {ChevronLeft, ChevronRight, Edit, Loader2, Save} from "lucide-react";
import {useSettings} from "@/services/api/hooks/settings.ts";

const CommissionManagementSkeleton = () => {
  const skeletonRows = Array(5).fill(null);

  return (
      <Card className="mb-6">
        <CardHeader>
          <div className="h-8 w-48 bg-gray-200 animate-pulse rounded-md"/>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>
                    <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"/>
                  </TableHead>
                  <TableHead>
                    <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"/>
                  </TableHead>
                  <TableHead>
                    <div className="h-4 w-32 bg-gray-200 animate-pulse rounded"/>
                  </TableHead>
                  <TableHead className="text-right">
                    <div className="h-4 w-20 bg-gray-200 animate-pulse rounded ml-auto"/>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {skeletonRows.map((_, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <div className="h-6 w-32 bg-gray-200 animate-pulse rounded"/>
                      </TableCell>
                      <TableCell>
                        <div className="h-6 w-24 bg-gray-200 animate-pulse rounded"/>
                      </TableCell>
                      <TableCell>
                        <div className="h-6 w-28 bg-gray-200 animate-pulse rounded"/>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="h-8 w-24 bg-gray-200 animate-pulse rounded ml-auto"/>
                      </TableCell>
                    </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
  );
};

const CommissionManagement = () => {
  const [agents, setAgents] = useState<Agent[]>(mockAgents);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editValue, setEditValue] = useState<number>(0);
  const { toast } = useToast();

  const handleEditClick = (agent, index) => {
    setEditingId(index);
    setEditValue(agent.rate);
  };

  const handleSave = async (agentId: string) => {

    const payload = {
      rate: editValue,
    }
    const res = await editCommission(agentId, payload)

    if (res.success) {
      setEditingId(null);

      toast({
        title: "Commission rate updated",
        description: "The agent's commission rate has been successfully updated.",
      });
      await getAllCommissions()

    }

  };

  const formatNaira = (amount: number) => {
    return new Intl.NumberFormat('en-NG', {
      style: 'currency',
      currency: 'NGN',
    }).format(amount);
  };

  const {getAllCommissions, commissionHistory, loading, editCommission, editLoading} = useSettings()
  // console.log(commissionHistory, 'commissionHistory')
  // Add these constants outside the component
  const ITEMS_PER_PAGE = 10;

  // Inside the OrdersTable component, add these state variables
  const [currentPage, setCurrentPage] = useState(1);

  // Add this function to handle page changes
  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };
  const totalPages = Math.ceil(commissionHistory.length / ITEMS_PER_PAGE);
  // Calculate paginated orders
  const paginatedOrders = commissionHistory.slice(
      (currentPage - 1) * ITEMS_PER_PAGE,
      currentPage * ITEMS_PER_PAGE
  );

  const PaginationControls = () => {
    return (
        <div className="flex items-center justify-between px-2 py-4">
          <div className="text-sm text-muted-foreground">
            Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, commissionHistory.length)} of {commissionHistory.length} entries
          </div>
          <div className="flex items-center space-x-2">
            <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4"/>
              Previous
            </Button>
            <div className="flex items-center space-x-1">
              {[...Array(totalPages)].map((_, index) => (
                  <Button
                      key={index + 1}
                      variant={currentPage === index + 1 ? "default" : "outline"}
                      size="sm"
                      onClick={() => handlePageChange(index + 1)}
                  >
                    {index + 1}
                  </Button>
              ))}
            </div>
            <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
            >
              Next
              <ChevronRight className="h-4 w-4"/>
            </Button>
          </div>
        </div>
    );
  };
  useEffect(() => {
    getAllCommissions()
  }, []);

  if (loading) {
    return <CommissionManagementSkeleton/>;
  }


  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>Commission Rates</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Agent Name</TableHead>
                <TableHead>Referral Code</TableHead>
                <TableHead>Commission Rate</TableHead>
                {/*<TableHead className="text-right">Actions</TableHead>*/}
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedOrders.map((agent, index) => (
                <TableRow key={index}>
                  <TableCell>{agent.agent_name}</TableCell>
                  <TableCell>{agent.referral_code}</TableCell>
                  <TableCell>
                    {editingId === index ? (
                      <Input
                        type="number"
                        value={editValue}
                        onChange={(e) => setEditValue(Number(e.target.value))}
                        className="w-32"
                      />
                    ) : (
                      formatNaira(agent.rate)
                    )}
                  </TableCell>
                  {/*<TableCell className="text-right">*/}
                  {/*  {editingId === index ? (*/}
                  {/*    <Button*/}
                  {/*      variant="ghost"*/}
                  {/*      size="sm"*/}
                  {/*      onClick={() => handleSave(agent.id)}*/}
                  {/*    >*/}
                  {/*      {editLoading ? (*/}
                  {/*          <div className="flex items-center gap-2">*/}
                  {/*            <Loader2 className="h-4 w-4 animate-spin"/>*/}
                  {/*            <span>Saving...</span>*/}
                  {/*          </div>*/}
                  {/*      ) : (*/}
                  {/*          <div className="flex items-center gap-2">*/}
                  {/*            <Save className="h-4 w-4 mr-2"/>*/}
                  {/*            <span>Save</span>*/}
                  {/*          </div>*/}
                  {/*      )}*/}
                  {/*    </Button>*/}
                  {/*  ) : (*/}
                  {/*    <Button*/}
                  {/*      variant="ghost"*/}
                  {/*      size="sm"*/}
                  {/*      onClick={() => handleEditClick(agent, index)}*/}
                  {/*    >*/}
                  {/*      <Edit className="h-4 w-4 mr-2" />*/}
                  {/*      Edit Rate*/}
                  {/*    </Button>*/}
                  {/*  )}*/}
                  {/*</TableCell>*/}
                </TableRow>
              ))}
            </TableBody>
          </Table>
          <PaginationControls />
        </div>
      </CardContent>
    </Card>
  );
};

export default CommissionManagement;
