
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Bin } from "@/utils/mockData/types";
import BinForm from "./BinForm";

interface EditBinDialogProps {
  isOpen: boolean;
  onOpenChange: (value: boolean) => void;
  selectedBin: Partial<Bin>;
  onEdit: (bin: Partial<Bin>) => void;
  onChange: (bin: Partial<Bin>) => void;
  validationErrors: Record<string, string>;
}

const EditBinDialog = ({
  isOpen,
  onOpenChange,
  selectedBin,
  onEdit,
  onChange,
  validationErrors
}: EditBinDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Bin Type</DialogTitle>
        </DialogHeader>
        <BinForm
            bin={selectedBin}
            onSubmit={onEdit}
            onChange={onChange}
            mode="edit"
            validationErrors={validationErrors} loading={false}        />
      </DialogContent>
    </Dialog>
  );
};

export default EditBinDialog;
