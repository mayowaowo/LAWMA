
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Boxes } from 'lucide-react';
import BinTable from './BinTable';
import BinActions from './BinActions';
import EditBinDialog from './EditBinDialog';
import { useBinManagement } from "@/hooks/useBinManagement";
import { Bin } from "@/utils/mockData/types";
import {useSettings} from "@/services/api/hooks/settings.ts";
import {useEffect} from "react";

const BinManagementSkeleton = () => {
  return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Boxes className="h-5 w-5"/>
            Bin Management
          </CardTitle>
          <CardDescription>
            Manage waste bin types, inventory, and SKUs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* BinActions Skeleton */}
            <div className="flex flex-wrap gap-4">
              <div className="h-10 w-32 bg-gray-200 animate-pulse rounded-md"/>
              {/* Add Button */}
              <div className="flex-1 max-w-sm">
                <div className="h-10 w-full bg-gray-200 animate-pulse rounded-md"/>
                {/* Search Bar */}
              </div>
            </div>

            {/* BinTable Skeleton */}
            <div className="rounded-md border">
              {/* Table Header */}
              <div className="grid grid-cols-6 gap-4 p-4 border-b bg-gray-50">
                {[...Array(6)].map((_, index) => (
                    <div key={index} className="h-4 bg-gray-200 animate-pulse rounded"/>
                ))}
              </div>

              {/* Table Rows */}
              {[...Array(5)].map((_, rowIndex) => (
                  <div key={rowIndex} className="grid grid-cols-6 gap-4 p-4 border-b">
                    {/* Image placeholder */}
                    <div className="w-12 h-12 bg-gray-200 animate-pulse rounded"/>

                    {/* Other columns */}
                    {[...Array(4)].map((_, colIndex) => (
                        <div key={colIndex} className="h-4 bg-gray-200 animate-pulse rounded"/>
                    ))}

                    {/* Actions column */}
                    <div className="flex justify-end gap-2">
                      <div className="h-8 w-8 bg-gray-200 animate-pulse rounded"/>
                      <div className="h-8 w-8 bg-gray-200 animate-pulse rounded"/>
                    </div>
                  </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
  );
};


const BinManagement = () => {
  const {
    bins,
    isAddingBin,
    setIsAddingBin,
    isEditingBin,
    setIsEditingBin,
    selectedBin,
    setSelectedBin,
    handleAddBin,
    handleEditBin,
    startEditBin,
    validationErrors,
    getAllBinsType,
    loading
  } = useBinManagement();

  // const {} = useSettings()

  useEffect(() => {
    getAllBinsType()
  }, [])

  if (loading) {
    return <BinManagementSkeleton/>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Boxes className="h-5 w-5" />
          Bin Management
        </CardTitle>
        <CardDescription>
          Manage waste bin types, inventory, and SKUs
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <BinActions
            selectedBin={selectedBin}
            isAddingBin={isAddingBin}
            setIsAddingBin={setIsAddingBin}
            setSelectedBin={setSelectedBin}
            onAddBin={handleAddBin}
            validationErrors={validationErrors}
          />

          <EditBinDialog
            isOpen={isEditingBin}
            onOpenChange={setIsEditingBin}
            selectedBin={selectedBin}
            onEdit={handleEditBin}
            onChange={setSelectedBin}
            validationErrors={validationErrors}
          />

          <BinTable
            bins={bins}
            onEdit={startEditBin}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default BinManagement;
