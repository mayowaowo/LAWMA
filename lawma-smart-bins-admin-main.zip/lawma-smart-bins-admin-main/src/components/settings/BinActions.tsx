
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Boxes } from "lucide-react";
import { Bin } from "@/utils/mockData/types";
import BinForm from "./BinForm";

interface BinActionsProps {
  selectedBin: Partial<Bin>;
  isAddingBin: boolean;
  setIsAddingBin: (value: boolean) => void;
  setSelectedBin: (bin: Partial<Bin>) => void;
  onAddBin: (bin: Partial<Bin>) => void;
  validationErrors: Record<string, string>;
}

const BinActions = ({
  selectedBin,
  isAddingBin,
  setIsAddingBin,
  setSelectedBin,
  onAddBin,
  validationErrors
}: BinActionsProps) => {
  return (
    <Dialog open={isAddingBin} onOpenChange={setIsAddingBin}>
      <DialogTrigger asChild>
        {/*<Button className="mb-4">*/}
        {/*  <Boxes className="h-4 w-4 mr-2" />*/}
        {/*  Add New Bin*/}
        {/*</Button>*/}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Add New Bin Type</DialogTitle>
        </DialogHeader>
        <BinForm
          bin={selectedBin}
          onSubmit={onAddBin}
          onChange={setSelectedBin}
          mode="add"
          loading={isAddingBin}
          validationErrors={validationErrors}
        />
      </DialogContent>
    </Dialog>
  );
};

export default BinActions;
