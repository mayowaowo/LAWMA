
import {useEffect, useState} from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import {useSettings} from "@/services/api/hooks/settings.ts";

const RoleManagementSkeleton = () => {
  return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5"/>
            Role Management
          </CardTitle>
          <CardDescription>
            Manage roles and their permissions in the system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Generate 3 role card skeletons */}
            {[...Array(3)].map((_, index) => (
                <div key={index} className="border rounded-lg p-4">
                  {/* Role header */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="h-6 w-32 bg-gray-200 animate-pulse rounded"/>
                    {/* Role name */}
                    <div className="h-6 w-24 bg-gray-200 animate-pulse rounded-full"/>
                    {/* Badge */}
                  </div>

                  {/* Description */}
                  <div className="h-4 w-3/4 bg-gray-200 animate-pulse rounded mb-4"/>

                  {/* Permissions grid */}
                  <div className="flex flex-wrap gap-2">
                    {[...Array(4 + Math.floor(Math.random() * 4))].map((_, permIndex) => (
                        <div
                            key={permIndex}
                            className="h-6 w-24 bg-gray-200 animate-pulse rounded-full"
                        />
                    ))}
                  </div>
                </div>
            ))}
          </div>
        </CardContent>
      </Card>
  );
};

const RoleManagement = () => {

  const getDescription = (name: string) => {
    switch (name) {
      case 'Super Admin':
        return 'Full access to all features and settings';
      case 'Order Manager':
        return 'Can manage orders and related data';
      case 'Referral Manager':
        return 'Can manage referral agents and related data';
      default:
        return 'No description available';
    }
  };

// Usage:
  const description = getDescription('Administrator');
// Returns: "Full access to all features and settings"



  const {getAllRoleType, role, loading} = useSettings()
  // console.log(role, 'jfj')
  useEffect(() => {
    getAllRoleType()
  }, []);

  if (loading) {
    return <RoleManagementSkeleton/>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Role Management
        </CardTitle>
        <CardDescription>
          Manage roles and their permissions in the system
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {role.map((role) => (
            <div key={role.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium">{role.name}</h3>
                <Badge variant={role.name === 'Super Admin' ? 'destructive' : 'secondary'}>
                  {role.name}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{getDescription(role.name)}</p>
              <div className="flex flex-wrap gap-2">
                {role.permissions.map((permission) => (
                  <Badge key={permission.name} variant="outline">
                    {permission.name}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default RoleManagement;
