
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Package } from "lucide-react";
import { Bin } from "@/utils/mockData/types";
import {Card, CardContent} from "@/components/ui/card.tsx";

interface BinTableProps {
  bins: Bin[];
  onEdit: (bin: Bin) => void;
}

const BinTable = ({ bins, onEdit }: BinTableProps) => {
    function isFile(value: string | File | null): value is File {
        return value instanceof File;
    }

    function getImageSource(image: string | File | null): string {
        if (!image) return ''; // or a default image URL
        if (isFile(image)) {
            return URL.createObjectURL(image);
        }
        return image; // if it's a string, return as is
    }


    return (
      <>
          {
              bins.length === 0 ? (
                  <Card>
                      <CardContent className="p-6 text-center">
                          <p className="text-gray-500">You haven't add bin yet.</p>

                      </CardContent>
                  </Card>
              ) :
                  <>
                      <Table>
                          <TableHeader>
                              <TableRow>
                                  <TableHead>Image</TableHead>
                                  <TableHead>Name</TableHead>
                                  <TableHead>SKU</TableHead>
                                  <TableHead>Price</TableHead>
                                  <TableHead>Stock</TableHead>
                                  <TableHead>Actions</TableHead>
                              </TableRow>
                          </TableHeader>
                          <TableBody>
                              {bins.map((bin) => (
                                  <TableRow key={bin.id}>
                                      <TableCell>
                                          <img
                                              src={getImageSource(bin.image)}
                                              alt={bin.name}
                                              className="w-12 h-12 object-cover rounded-md"
                                          />
                                      </TableCell>
                                      <TableCell className="font-medium">{bin.name}</TableCell>
                                      <TableCell>{bin.sku}</TableCell>
                                      <TableCell>₦{bin.amount.toLocaleString()}</TableCell>
                                      <TableCell>{bin.stock}</TableCell>
                                      <TableCell>
                                          <Button
                                              variant="outline"
                                              size="sm"
                                              onClick={() => onEdit(bin)}
                                          >
                                              <Package className="h-4 w-4 mr-2"/>
                                              Edit
                                          </Button>
                                      </TableCell>
                                  </TableRow>
                              ))}
                          </TableBody>
                      </Table>
                  </>
          }
      </>

  );
};

export default BinTable;
