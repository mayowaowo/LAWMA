
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {Upload, PackageCheck, Loader2} from "lucide-react";
import { Bin } from "@/utils/mockData/types";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface BinFormProps {
  bin: Partial<Bin>;
  onSubmit: (bin: Partial<Bin>) => void;
  onChange: (bin: Partial<Bin>) => void;
  loading: boolean;
  mode: 'add' | 'edit';
  validationErrors?: Record<string, string>;
}

const BinForm = ({ bin, onSubmit, onChange, loading, mode, validationErrors = {} }: BinFormProps) => {
    const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            // Store both the file and the preview URL
            onChange({
                ...bin,
                image: file, // Store the actual file
                imageUrl: URL.createObjectURL(file) // Store the preview URL
            });
        }
    };


    return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Bin Name</Label>
        <Input
          id="name"
          value={bin.name}
          onChange={(e) => onChange({ ...bin, name: e.target.value })}
          placeholder="Enter bin name"
          className={validationErrors.name ? "border-red-500" : ""}
        />
        {validationErrors.name && (
          <Alert variant="destructive">
            <AlertDescription>{validationErrors.name}</AlertDescription>
          </Alert>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="sku">SKU</Label>
        <Input
          id="sku"
          value={bin.sku}
          onChange={(e) => onChange({ ...bin, sku: e.target.value })}
          placeholder="Enter SKU"
          readOnly={true}
          className={validationErrors.sku ? "border-red-500" : ""}
        />
        {validationErrors.sku && (
          <Alert variant="destructive">
            <AlertDescription>{validationErrors.sku}</AlertDescription>
          </Alert>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={bin.description}
          onChange={(e) => onChange({ ...bin, description: e.target.value })}
          placeholder="Enter description"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="amount">Price (₦)</Label>
        <Input
          id="amount"
          type="number"
          value={bin.amount}
          onChange={(e) => onChange({ ...bin, amount: Number(e.target.value) })}
          placeholder="Enter price"
          className={validationErrors.amount ? "border-red-500" : ""}
        />
        {validationErrors.amount && (
          <Alert variant="destructive">
            <AlertDescription>{validationErrors.amount}</AlertDescription>
          </Alert>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="quantity">Stock Quantity</Label>
        <Input
          id="quantity"
          type="number"
          value={bin.stock}
          onChange={(e) => onChange({ ...bin, stock: Number(e.target.value) })}
          placeholder="Enter quantity"
          className={validationErrors.stock ? "border-red-500" : ""}
        />
        {validationErrors.stock && (
          <Alert variant="destructive">
            <AlertDescription>{validationErrors.stock}</AlertDescription>
          </Alert>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="image">Bin Image</Label>
        <Input
          id="image"
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
        />
      </div>

      <Button onClick={() => onSubmit(bin)} className="w-full" disabled={loading}>
        {
            loading ? (
                    <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin"/>
                        {mode === 'add' ? 'Adding...' : 'Updating...'}
                    </>
                ) :
                mode === 'add' ? (
          <>
            <Upload className="h-4 w-4 mr-2" />
            Add Bin
          </>
        ) : (
          <>
            <PackageCheck className="h-4 w-4 mr-2" />
            Update Bin
          </>
        )}
      </Button>
    </div>
  );
};

export default BinForm;
