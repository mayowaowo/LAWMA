
import React, { useState } from 'react';
import {Navigate, Outlet, Route, Routes} from 'react-router-dom';
import Header from './Header';
import Sidebar from './Sidebar';
import { cn } from '@/lib/utils';
// import Index from "@/pages";
import Dashboard from "@/pages/Dashboard.tsx";
import Orders from "@/pages/Orders.tsx";
import Referrals from "@/pages/Referrals.tsx";
import Reports from "@/pages/Reports.tsx";
import Users from "@/pages/Users.tsx";
import Settings from "@/pages/Settings.tsx";
import NotFound from "@/pages/NotFound.tsx";
import Customers from "@/pages/Customers.tsx";
import Repayments from '@/pages/Repayments';
import ActivityLog from '@/pages/ActivityLog';
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";

const DashboardLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
    const userState = useSelector((state: RootState) => state.user);
    const {user} = userState

    const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

    const getRoleName = (role) => {
        switch (role) {
            case 'Order Manager':
                return 'order_manager'
            case 'Referral Manager':
                return 'referral_manager'
            case 'Super Admin':
                return 'super_admin'
            default:
                return 'super_admin'
        }
    }

    const allRoutes = [
        {
            name: 'Dashboard',
            path: 'dashboard',
            element: <Dashboard/>,
            roles: ['super_admin', 'order_manager', 'referral_manager'],
        },
        {
            name: 'Orders',
            path: 'orders',
            element: <Orders/>,
            roles: ['super_admin', 'order_manager'],
        },
        {
            name: 'Referrals',
            path: 'referrals',
            element: <Referrals/>,
            roles: ['super_admin', 'referral_manager'],
        },
        {
            name: 'Customers',
            path: 'customers',
            element: <Customers/>,
            roles: ['super_admin', 'referral_manager'],
        },
        {
            name: 'Reports',
            path: 'reports',
            element: <Reports/>,
            roles: ['super_admin', 'order_manager', 'referral_manager'],
        },
        {
            name: 'Users',
            path: 'users',
            element: <Users/>,
            roles: ['super_admin'],
        },
        {
            name: 'Settings',
            path: 'settings',
            element: <Settings/>,
            roles: ['super_admin'],
        },
        {
            name: 'Activity Log',
            path: 'activitylog',
            element: <ActivityLog/>,
            roles: ['super_admin'],
        },
    ];


    const userRole = getRoleName(user?.role);

    // Filter routes based on user role
    const availableRoutes = allRoutes.filter((route) =>
        route.roles.includes(userRole)
    );


    return (
    <div className="h-screen flex flex-col">
      <Sidebar isSidebarOpen={isSidebarOpen} toggleSidebarOpen={toggleSidebar}/>
      <div className={cn(
          "flex-1 overflow-y-auto transition-all duration-300",
          isSidebarOpen ? "md:ml-64" : "ml-0"
      )}>
        <Header toggleSidebar={toggleSidebar} isSidebarOpen={isSidebarOpen}/>

        <div className="overflow-hidden">

          <main>
            <div className="container mx-auto py-6 px-4 w-full" onClick={toggleSidebar}>
                <Routes>
                    {availableRoutes.map((route) => (
                        <Route
                            key={route.name}
                            path={route.path}
                            element={route.element}
                        />
                    ))}

                    {/* Redirect unauthorized users to the dashboard */}
                    <Route path="*" element={<Navigate to="/dashboard" replace/>}/>
                </Routes>

            </div>
          </main>
        </div>
      </div>

    </div>
  );
};

export default DashboardLayout;
