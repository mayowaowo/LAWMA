
import { NavLink } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { useAuth } from '@/context/AuthContext';
import {
  BarChart,
  Package,
  Users,
  Settings,
  User,
  FilePlus
} from 'lucide-react';

interface SidebarProps {
  isSidebarOpen: boolean;
  toggleSidebarOpen: () => void;
}

const Sidebar = ({ isSidebarOpen, toggleSidebarOpen }: SidebarProps) => {
  const { hasPermission } = useAuth();
  const authState = useSelector((state: RootState) => state.auth);
  const userState = useSelector((state: RootState) => state.user);
  const {isAuthenticated, } = authState
  const {user} = userState
  // console.log(user)

  const getRoleName = (role) => {
    switch (role) {
      case 'Order Manager':
        return 'order_manager'
      case 'Referral Manager':
        return 'referral_manager'
      case 'Super Admin':
        return 'super_admin'
      default:
        return 'super_admin'
    }
  }

  const navigation = [
    {
      name: 'Dashboard',
      href: '/dashboard',
      icon: BarChart,
      roles: ['super_admin', 'order_manager', 'referral_manager']
    },
    {
      name: 'Orders',
      href: '/orders',
      icon: Package,
      roles: ['super_admin', 'order_manager']
    },
    {
      name: 'Agent',
      href: '/referrals',
      icon: Users,
      roles: ['super_admin', 'referral_manager']
    },
    {
      name: 'Customers',
      href: '/customers',
      icon: Users,
      roles: ['super_admin', 'referral_manager']
    },
    // {
    //   name: 'Repayments',
    //   href: '/repayments',
    //   icon: Package,
    //   roles: ['super_admin']
    // },
    {
      name: 'Reports',
      href: '/reports',
      icon: FilePlus,
      roles: ['super_admin', 'order_manager', 'referral_manager']
    },
    {
      name: 'Settings',
      href: '/settings',
      icon: Settings,
      roles: ['super_admin']
    },
    {
      name: 'Users',
      href: '/users',
      icon: User,
      roles: ['super_admin']
    },
    {
      name: 'Activity Log',
      href: '/activitylog',
      icon: User,
      roles: ['super_admin']
    },
  ];

  // Filtering navigation based on user roles
  const filteredNavigation = navigation.filter((item) =>
      item.roles.some((role) => role === getRoleName(user?.role))
  );



  return (
    <aside
      className={cn(
        "fixed inset-y-0 left-0 z-30 bg-sidebar transform transition-transform duration-300 ease-in-out shadow-lg",
        isSidebarOpen ? 'translate-x-0 w-64' : '-translate-x-full w-0 hidden',
        "md:translate-x-0"
      )}
    >
      <div className="h-16 flex items-center justify-center border-b border-sidebar-accent">
        <h2 className="text-xl font-bold text-white">Smart Waste Bins</h2>
      </div>

      <div className="mt-6 px-4">
        <div className="mb-4 px-4 py-2 bg-sidebar-accent rounded-lg">
          <p className="text-sm text-white font-semibold">{user?.name}</p>
          <p className="text-xs text-white/80 capitalize">{user?.type}</p>
        </div>
      </div>

      <nav className="mt-2 px-2 space-y-1">
        {filteredNavigation.map((item) => (

            <NavLink
              key={item.name}
              to={item.href}
              onClick={toggleSidebarOpen}
              className={({ isActive }) => cn(
                "flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors duration-150 ease-in-out sidebar-link",
                "hover:bg-sidebar-primary hover:text-white",
                "text-white",
                isActive ? "bg-sidebar-primary" : "bg-transparent"
              )}
            >
              <item.icon className="h-5 w-5 mr-3" aria-hidden="true" />
              {item.name}
            </NavLink>

        ))}
      </nav>

      <div className="absolute bottom-0 left-0 right-0 p-4">
        <div className="border-t border-sidebar-accent pt-4">
          <div className="flex items-center px-4 py-2">
            <div className="flex-shrink-0">
              <Avatar className="h-8 w-8">
                <AvatarImage src={user?.avatar} alt={user?.name} />
                <AvatarFallback className="bg-sidebar-accent text-white">{user?.name}</AvatarFallback>
              </Avatar>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-white">{user?.name}</p>
              <p className="text-xs text-white/70">{user?.email}</p>
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};

import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {useSelector} from "react-redux";
import {RootState} from "@/services/reducers/rootReducer.ts";

export default Sidebar;
