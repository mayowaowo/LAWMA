
import { formatCurrency } from '@/utils/mockData';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {format} from "date-fns";
import {User, UserData} from "@/services/constant/actionTypes.ts";
import {useState} from "react";
import {Button} from "@/components/ui/button.tsx";
import {ChevronLeft, ChevronRight} from "lucide-react";

interface ReportData {
  id: string;
  date: string;
  customerName: string;
  amount: number;
  source: string;
  status: string;
  agentName?: string;
}

interface ReportTableProps {
  data: User[];
}

const ReportTable = ({ data }) => {

  // console.log(data, 'data hhh')
  // Add these constants outside the component
  const ITEMS_PER_PAGE = 10;

  // Inside the OrdersTable component, add these state variables
  const [currentPage, setCurrentPage] = useState(1);

  // Add this function to handle page changes
  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };
  const totalPages = Math.ceil(data?.length / ITEMS_PER_PAGE) || 0;
  // Calculate paginated orders
  const paginatedOrders = data?.slice(
      (currentPage - 1) * ITEMS_PER_PAGE,
      currentPage * ITEMS_PER_PAGE
  );

  const PaginationControls = () => {
    return (
        <div className="flex items-center justify-between px-2 py-4">
          <div className="text-sm text-muted-foreground">
            Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, data?.length)} of {data?.length} entries
          </div>
          <div className="flex items-center space-x-2">
            <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage - 1)}
                disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4"/>
              Previous
            </Button>
            <div className="flex items-center space-x-1">
              {[...Array(totalPages)].map((_, index) => (
                  <Button
                      key={index + 1}
                      variant={currentPage === index + 1 ? "default" : "outline"}
                      size="sm"
                      onClick={() => handlePageChange(index + 1)}
                  >
                    {index + 1}
                  </Button>
              ))}
            </div>
            <Button
                variant="outline"
                size="sm"
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={currentPage === totalPages}
            >
              Next
              <ChevronRight className="h-4 w-4"/>
            </Button>
          </div>
        </div>
    );
  };
  return (
    <div className="border rounded-md">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>#</TableHead>
            <TableHead>Order ID</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Source</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Agent</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {paginatedOrders?.length > 0 ? (
              paginatedOrders?.map((item, index) => (
              <TableRow key={item.id}>
                <TableCell>{index + 1}</TableCell>
                <TableCell className="font-medium">{item.order_reference}</TableCell>

                <TableCell>{format(new Date(item.created_at), 'yyyy-MM-dd') }</TableCell>
                <TableCell>
                  <div>{item.receiver_details ? (
                      <div>{JSON.parse(item.receiver_details)?.receiver_name || 'N/A'}</div>
                  ) : (
                      <div>{item?.users?.name}</div>
                  )}
                  </div></TableCell>
                <TableCell>{formatCurrency(item.expected_amount)}</TableCell>
                <TableCell>
                  <span className={`inline-block px-2 py-1 rounded-full text-xs ${
                    item.referral === 1 ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                  }`}>
                    {item.referral === 1 ? 'Referral' : 'Direct'}
                  </span>
                </TableCell>
                <TableCell className="capitalize">{item.status}</TableCell>
                {/*<TableCell>{item.receiver_details ? item?.users?.name : 'N/A'}</TableCell>*/}
                <TableCell>{item?.agent ? item?.agent : 'N/A'}</TableCell>

              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-4">
                No data found for the selected report type.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
      <PaginationControls/>
    </div>
  );
};

export default ReportTable;
