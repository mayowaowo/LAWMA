
import { Button } from '@/components/ui/button';
import { formatCurrency } from '@/utils/mockData';
import { Download } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface ReportData {
  id: string;
  date: string;
  customerName: string;
  amount: number;
  source: string;
  status: string;
  agentName?: string;
}

interface ReportPreviewProps {
  data: ReportData[];
  summary: {
    totalOrders: number;
    totalAmount: number;
    referralCount: number;
    directCount: number;
    referralPercentage: number;
    directPercentage: number;
  };
}

const ReportPreview = ({ data, summary }: ReportPreviewProps) => {
  return (
    <div className="space-y-4">
      <div className="p-4 border-b">
        <h2 className="text-lg font-bold">Sales Report Summary</h2>
        <p className="text-sm text-muted-foreground">Generated on {new Date().toLocaleDateString()}</p>
      </div>
      
      <div className="grid grid-cols-2 gap-4 p-4">
        <div>
          <p className="font-medium">Total Orders</p>
          <p>{summary.totalOrders}</p>
        </div>
        <div>
          <p className="font-medium">Total Revenue</p>
          <p>{formatCurrency(summary.totalAmount)}</p>
        </div>
        <div>
          <p className="font-medium">Referral Orders</p>
          <p>{summary.referralCount} ({summary.referralPercentage.toFixed(1)}%)</p>
        </div>
        <div>
          <p className="font-medium">Direct Orders</p>
          <p>{summary.directCount} ({summary.directPercentage.toFixed(1)}%)</p>
        </div>
      </div>
      
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Order ID</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Customer</TableHead>
            <TableHead>Amount</TableHead>
            <TableHead>Source</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.slice(0, 10).map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.id}</TableCell>
              <TableCell>{item.date}</TableCell>
              <TableCell>{item.customerName}</TableCell>
              <TableCell>{formatCurrency(item.amount)}</TableCell>
              <TableCell>{item.source}</TableCell>
            </TableRow>
          ))}
          {data.length > 10 && (
            <TableRow>
              <TableCell colSpan={5} className="text-center">
                <em>...and {data.length - 10} more entries</em>
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
      
      <div className="flex justify-end p-4">
        <Button size="sm">
          <Download className="mr-2 h-4 w-4" />
          Download Full Report
        </Button>
      </div>
    </div>
  );
};

export default ReportPreview;
