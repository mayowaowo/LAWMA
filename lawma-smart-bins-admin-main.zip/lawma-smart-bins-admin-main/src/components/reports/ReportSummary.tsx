
import { Card } from '@/components/ui/card';
import { formatCurrency } from '@/utils/mockData';

interface ReportSummaryProps {
  summary: {
    total_orders: number;
    total_revenue: number;
    referral_orders: number;
    direct_orders: number;
    order: Array<any>; // Replace 'any' with your Order interface
  };
}

const ReportSummary = ({ summary }: ReportSummaryProps) => {
  // console.log(summary)
  return (
    <Card className="p-4">
      <h3 className="text-lg font-medium mb-2">Report Summary</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        <div className="bg-muted p-4 rounded-lg">
          <p className="text-sm text-muted-foreground">Total Orders</p>
          <p className="text-2xl font-bold">{summary.total_orders}</p>
        </div>
        <div className="bg-muted p-4 rounded-lg">
          <p className="text-sm text-muted-foreground">Total Revenue</p>
          <p className="text-2xl font-bold">{formatCurrency(summary.total_revenue)}</p>
        </div>
        <div className="bg-muted p-4 rounded-lg">
          <p className="text-sm text-muted-foreground">Referral Orders</p>
          <p className="text-2xl font-bold">
            {summary.referral_orders}
          </p>
        </div>
        <div className="bg-muted p-4 rounded-lg">
          <p className="text-sm text-muted-foreground">Direct Orders</p>
          <p className="text-2xl font-bold">
            {summary.direct_orders}
          </p>
        </div>
      </div>
    </Card>
  );
};

export default ReportSummary;
