
import {useEffect, useState} from 'react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { FileText } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import ReportSummary from './ReportSummary';
import ReportTable from './ReportTable';
import ReportPreview from './ReportPreview';
import { useReportData, ReportType } from '@/hooks/useReportData';
import {format} from "date-fns";

const ReportGenerator = ({report, exportReports, filters
                         }) => {
  const { reportType, setReportType, reportData, summary } = useReportData();
  const [exportFormat, setExportFormat] = useState<'csv' | 'pdf' | 'excel'>('csv');
  const { toast } = useToast();
  // console.log(report, 'data');

  const [filtersd, setFilters] = useState({
    customerName: filters.customerName || '',
    source: filters.source,
    status: filters.status || 'all',
    binType: filters.binType || 'all',
    dateRange: filters.dateRange || '',
  });

  // Update local state when initialFilters changes
  useEffect(() => {
    setFilters({
      customerName: filters.customerName || '',
      source: filters.source || 'all',
      status: filters.status || 'all',
      binType: filters.binType || 'all',
      dateRange: filters.dateRange || '',

    });

    // Generate selected filters to display based on initialFilters
    // updateSelectedFiltersDisplay(filters);
  }, [filters]);




  const handleFilterChange = (key: string, value: string) => {
    setFilters({...filters, [key]: value});
  };
  const handleExport = async () => {
    const {customerName, source, status, binType, dateRange} = filtersd;

    const params = {
      name: customerName, // Rename `customerName` to `name`
      source: source, // Use `sources` for the report type
      status, // Pass status as-is
      bin: binType, // Rename `binType` to `bin`
      date: dateRange.from && dateRange.to // Check if `from` and `to` exist
          ? `${new Date(dateRange.from).toISOString().split('T')[0]} - ${new Date(dateRange.to).toISOString().split('T')[0]}`
          : undefined // Format `dateRange` as "YYYY-MM-DD - YYYY-MM-DD"
    };

    // console.log(params);
    //
    //
    // console.log(params, reportType);

    const res = await exportReports(params)
    // if (res.success) {
    //   toast({
    //     title: "Report Exported",
    //     description: `Report has been exported as ${exportFormat.toUpperCase()}`,
    //   });
    // }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-4">
        <div>
          <label htmlFor="report-type" className="block text-sm font-medium mb-1">
            Report Type
          </label>
          <Select
              value={filtersd.source}
              onValueChange={(value) => handleFilterChange('source', value)}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Orders</SelectItem>
              <SelectItem value="referral">Referrals Only</SelectItem>
              <SelectItem value="direct">Direct Only</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label htmlFor="export-format" className="block text-sm font-medium mb-1">
            Export Format
          </label>
          <Select
            value={exportFormat}
            onValueChange={(value: 'csv' | 'pdf' | 'excel') => setExportFormat(value)}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Export Format" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="csv">CSV</SelectItem>
              {/*<SelectItem value="pdf">PDF</SelectItem>*/}
              {/*<SelectItem value="excel">Excel</SelectItem>*/}
            </SelectContent>
          </Select>
        </div>

        <Button className="mt-6" onClick={handleExport}>
          <FileText className="mr-2 h-4 w-4" />
          Export Report
        </Button>

        {/*<Dialog>*/}
        {/*  <DialogTrigger asChild>*/}
        {/*    <Button className="mt-6" variant="outline">*/}
        {/*      <FileText className="mr-2 h-4 w-4" />*/}
        {/*      Preview Report*/}
        {/*    </Button>*/}
        {/*  </DialogTrigger>*/}
        {/*  <DialogContent className="max-w-3xl">*/}
        {/*    <DialogHeader>*/}
        {/*      <DialogTitle>Report Preview</DialogTitle>*/}
        {/*    </DialogHeader>*/}
        {/*    <div className="max-h-[60vh] overflow-auto">*/}
        {/*      <ReportPreview data={reportData} summary={summary} />*/}
        {/*    </div>*/}
        {/*  </DialogContent>*/}
        {/*</Dialog>*/}
      </div>

      <ReportSummary summary={report} />
      <ReportTable data={report.order} />
    </div>
  );
};

export default ReportGenerator;

