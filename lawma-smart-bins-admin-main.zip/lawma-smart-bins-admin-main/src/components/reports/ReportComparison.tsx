
import {useEffect, useState} from 'react';
import { orders, agents, formatCurrency } from '@/utils/mockData';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { PieChart as PieChartIcon, BarChart2, LineChart } from 'lucide-react';
import {useReport} from "@/services/api/hooks/reports.ts";

// Comparison types
type ComparisonType = 'source' | 'status' | 'binType';

// Chart colors
const CHART_COLORS = ['#8B5CF6', '#f97316', '#0EA5E9', '#D946EF'];

const ReportComparison = () => {
  const [comparisonType, setComparisonType] = useState<ComparisonType>('source');
  const [chartType, setChartType] = useState('bar');

  const {getReports, loading, report: orders, reportOrders, reportAgent} = useReport()


  // Generate comparison data based on the selected type
  const generateComparisonData = () => {
    if (comparisonType === 'source') {
      const referralOrders = reportOrders.filter(order => order.agentId);
      const directOrders = reportOrders.filter(order => !order.agentId);

      const referralTotal = orders.referral_orders;
      const directTotal = orders.direct_orders;

      return [
        { name: 'Referral Orders', value: referralTotal, amount: referralTotal },
        { name: 'Direct Orders', value: directTotal, amount: directTotal },
      ];
    } else if (comparisonType === 'status') {
      const statusCounts: Record<string, { count: number; amount: number }> = {};

      reportOrders.forEach(order => {
        if (!statusCounts[order.status]) {
          statusCounts[order.status] = { count: 0, amount: 0 };
        }
        statusCounts[order.status].count++;
        statusCounts[order.status].amount += Number(order.total_amount);
      });

      return Object.entries(statusCounts).map(([status, data]) => ({
        name: status.charAt(0).toUpperCase() + status.slice(1),
        value: data.count,
        amount: data.amount,
      }));
    } else if (comparisonType === 'binType') {
      const binTypeCounts: Record<string, { count: number; amount: number }> = {};

      reportOrders.forEach(order => {
        if (!binTypeCounts[order.bin_type]) {
          binTypeCounts[order.bin_type] = { count: 0, amount: 0 };
        }
        binTypeCounts[order.bin_type].count++;
        binTypeCounts[order.bin_type].amount += Number(order.total_amount);
      });

      return Object.entries(binTypeCounts).map(([type, data]) => ({
        name: type.charAt(0).toUpperCase() + type.slice(1),
        value: data.count,
        amount: data.amount,
      }));
    }

    return [];
  };

  const comparisonData = generateComparisonData();

  // Format currency for tooltips
  const formatTooltipValue = (value: number, name: string) => {
    if (name === 'amount') {
      return formatCurrency(value);
    }
    return value;
  };

  // Generate agent performance data
  const generateAgentPerformanceData = () => {
    return reportAgent.map(agent => ({
      name: agent.name,
      referrals: agent.total_referrals,
      commission: agent.total_commissions,
      pending: agent.pending_commissions,
    }));
  };

  const agentPerformanceData = generateAgentPerformanceData();

  useEffect(() => {
    getReports()
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center gap-4">
        <div>
          <label htmlFor="comparison-type" className="block text-sm font-medium mb-1">
            Compare By
          </label>
          <Select
            value={comparisonType}
            onValueChange={(value: ComparisonType) => setComparisonType(value)}
          >
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="source">Order Source</SelectItem>
              <SelectItem value="status">Payment Status</SelectItem>
              <SelectItem value="binType">Bin Type</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs value={chartType} onValueChange={setChartType} className="mt-4">
          <TabsList>
            <TabsTrigger value="bar" className="flex items-center gap-1">
              <BarChart2 className="h-4 w-4" />
              <span>Bar</span>
            </TabsTrigger>
            <TabsTrigger value="pie" className="flex items-center gap-1">
              <PieChartIcon className="h-4 w-4" />
              <span>Pie</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Card className="p-4">
        <h3 className="text-lg font-medium mb-4">
          {comparisonType === 'source' && 'Order Source Comparison'}
          {comparisonType === 'status' && 'Order Status Comparison'}
          {comparisonType === 'binType' && 'Bin Type Comparison'}
        </h3>
        <div className="h-80">
          {chartType === 'bar' ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={comparisonData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={formatTooltipValue} />
                <Legend />
                <Bar dataKey="value" name="Orders" fill="#8B5CF6" />
                {/*<Bar dataKey="amount" name="Revenue" fill="#0EA5E9" />*/}
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={comparisonData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {comparisonData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={formatTooltipValue} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
          {comparisonData.map((item, index) => (
            <div
              key={index}
              className="p-4 rounded-lg border"
              style={{ borderLeftColor: CHART_COLORS[index % CHART_COLORS.length], borderLeftWidth: '4px' }}
            >
              <p className="text-sm text-muted-foreground">{item.name}</p>
              <p className="text-xl font-bold">{item.value} orders</p>
              {/*<p className="text-sm font-medium">{formatCurrency(item.amount)}</p>*/}
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="text-lg font-medium mb-4">Agent Performance Comparison</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={agentPerformanceData}
              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip formatter={formatTooltipValue} />
              <Legend />
              <Bar dataKey="referrals" name="Total Referrals" fill="#8B5CF6" />
              <Bar dataKey="commission" name="Total Commission" fill="#f97316" />
              <Bar dataKey="pending" name="Pending Commission" fill="#0EA5E9" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
};

export default ReportComparison;
