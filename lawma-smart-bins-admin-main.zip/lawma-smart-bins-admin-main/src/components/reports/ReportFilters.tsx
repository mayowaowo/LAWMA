
import {useEffect, useState} from 'react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { CalendarRange, Filter } from 'lucide-react';
import { format } from 'date-fns';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import {ReportFilter} from "@/services/constant/actionTypes.ts";

interface props {
  initialFilters?: ReportFilter;
  onApplyFilters?: (filters: ReportFilter) => void;
}

const ReportFilters = ({initialFilters = {}, onApplyFilters}: props) => {
  const [dateRange, setDateRange] = useState({
    from: initialFilters.dateRange?.from,
    to: initialFilters.dateRange?.to
  });

  const [filters, setFilters] = useState({
    customerName: initialFilters.customerName || '',
    source: initialFilters.source || 'all',
    status: initialFilters.status || 'all',
    binType: initialFilters.binType || 'all'
  });

  // Selected filter tags to display
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);

  // Update local state when initialFilters changes
  useEffect(() => {
    setFilters({
      customerName: initialFilters.customerName || '',
      source: initialFilters.source || 'all',
      status: initialFilters.status || 'all',
      binType: initialFilters.binType || 'all'
    });

    setDateRange({
      from: initialFilters.dateRange?.from,
      to: initialFilters.dateRange?.to
    });

    // Generate selected filters to display based on initialFilters
    updateSelectedFiltersDisplay(initialFilters);
  }, [initialFilters]);

  // Helper function to update the selectedFilters display
  const updateSelectedFiltersDisplay = (filterData) => {
    const newSelectedFilters = [];

    if (filterData.customerName) {
      newSelectedFilters.push(`Customer: ${filterData.customerName}`);
    }

    if (filterData.minAmount || filterData.maxAmount) {
      const amountFilter = `Amount: ${filterData.minAmount || '0'} - ${filterData.maxAmount || 'max'}`;
      newSelectedFilters.push(amountFilter);
    }

    if (filterData.source !== 'all') {
      newSelectedFilters.push(`Source: ${filterData.source}`);
    }

    if (filterData.status !== 'all') {
      newSelectedFilters.push(`Status: ${filterData.status}`);
    }

    if (filterData.binType !== 'all') {
      newSelectedFilters.push(`Bin Type: ${filterData.binType}`);
    }

    if (filterData.dateRange?.from) {
      const dateFilter = filterData.dateRange.to
          ? `Date: ${format(filterData.dateRange.from, 'PPP')} - ${format(filterData.dateRange.to, 'PPP')}`
          : `Date: From ${format(filterData.dateRange.from, 'PPP')}`;
      newSelectedFilters.push(dateFilter);
    }

    setSelectedFilters(newSelectedFilters);
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters({...filters, [key]: value});
  };

  const handleApplyFilters = () => {
    // Create the complete filters object
    const appliedFilters = {
      ...filters,
      dateRange
    };

    // Update the selected filters display
    updateSelectedFiltersDisplay(appliedFilters);

    // Call the parent callback with the filters
    if (onApplyFilters) {
      onApplyFilters(appliedFilters);
    }
  };

  const handleResetFilters = () => {
    const resetFilters = {
      customerName: '',
      source: 'all',
      status: 'all',
      binType: 'all',
      dateRange: {
        from: undefined,
        to: undefined
      }
    };

    setFilters({
      customerName: '',
      source: 'all',
      status: 'all',
      binType: 'all'
    });

    setDateRange({from: undefined, to: undefined});
    setSelectedFilters([]);

    // Apply the reset filters
    if (onApplyFilters) {
      onApplyFilters(resetFilters);
    }
  };

  const handleRemoveFilter = (filter: string) => {
    setSelectedFilters(selectedFilters.filter(f => f !== filter));

    // Create a copy of the current filters to modify
    const updatedFilters = {...filters};
    const updatedDateRange = {...dateRange};

    // Reset the corresponding filter
    if (filter.startsWith('Customer:')) {
      updatedFilters.customerName = '';
    } else if (filter.startsWith('Source:')) {
      updatedFilters.source = 'all';
    } else if (filter.startsWith('Status:')) {
      updatedFilters.status = 'all';
    } else if (filter.startsWith('Bin Type:')) {
      updatedFilters.binType = 'all';
    } else if (filter.startsWith('Date:')) {
      updatedDateRange.from = undefined;
      updatedDateRange.to = undefined;
    }

    // Update local state
    setFilters(updatedFilters);
    setDateRange(updatedDateRange);

    // Apply the updated filters
    if (onApplyFilters) {
      onApplyFilters({
        ...updatedFilters,
        dateRange: updatedDateRange
      });
    }
  };


  // const handleRemoveFilter = (filter: string) => {
  //   setSelectedFilters(selectedFilters.filter(f => f !== filter));
  //
  //   // Reset the corresponding filter
  //   if (filter.startsWith('Customer:')) {
  //     setFilters({ ...filters, customerName: '' });
  //   } else if (filter.startsWith('Amount:')) {
  //     setFilters({ ...filters, minAmount: '', maxAmount: '' });
  //   } else if (filter.startsWith('Source:')) {
  //     setFilters({ ...filters, source: 'all' });
  //   } else if (filter.startsWith('Status:')) {
  //     setFilters({ ...filters, status: 'all' });
  //   } else if (filter.startsWith('Bin Type:')) {
  //     setFilters({ ...filters, binType: 'all' });
  //   } else if (filter.startsWith('Date:')) {
  //     setDateRange({ from: undefined, to: undefined });
  //   }
  // };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="space-y-2">
          <label htmlFor="customerName" className="text-sm font-medium">
            Customer Name
          </label>
          <Input
            id="customerName"
            placeholder="Search by customer name"
            value={filters.customerName}
            onChange={(e) => handleFilterChange('customerName', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Date Range</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
              >
                <CalendarRange className="mr-2 h-4 w-4" />
                {dateRange.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, 'PPP')} - {format(dateRange.to, 'PPP')}
                    </>
                  ) : (
                    format(dateRange.from, 'PPP')
                  )
                ) : (
                  <span>Pick a date range</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="range"
                selected={dateRange}
                onSelect={setDateRange as any}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Order Source</label>
          <Select
            value={filters.source}
            onValueChange={(value) => handleFilterChange('source', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select source" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sources</SelectItem>
              <SelectItem value="referral">Referrals Only</SelectItem>
              <SelectItem value="direct">Direct Only</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Payment Status</label>
          <Select
            value={filters.status}
            onValueChange={(value) => handleFilterChange('status', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Pending">Pending</SelectItem>
              <SelectItem value="Successful">Successful</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium">Bin Type</label>
          <Select
            value={filters.binType}
            onValueChange={(value) => handleFilterChange('binType', value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select bin type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="GENERAL">General</SelectItem>
              <SelectItem value="RECYCLABLES">Recyclable</SelectItem>
              <SelectItem value="both">Both</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/*<div className="grid grid-cols-2 gap-2">*/}
        {/*  <div className="space-y-2">*/}
        {/*    <label htmlFor="minAmount" className="text-sm font-medium">*/}
        {/*      Min Amount*/}
        {/*    </label>*/}
        {/*    <Input*/}
        {/*      id="minAmount"*/}
        {/*      placeholder="0"*/}
        {/*      value={filters.minAmount}*/}
        {/*      onChange={(e) => handleFilterChange('minAmount', e.target.value)}*/}
        {/*    />*/}
        {/*  </div>*/}
        {/*  <div className="space-y-2">*/}
        {/*    <label htmlFor="maxAmount" className="text-sm font-medium">*/}
        {/*      Max Amount*/}
        {/*    </label>*/}
        {/*    <Input*/}
        {/*      id="maxAmount"*/}
        {/*      placeholder="Max"*/}
        {/*      value={filters.maxAmount}*/}
        {/*      onChange={(e) => handleFilterChange('maxAmount', e.target.value)}*/}
        {/*    />*/}
        {/*  </div>*/}
        {/*</div>*/}
      </div>

      <div className="flex flex-wrap gap-2">
        <Button onClick={handleApplyFilters}>
          <Filter className="mr-2 h-4 w-4" />
          Apply Filters
        </Button>
        <Button variant="outline" onClick={handleResetFilters}>
          Reset All
        </Button>
      </div>

      {selectedFilters.length > 0 && (
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-2">
              {selectedFilters.map((filter, index) => (
                <div
                  key={index}
                  className="flex items-center bg-muted px-3 py-1 rounded-full text-sm"
                >
                  <span>{filter}</span>
                  <button
                    className="ml-2 text-muted-foreground hover:text-foreground"
                    onClick={() => handleRemoveFilter(filter)}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/*<div className="space-y-4">*/}
      {/*  <h3 className="text-lg font-medium">Additional Options</h3>*/}
      {/*  <div className="space-y-2">*/}
      {/*    <div className="flex items-center space-x-2">*/}
      {/*      <Checkbox id="include-deleted" />*/}
      {/*      <label*/}
      {/*        htmlFor="include-deleted"*/}
      {/*        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"*/}
      {/*      >*/}
      {/*        Include deleted orders*/}
      {/*      </label>*/}
      {/*    </div>*/}
      {/*    <div className="flex items-center space-x-2">*/}
      {/*      <Checkbox id="show-agent-details" />*/}
      {/*      <label*/}
      {/*        htmlFor="show-agent-details"*/}
      {/*        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"*/}
      {/*      >*/}
      {/*        Show detailed agent information*/}
      {/*      </label>*/}
      {/*    </div>*/}
      {/*    <div className="flex items-center space-x-2">*/}
      {/*      <Checkbox id="include-pending-commissions" />*/}
      {/*      <label*/}
      {/*        htmlFor="include-pending-commissions"*/}
      {/*        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"*/}
      {/*      >*/}
      {/*        Include pending commissions*/}
      {/*      </label>*/}
      {/*    </div>*/}
      {/*  </div>*/}
      {/*</div>*/}
    </div>
  );
};

export default ReportFilters;
