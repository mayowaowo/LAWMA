import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { format } from 'date-fns';
import { ActivityLog } from '@/services/api/hooks/ActivityLog';

interface User {
    id: number;
    name: string;
    email: string;
    email_verified_at: string | null;
    created_at: string;
    updated_at: string;
    uuid: string | null;
    type: string;
    phone: string;
    city: string | null;
    postal_code: string | null;
    address: string | null;
    status: number;
    referral_code: string | null;
    last_login: string;
    login_count: number;
    installment_verification_status: number;
    commision_rate: number | null;
}

interface ActivityDetailsModalProps {
    activity: ActivityLog; 
    isOpen: boolean;
    onClose: () => void;
  }

const ActivityDetailsModal = ({ activity, isOpen, onClose }: ActivityDetailsModalProps) => {
    if (!activity) return null;

    const payload = activity.payload ? JSON.parse(activity.payload) : [];
    const response = activity.response ? JSON.parse(activity.response) : null;

    const DetailColumn = ({ label, value }: { label: string; value: React.ReactNode }) => (
        <div className="py-3">
            <span className="font-medium text-gray-500">{label}</span>
            <div className="col-span-2 text-sm pt-1">{value}</div>
        </div>
    );

    const StatusBadge = ({ status }: { status: number }) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
            status === 1 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
        }`}>
            {status === 1 ? 'Active' : 'Inactive'}
        </span>
    );

    const UserTypeBadge = ({ type }: { type: string }) => (
        <span className={`px-2 py-1 rounded-full text-sm ${
            type === 'ADMIN' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
        }`}>
            {type}
        </span>
    );

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-[800px] max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Activity Details</DialogTitle>
                </DialogHeader>

                <div className="space-y-6">
                    <div>
                        <h3 className="font-semibold mb-4">Activity Information</h3>
                        <div className="grid grid-cols-3 space-y-0">
                            <DetailColumn label="Activity ID" value={activity.id} />
                            <DetailColumn label="Action" value={activity.action} />
                            <DetailColumn label="Description" value={activity.description} />
                            <DetailColumn label="Resource" value={activity.resource} />
                            <DetailColumn label="IP Address" value={activity.ip_address} />
                            <DetailColumn 
                                label="Created At" 
                                value={format(new Date(activity.created_at), 'PPp')} 
                            />
                            <DetailColumn 
                                label="Updated At" 
                                value={format(new Date(activity.updated_at), 'PPp')} 
                            />
                        </div>
                    </div>

                    <div>
                        <h3 className="font-semibold mb-4">User Information</h3>
                        <div className="grid grid-cols-3 space-y-0">
                            <DetailColumn label="User ID" value={activity.user.id} />
                            <DetailColumn label="Name" value={activity.user.name} />
                            <DetailColumn label="Email" value={activity.user.email} />
                            <DetailColumn label="Phone" value={activity.user.phone} />
                            <DetailColumn 
                                label="User Type" 
                                value={<UserTypeBadge type={activity.user.type} />} 
                            />
                            <DetailColumn 
                                label="Status" 
                                value={<StatusBadge status={activity.user.status} />} 
                            />
                            <DetailColumn 
                                label="Login Count" 
                                value={activity.user.login_count} 
                            />
                            <DetailColumn 
                                label="Last Login" 
                                value={activity.user.last_login ? format(new Date(activity.user.last_login), 'PPp') : 'Never'} 
                            />
                            <DetailColumn 
                                label="User Created" 
                                value={format(new Date(activity.user.created_at), 'PPp')} 
                            />
                        </div>
                    </div>

                    {(activity.user.address || activity.user.city || activity.user.postal_code) && (
                        <div>
                            <h3 className="font-semibold mb-4">Address Information</h3>
                            <div className="grid grid-cols-3 space-y-0">
                                {activity.user.address && (
                                    <DetailColumn label="Address" value={activity.user.address} />
                                )}
                                {activity.user.city && (
                                    <DetailColumn label="City" value={activity.user.city} />
                                )}
                                {activity.user.postal_code && (
                                    <DetailColumn label="Postal Code" value={activity.user.postal_code} />
                                )}
                            </div>
                        </div>
                    )}

                    <div>
                        <h3 className="font-semibold mb-4">Additional Information</h3>
                        <div className="grid grid-cols-3 space-y-0">
                            <DetailColumn 
                                label="Email Verified" 
                                value={activity.user.email_verified_at ? 'Yes' : 'No'} 
                            />
                            <DetailColumn 
                                label="Installment Verification" 
                                value={activity.user.installment_verification_status === 1 ? 'Verified' : 'Not Verified'} 
                            />
                            {activity.user.referral_code && (
                                <DetailColumn label="Referral Code" value={activity.user.referral_code} />
                            )}
                            {activity.user.commision_rate && (
                                <DetailColumn 
                                    label="Commission Rate" 
                                    value={`${activity.user.commision_rate}%`} 
                                />
                            )}
                            {activity.user.uuid && (
                                <DetailColumn label="UUID" value={activity.user.uuid} />
                            )}
                        </div>
                    </div>

                    {payload && payload.length > 0 && (
                        <div>
                            <h3 className="font-semibold mb-4">Payload Data</h3>
                            <div className="bg-gray-50 p-4 rounded-lg">
                                <pre className="text-sm overflow-x-auto">
                                    {JSON.stringify(payload, null, 2)}
                                </pre>
                            </div>
                        </div>
                    )}

                    {response && (
                        <div>
                            <h3 className="font-semibold mb-4">Response Data</h3>
                            <div className="bg-gray-50 p-4 rounded-lg">
                                <pre className="text-sm overflow-x-auto">
                                    {JSON.stringify(response, null, 2)}
                                </pre>
                            </div>
                        </div>
                    )}
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default ActivityDetailsModal;