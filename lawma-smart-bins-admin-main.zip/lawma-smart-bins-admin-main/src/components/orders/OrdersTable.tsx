import { useEffect, useState } from "react";
import { format } from 'date-fns';
import { orders as mockOrders, formatCurrency } from "@/utils/mockData";
import { Order } from "@/utils/mockData/types";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import {
  Package,
  Search,
  Filter,
  Check,
  X, MoreVertical, ChevronLeft, ChevronRight
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useOrder } from "@/services/api/hooks/order.ts";
import { getDashboardData } from "@/services/api/hooks/Dashboard.ts";
import OrderDetailsModal from "@/components/orders/OrdersDetailsModal.tsx";
import ConfirmDeliveryModal from "./ConfirmDeliveryModal";
import PaymentScheduleModal from "./PaymentScheduleModal";

const OrdersTableSkeleton = () => {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl flex items-center gap-2">
          <Package className="h-5 w-5" />
          <span>Orders</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Search and Filters Skeleton */}
        <div className="mb-4 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          {/* Search Input Skeleton */}
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <div className="h-10 bg-gray-200 rounded-md animate-pulse" />
          </div>

          {/* Filters Skeleton */}
          <div className="flex flex-col gap-2 md:flex-row">
            <div className="h-10 w-[180px] bg-gray-200 rounded-md animate-pulse" />
            <div className="h-10 w-[180px] bg-gray-200 rounded-md animate-pulse" />
          </div>
        </div>

        {/* Table Skeleton */}
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order ID</TableHead>
                <TableHead>Customer</TableHead>
                <TableHead className="hidden md:table-cell">Date</TableHead>
                <TableHead>Bin Type</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Payment Status</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[...Array(5)].map((_, index) => (
                <TableRow key={index}>
                  {/* Order ID */}
                  <TableCell>
                    <div className="h-4 w-16 bg-gray-200 rounded animate-pulse" />
                  </TableCell>

                  {/* Customer */}
                  <TableCell>
                    <div className="space-y-2">
                      <div className="h-4 w-32 bg-gray-200 rounded animate-pulse" />
                      <div className="h-3 w-24 bg-gray-200 rounded animate-pulse" />
                    </div>
                  </TableCell>

                  {/* Date */}
                  <TableCell className="hidden md:table-cell">
                    <div className="h-4 w-24 bg-gray-200 rounded animate-pulse" />
                  </TableCell>

                  {/* Bin Type */}
                  <TableCell>
                    <div className="h-4 w-20 bg-gray-200 rounded animate-pulse" />
                  </TableCell>

                  {/* Amount */}
                  <TableCell>
                    <div className="h-4 w-16 bg-gray-200 rounded animate-pulse" />
                  </TableCell>

                  {/* Status */}
                  <TableCell>
                    <div className="h-6 w-20 bg-gray-200 rounded-full animate-pulse" />
                  </TableCell>

                  {/* Actions */}
                  <TableCell className="text-right">
                    <div className="h-8 w-8 bg-gray-200 rounded float-right animate-pulse" />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};


const OrdersTable = () => {
  const [orders, setOrders] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [paymentTypeFilter, setPaymentTypeFilter] = useState("all");

  const [binTypeFilter, setBinTypeFilter] = useState("all");

  const [paymentScheduleModalOpen, setPaymentScheduleModalOpen] = useState(false);
  const [selectedOrderForPaymentSchedule, setSelectedOrderForPaymentSchedule] = useState<any>(null);

  const { toast } = useToast();
  const { getOrderHistory, orderHistory, loading, updateOrderStatus, getOrderPaymentInfo, paymentSchedule } = useOrder();

  const [deliveryConfirmationOpen, setDeliveryConfirmationOpen] = useState(false);
  const [selectedOrderForDelivery, setSelectedOrderForDelivery] = useState<{ id: string, order_reference: string } | null>(null);
  const [isConfirmingDelivery, setIsConfirmingDelivery] = useState(false);

  const ITEMS_PER_PAGE = 10;

  const [currentPage, setCurrentPage] = useState(1);
  const [selectedOrder, setSelectedOrder] = useState<null | any>(null);
  const [paymentInfo, setPaymentInfo] = useState<any>(null);

  const handleOpenDeliveryConfirmation = (orderId: string, orderReference: string) => {
    setSelectedOrderForDelivery({
      id: orderId,
      order_reference: orderReference
    });
    setDeliveryConfirmationOpen(true);
  };

  const handleCloseDeliveryConfirmation = () => {
    setDeliveryConfirmationOpen(false);
    setSelectedOrderForDelivery(null);
  };

  const handleViewPaymentSchedule = (order: any) => {
    setSelectedOrderForPaymentSchedule(order);
    getOrderPaymentInfo(order.order_reference).then((res) => {
      if (res.success) {
        setPaymentInfo(res.results);
        setPaymentScheduleModalOpen(true);
      }
    });
  };

  const handleDashboard = async () => {
    try {
      const data = await getOrderHistory()
      setOrders(data.results[0])
    } catch (e) {
      console.error(e);
    }
  }

  const handleStatusChange = async (orderId: string, newStatus: string, orderReference?: string) => {
    const res = await updateOrderStatus(orderId, {})

    if (res.success) {
      await handleDashboard()

      toast({
        title: "Order status updated",
        description: `Order ${orderReference} status has been updated`,
      });
    }
  };

  const handleConfirmDelivery = async () => {
    if (!selectedOrderForDelivery) return;

    setIsConfirmingDelivery(true);
    try {
      await handleStatusChange(
        selectedOrderForDelivery.id,
        'COMPLETED',
        selectedOrderForDelivery.order_reference
      );

      setDeliveryConfirmationOpen(false);
      setSelectedOrderForDelivery(null);
    } finally {
      setIsConfirmingDelivery(false);
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'In Progress':
        return 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200';
      case 'COMPLETED':
        return 'bg-blue-100 text-blue-800 hover:bg-blue-200';
      case 'processing':
        return 'bg-purple-100 text-purple-800 hover:bg-purple-200';
      case 'delivered':
        return 'bg-green-100 text-green-800 hover:bg-green-200';
      case 'NOT COMPLETED':
        return 'bg-red-100 text-red-800 hover:bg-red-200';
      default:
        return 'bg-gray-100 text-gray-800 hover:bg-gray-200';
    }
  };

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber);
  };

  const getBinTypeLabel = (type: string) => {
    switch (type) {
      case 'general':
        return 'General';
      case 'recyclable':
        return 'Recyclable';
      case 'both':
        return 'Both';
      default:
        return type;
    }
  };

  const handleViewDetails = (order) => {
    setSelectedOrder(order);
    getOrderPaymentInfo(order.order_reference).then((res) => {
      if (res.success) {
        setPaymentInfo(res.results);
      }
    });
  };

  const filteredOrders = orders.filter(order => {
    let receiverData = { receiver_name: '', receiver_phone: '' };

    try {
      if (order.receiver_details) {
        receiverData = JSON.parse(order.receiver_details);
      }
    } catch (e) { /* empty */ }

    const searchMatch =
      receiverData.receiver_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      receiverData.receiver_phone?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.users.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.users.email.toLowerCase().includes(searchTerm.toLowerCase())

    const statusMatch = statusFilter === 'all' || order.status === statusFilter;

    const paymentTypeMatch = paymentTypeFilter === 'all' || order.payment_type === paymentTypeFilter;

    const typeMatch = binTypeFilter === 'all' || order.bin_type === binTypeFilter;

    return searchMatch && paymentTypeMatch && statusMatch && typeMatch;
  });

  const totalPages = Math.ceil(filteredOrders.length / ITEMS_PER_PAGE);

  const paginatedOrders = filteredOrders.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  const PaginationControls = () => {
    return (
      <div className="flex items-center justify-between px-2 py-4">
        <div className="text-sm text-muted-foreground">
          Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, filteredOrders.length)} of {filteredOrders.length} entries
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            <ChevronLeft className="h-4 w-4" />
            Previous
          </Button>
          <div className="flex items-center space-x-1">
            {[...Array(totalPages)].map((_, index) => (
              <Button
                key={index + 1}
                variant={currentPage === index + 1 ? "default" : "outline"}
                size="sm"
                onClick={() => handlePageChange(index + 1)}
              >
                {index + 1}
              </Button>
            ))}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            Next
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    );
  };

  const calculateTotalBins = (binPurchaseString: string) => {
    try {
      const binPurchase = JSON.parse(binPurchaseString);
      return binPurchase.reduce((total: number, bin: { quantity: number }) => {
        return total + bin.quantity;
      }, 0);
    } catch (error) {
      return 0;
    }
  };

  const handlePaymentConfirm = (orderId: string) => {
    const updatedOrders = orders.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status: 'paid' as Order['status'],
          paymentDate: new Date().toISOString().split('T')[0]
        };
      }
      return order;
    });

    setOrders(updatedOrders);

    toast({
      title: "Payment confirmed",
      description: `Payment for order ${orderId} has been confirmed`,
    });
  };

  const handleTriggerDelivery = (orderId: string) => {
    const updatedOrders = orders.map(order => {
      if (order.id === orderId) {
        return { ...order, status: 'processing' as Order['status'] };
      }
      return order;
    });

    setOrders(updatedOrders);

    toast({
      title: "Delivery triggered",
      description: `Delivery process started for order ${orderId}`,
    });
  };

  useEffect(() => {
    handleDashboard()
  }, [])

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, statusFilter, binTypeFilter, paymentTypeFilter]);

  if (loading) {
    return <OrdersTableSkeleton />;
  }

  return (
    <>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-xl flex items-center gap-2">
            <Package className="h-5 w-5" />
            <span>Orders</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="relative w-full md:w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search orders..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="flex flex-col gap-2 md:flex-row">
              <div className="flex items-center gap-2">
                <Select
                  value={paymentTypeFilter}
                  onValueChange={setPaymentTypeFilter}
                >
                  <SelectTrigger className="w-full md:w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Payment Type</SelectItem>
                    <SelectItem value="ONEOFF">ONEOFF </SelectItem>
                    <SelectItem value="INSTALLMENT">INSTALLMENT</SelectItem>

                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2">
                <Select
                  value={statusFilter}
                  onValueChange={setStatusFilter}
                >
                  <SelectTrigger className="w-full md:w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Successful">Successful</SelectItem>

                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2">
                <Select
                  value={binTypeFilter}
                  onValueChange={setBinTypeFilter}
                >
                  <SelectTrigger className="w-full md:w-[180px]">
                    <SelectValue placeholder="Filter by bin type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Bin Types</SelectItem>
                    <SelectItem value="GENERAL">GENERAL</SelectItem>
                    <SelectItem value="RECYCLABLES">RECYCLABLES</SelectItem>
                    <SelectItem value="both">Both</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>#</TableHead>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead className="hidden md:table-cell">Date</TableHead>
                  <TableHead>Bin Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Payment Type</TableHead>
                  <TableHead>Payment Status</TableHead>
                  <TableHead>Delivery Status</TableHead>

                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedOrders.length > 0 ? (
                  paginatedOrders.map((order, index) => (
                    <TableRow key={order.id}>
                      <TableCell className="font-medium">{index + 1}</TableCell>
                      <TableCell className="font-medium">{order.order_reference}</TableCell>
                      <TableCell>
                        <div>
                          <div>{order.receiver_details ? (
                            <div>{JSON.parse(order.receiver_details)?.receiver_name || 'N/A'}</div>
                          ) : (
                            <div>{order?.users?.name || 'N/A'}</div>
                          )}
                          </div>
                          <div className="text-xs text-gray-500">{order?.users?.email}</div>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">
                        {calculateTotalBins(order.bin_purchase)}
                      </TableCell>

                      <TableCell className="hidden md:table-cell">{format(new Date(order.created_at), 'yyyy-MM-dd')
                      }</TableCell>
                      <TableCell>{getBinTypeLabel(order.bin_type)}</TableCell>
                      <TableCell>{formatCurrency(order.expected_amount)}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`${getStatusColor(order.payment_type)} capitalize`}>
                          {order.payment_type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`${getStatusColor(order.status)} capitalize`}>
                          {order.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`${getStatusColor(order.delivery_status)} capitalize`}>
                          {order.delivery_status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <span className="sr-only">Open menu</span>
                              <MoreVertical
                                className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => handleViewDetails(order)}
                              className="cursor-pointer"
                            >
                              View Details
                            </DropdownMenuItem>
                            {order.payment_type === 'INSTALLMENT' && (
                              <DropdownMenuItem
                                onClick={() => handleViewPaymentSchedule(order)}
                                className="cursor-pointer"
                              >
                                View Payment Schedule
                              </DropdownMenuItem>
                            )}
                            {
                              order.delivery_status === 'Pending' && (
                                <DropdownMenuItem
                                  onClick={() => handleOpenDeliveryConfirmation(order.id, order.order_reference)}
                                  className="cursor-pointer"
                                >
                                  Confirm Delivery
                                </DropdownMenuItem>
                              )
                            }


                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No orders found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
            <PaginationControls />

          </div>
        </CardContent>

        {selectedOrder && (
          <OrderDetailsModal
            order={selectedOrder}
            isOpen={!!selectedOrder}
            onClose={() => setSelectedOrder(null)}
            paymentInfo={paymentInfo}
          />
        )}
      </Card>

      {selectedOrderForPaymentSchedule && (
        <PaymentScheduleModal
          order={selectedOrderForPaymentSchedule}
          paymentInfo={paymentInfo}
          isOpen={paymentScheduleModalOpen}
          onClose={() => {
            setPaymentScheduleModalOpen(false);
            setSelectedOrderForPaymentSchedule(null);
          }}
        />
      )}

      <ConfirmDeliveryModal
        isOpen={deliveryConfirmationOpen}
        onClose={handleCloseDeliveryConfirmation}
        onConfirm={handleConfirmDelivery}
        orderId={selectedOrderForDelivery?.id || ''}
        orderReference={selectedOrderForDelivery?.order_reference || ''}
        loading={isConfirmingDelivery}
      />
    </>
  );
};

export default OrdersTable;
