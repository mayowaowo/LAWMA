import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns";
import { ObjectTypes, User } from "@/services/constant/actionTypes.ts";

interface OrderDetailsModalProps {
    order: {
        account_number: string;
        amount: string;
        bin_purchase: string;
        bin_type: string;
        color: string;
        created_at: string;
        dispatch_details: string;
        expected_amount: string;
        id: number;
        order_reference: string;
        payment_period: string | null;
        payment_status: string;
        payment_type: string;
        receiver_details: string | null;
        remitted_amount: string | null;
        status: string;
        store_dispatch_details: number;
        total_amount: string;
        updated_at: string;
        user_id: number;
        users: ObjectTypes;
    };
    isOpen: boolean;
    onClose: () => void;
    paymentInfo?: any;
}

const OrderDetailsModal = ({ order, isOpen, onClose, paymentInfo }: OrderDetailsModalProps) => {
    const binPurchase = JSON.parse(order.bin_purchase || "[]");
    const dispatchDetails = JSON.parse(order.dispatch_details || "{}");
    const recieverDetails = JSON.parse(order.receiver_details || "{}");

    console.log(order)

    const DetailColumn = ({ label, value }: { label: string; value: React.ReactNode }) => (
        <div className="py-3 ">
            <span className="font-medium text-gray-500">{label}</span>
            <div className="col-span-2 text-sm pt-1">{value}</div>
        </div>
    );

    const generatePaymentSchedule = () => {
        if (!paymentInfo || paymentInfo.length === 0) {
            return null;
        }

        const paymentData = paymentInfo[0];

        const totalAmount = parseFloat(paymentData.total_amount || "0");
        const initialPayment = parseFloat(paymentData.initial_payment || "0");
        const remainingAmount = parseFloat(paymentData.remaining_amount || "0");
        const frequency = paymentData.payment_frequency;
        const nextPaymentDate = paymentData.next_payment_date ? new Date(paymentData.next_payment_date) : null;
        const paymentScheduleItems = paymentData.payment_schedule || [];

        if (order.payment_type === "ONEOFF") {
            return (
                <div className="mt-4">


                    <div className="border rounded-md overflow-hidden mt-4">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Provider Reference</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {paymentScheduleItems.length > 0 ? (
                                    paymentScheduleItems.map((item: any, index: number) => (
                                        <tr key={index}>
                                            <td className="px-4 py-2 whitespace-nowrap text-sm">
                                                {item.created_at ? format(new Date(item.created_at), 'PPP') : 'N/A'}
                                            </td>
                                            <td className="px-4 py-2 whitespace-nowrap text-sm">
                                                {item.provider_reference || 'N/A'}
                                            </td>

                                            <td className="px-4 py-2 whitespace-nowrap text-sm">
                                                <span className={`px-2 py-1 rounded-full text-xs ${
                                                    item.status === 'Paid' || item.provider_status === 'Paid'
                                                        ? 'bg-green-100 text-green-800'
                                                        : item.status === 'Pending' || item.provider_status === 'Pending'
                                                            ? 'bg-yellow-100 text-yellow-800'
                                                            : 'bg-blue-100 text-blue-800'
                                                }`}>
                                                    {item.status || 'N/A'}
                                                </span>
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan={4} className="px-4 py-2 text-center text-sm text-gray-500">
                                            No payment records found
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            );
        }

        const installments = paymentScheduleItems.length > 0
            ? paymentScheduleItems.map((item: any) => ({
                date: format(new Date(item.created_at), 'PPP'),
                reference: item.reference,
                provider_reference: item.provider_reference || 'N/A',
                amount: parseFloat(item.amount),
                type: item.type === 'Credit' ? 'Payment' : item.type || 'Installment',
                status: item.status,
                provider_status: item.provider_status
            }))
            : [];

        if (installments.length === 0) {
            const currentDate = nextPaymentDate ? new Date(nextPaymentDate) : new Date(order.created_at);
            const installmentCount = order.payment_period ? parseInt(order.payment_period) : 0;
            const installmentAmount = remainingAmount / (installmentCount || 1);

            for (let i = 0; i < installmentCount; i++) {
                if (i === 0 && initialPayment > 0) {
                    installments.push({
                        date: format(new Date(order.created_at), 'PPP'),
                        reference: 'N/A',
                        provider_reference: 'N/A',
                        amount: initialPayment,
                        type: 'Initial Payment',
                        status: 'Paid',
                        provider_status: 'Paid'
                    });
                }

                const paymentDate = new Date(currentDate);
                if (frequency === 'Monthly') {
                    paymentDate.setMonth(paymentDate.getMonth() + i);
                } else if (frequency === 'Weekly') {
                    paymentDate.setDate(paymentDate.getDate() + (i * 7));
                }

                const newInstallment = {
                    date: format(paymentDate, 'PPP'),
                    reference: 'N/A',
                    provider_reference: 'N/A',
                    amount: installmentAmount,
                    type: 'Installment',
                    status: i === 0 ? 'Pending' : 'Upcoming',
                    provider_status: i === 0 ? 'Pending' : 'Upcoming'
                };
                installments.push(newInstallment);
            }
        }

        if (installments.length === 0) {
            return null;
        }

        return (
            <div className="mt-4">
                <h4 className="font-medium mb-2">Payment Schedule</h4>
                <div className="bg-gray-50 p-4 rounded-md">
                    <div className="grid grid-cols-2 gap-4 mb-4">
                        <DetailColumn
                            label="Payment Frequency"
                            value={frequency || 'N/A'}
                        />
                        <DetailColumn
                            label="Next Payment Date"
                            value={nextPaymentDate ? format(nextPaymentDate, 'PPP') : 'N/A'}
                        />
                        <DetailColumn
                            label="Initial Payment"
                            value={`₦${initialPayment.toLocaleString()}`}
                        />
                        <DetailColumn
                            label="Remaining Amount"
                            value={`₦${remainingAmount.toLocaleString()}`}
                        />
                    </div>

                    <div className="border rounded-md overflow-hidden">
                        <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Provider Reference</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                                {installments.map((installment: any, index: number) => (
                                    <tr key={index}>
                                        <td className="px-4 py-2 whitespace-nowrap text-sm">{installment.date}</td>
                                        <td className="px-4 py-2 whitespace-nowrap text-sm">{installment.provider_reference}</td>
                                        <td className="px-4 py-2 whitespace-nowrap text-sm">₦{installment.amount.toFixed(2)}</td>
                                        <td className="px-4 py-2 whitespace-nowrap text-sm">{installment.type}</td>
                                        <td className="px-4 py-2 whitespace-nowrap text-sm">
                                            <span className={`px-2 py-1 rounded-full text-xs ${installment.status === 'Paid'
                                                    ? 'bg-green-100 text-green-800'
                                                    : installment.status === 'Pending'
                                                        ? 'bg-yellow-100 text-yellow-800'
                                                        : 'bg-blue-100 text-blue-800'
                                                }`}>
                                                {installment.status}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-[700px] max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Order Details</DialogTitle>
                </DialogHeader>

                <div className="space-y-6">
                    {/* Order Information */}
                    <div>
                        <h3 className="font-semibold mb-4">Order Information</h3>
                        <div className="grid grid-cols-3 space-y-0">
                            <DetailColumn label="Reference" value={order.order_reference} />
                            {/*<DetailColumn label="Account Number" value={order.account_number}/>*/}
                            <DetailColumn
                                label="Payment Status"
                                value={
                                    <span className={`px-2 py-1 rounded-full text-sm ${order.status === 'COMPLETED' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                                        }`}>
                                        {order.status}
                                    </span>
                                }
                            />
                            <DetailColumn
                                label="Created"
                                value={format(new Date(order.created_at), 'PPp')}
                            />
                        </div>
                    </div>

                    {/* Payment Information */}
                    <div>
                        <h3 className="font-semibold mb-4">Payment Information</h3>
                        <div className="grid grid-cols-3 space-y-0">
                            <DetailColumn label="Payment Type" value={order.payment_type} />
                            {order.payment_type !== "ONEOFF" && (
                                <DetailColumn
                                    label="Installment Plan"
                                    value={`${order.payment_period || 0} month(s)`}
                                />
                            )}
                            <DetailColumn
                                label="Amount Paid"
                                value={`₦${parseFloat(order.expected_amount).toLocaleString()}`}
                            />
                            <DetailColumn
                                label="Base Amount"
                                value={`₦${parseFloat(order.total_amount).toLocaleString()}`}
                            />
                            {order.payment_type !== "ONEOFF" && (
                                <DetailColumn
                                    label="Remaining Balance"
                                    value={`₦${(
                                        parseFloat(order.total_amount) - parseFloat(order.expected_amount)
                                    ).toFixed(2)}`}
                                />
                            )}
                        </div>

                        {/* Payment Schedule with References */}
                        {generatePaymentSchedule()}
                    </div>

                    {/* Bin Details */}
                    <div>
                        <h3 className="font-semibold mb-4">Bin Details</h3>
                        <div className="grid grid-cols-3  space-y-0">
                            <DetailColumn label="Bin Type" value={order.bin_type} />
                            {binPurchase.map((bin: { category: string; quantity: number }, index: number) => (
                                <DetailColumn
                                    key={index}
                                    label={`${bin.category} Bins`}
                                    value={`${bin.quantity} unit(s)`}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Dispatch Information */}
                    <div>
                        <h3 className="font-semibold mb-4">Dispatch Information</h3>
                        <div className="grid grid-cols-3  space-y-0">
                            <DetailColumn label="Name" value={recieverDetails.receiver_name || order.users.name} />
                            <DetailColumn label="Phone" value={recieverDetails.receiver_phone || order.users.phone} />
                        </div>
                        <div className="grid grid-cols-3  space-y-0">
                            <DetailColumn label="Address" value={dispatchDetails.dispatch_address} />
                            <DetailColumn label="City" value={dispatchDetails.dispatch_city} />
                            <DetailColumn label="Postal Code" value={dispatchDetails.dispatch_postal} />
                        </div>
                    </div>
                </div>
            </DialogContent>
        </Dialog>
    );
};

export default OrderDetailsModal;
