import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format } from "date-fns";

interface PaymentScheduleModalProps {
  order: {
    order_reference: string;
    payment_type: string;
    payment_period: string | null;
    created_at: string;
    total_amount: string;
    expected_amount: string;
  };
  paymentInfo?: any;
  isOpen: boolean;
  onClose: () => void;
}

const PaymentScheduleModal = ({ order, paymentInfo, isOpen, onClose }: PaymentScheduleModalProps) => {
  const generatePaymentSchedule = () => {
    if (!paymentInfo || paymentInfo.length === 0) {
      return <div className="text-gray-500">No payment schedule available</div>;
    }

    const paymentData = paymentInfo[0];
    const totalAmount = parseFloat(paymentData.total_amount || "0");
    const initialPayment = parseFloat(paymentData.initial_payment || "0");
    const remainingAmount = parseFloat(paymentData.remaining_amount || "0");
    const frequency = paymentData.payment_frequency;
    const nextPaymentDate = paymentData.next_payment_date ? new Date(paymentData.next_payment_date) : null;
    const paymentScheduleItems = paymentData.payment_schedule || [];

    if (order.payment_type === "ONEOFF") {
      return (
        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-md">
            <div className="grid grid-cols-2 gap-4">
              <div className="py-3">
                <span className="font-medium text-gray-500">Payment Type</span>
                <div className="text-sm pt-1">One-time payment</div>
              </div>
              <div className="py-3">
                <span className="font-medium text-gray-500">Total Amount</span>
                <div className="text-sm pt-1">₦{totalAmount.toLocaleString()}</div>
              </div>
            </div>
          </div>
          <div className="border rounded-md overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Provider Reference</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {paymentScheduleItems.length > 0 ? (
                  paymentScheduleItems.map((item: any, index: number) => (
                    <tr key={index}>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">
                        {item.created_at ? format(new Date(item.created_at), 'PPP') : 'N/A'}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">
                        {item.provider_reference || 'N/A'}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">
                        ₦{parseFloat(item.amount).toFixed(2)}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm">
                        <span className={`px-2 py-1 rounded-full text-xs ${
                          item.status === 'Paid' || item.provider_status === 'Paid'
                            ? 'bg-green-100 text-green-800' 
                            : item.status === 'Pending' || item.provider_status === 'Pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-blue-100 text-blue-800'
                        }`}>
                          {item.status || 'N/A'}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="px-4 py-2 text-center text-sm text-gray-500">
                      No payment records found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      );
    }

    const installments = paymentScheduleItems.map((item: any) => ({
      date: format(new Date(item.created_at), 'PPP'),
      reference: item.reference,
      provider_reference: item.provider_reference || 'N/A',
      amount: parseFloat(item.amount),
      type: item.type === 'Credit' ? 'Payment' : item.type,
      status: item.status,
      provider_status: item.provider_status
    }));

    if (installments.length === 0) {
      const currentDate = nextPaymentDate ? new Date(nextPaymentDate) : new Date(order.created_at);
      const installmentCount = order.payment_period ? parseInt(order.payment_period) : 0;
      const installmentAmount = remainingAmount / (installmentCount || 1);

      for (let i = 0; i < installmentCount; i++) {
        if (i === 0 && initialPayment > 0) {
          installments.push({
            date: format(new Date(order.created_at), 'PPP'),
            reference: 'N/A',
            provider_reference: 'N/A',
            amount: initialPayment,
            type: 'Initial Payment',
            status: 'Paid',
            provider_status: 'Paid'
          });
        }

        const paymentDate = new Date(currentDate);
        if (frequency === 'Monthly') {
          paymentDate.setMonth(paymentDate.getMonth() + i);
        } else if (frequency === 'Weekly') {
          paymentDate.setDate(paymentDate.getDate() + (i * 7));
        }

        installments.push({
          date: format(paymentDate, 'PPP'),
          reference: 'N/A',
          provider_reference: 'N/A',
          amount: installmentAmount,
          type: 'Installment',
          status: i === 0 ? 'Pending' : 'Upcoming',
          provider_status: i === 0 ? 'Pending' : 'Upcoming'
        });
      }
    }

    return (
      <div className="space-y-4">
        <div className="bg-gray-50 p-4 rounded-md">
          <div className="grid grid-cols-2 gap-4">
            <div className="py-3">
              <span className="font-medium text-gray-500">Payment Frequency</span>
              <div className="text-sm pt-1">{frequency || 'N/A'}</div>
            </div>
            <div className="py-3">
              <span className="font-medium text-gray-500">Next Payment Date</span>
              <div className="text-sm pt-1">{nextPaymentDate ? format(nextPaymentDate, 'PPP') : 'N/A'}</div>
            </div>
            <div className="py-3">
              <span className="font-medium text-gray-500">Initial Payment</span>
              <div className="text-sm pt-1">₦{initialPayment.toLocaleString()}</div>
            </div>
            <div className="py-3">
              <span className="font-medium text-gray-500">Remaining Amount</span>
              <div className="text-sm pt-1">₦{remainingAmount.toLocaleString()}</div>
            </div>
          </div>
        </div>

        <div className="border rounded-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-100">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Provider Reference</th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {installments.map((installment: any, index: number) => (
                <tr key={index}>
                  <td className="px-4 py-2 whitespace-nowrap text-sm">{installment.date}</td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm">{installment.provider_reference}</td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm">₦{installment.amount.toFixed(2)}</td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm">{installment.type}</td>
                  <td className="px-4 py-2 whitespace-nowrap text-sm">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      installment.status === 'Paid' || installment.provider_status === 'Paid'
                        ? 'bg-green-100 text-green-800' 
                        : installment.status === 'Pending' || installment.provider_status === 'Pending'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-blue-100 text-blue-800'
                    }`}>
                      {installment.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Payment Schedule for Order {order.order_reference}</DialogTitle>
        </DialogHeader>
        {generatePaymentSchedule()}
      </DialogContent>
    </Dialog>
  );
};

export default PaymentScheduleModal;
