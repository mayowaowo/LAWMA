import { format } from "date-fns";
import { Check, X, BadgeDollarSign } from "lucide-react";
import { Commission } from "@/utils/mockData/types";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatNaira } from "@/utils/mockData/utils";
import {ObjectType} from "@/services/constant/actionTypes.ts";

interface CommissionTableProps {
  commissions: ObjectType[];
  onToggleStatus: (commissionId: string) => void;
}

const CommissionTable = ({ commissions, onToggleStatus }: CommissionTableProps) => {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>#</TableHead>
          <TableHead>Order ID</TableHead>
          {/*<TableHead>Referral Code</TableHead>*/}
          <TableHead>Commission</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Paid Date</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {commissions.length > 0 ? (
          commissions.map((commission, index) => (
            <TableRow key={commission.id}>
              <TableCell>{index + 1}</TableCell>

              {/*<TableCell>{format(new Date(commission.created_at), 'MMM dd, yyyy')}</TableCell>*/}
              <TableCell>{commission.orders?.order_reference || "N/A"}</TableCell>
              {/*<TableCell>{commission.referralCode}</TableCell>*/}
              <TableCell className="flex items-center gap-1">
                {/*<BadgeDollarSign className="h-4 w-4" />*/}
                {formatNaira(commission.commission)}
              </TableCell>
              <TableCell>
                {commission.status === 'Paid' ? (
                  <span className="flex items-center gap-1 text-green-600">
                    <Check className="h-4 w-4" /> Paid
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-orange-500">
                    <X className="h-4 w-4" /> Pending
                  </span>
                )}
              </TableCell>
              <TableCell>
                {commission.updated_at ? format(new Date(commission.updated_at), 'MMM dd, yyyy') : '-'}
              </TableCell>
              <TableCell className="flex justify-end">
                <Button
                  variant="ghost"
                  onClick={() => onToggleStatus(commission.id)}
                  className="flex items-center gap-1"
                  disabled={commission.status === 'Paid'}
                >
                  {commission.status === 'Paid' ? (
                    <>
                      <X className="h-4 w-4" />
                      Mark Paid
                    </>
                  ) : (
                    <>
                      <Check className="h-4 w-4" />
                      Mark Paid
                    </>
                  )}
                </Button>
              </TableCell>
            </TableRow>
          ))
        ) : (
          <TableRow>
            <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
              No commission records found for this period.
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
};

export default CommissionTable;
