import { BadgeDollarSign } from "lucide-react";
import {Agent, Commission} from "@/utils/mockData/types";
import { Card, CardContent } from "@/components/ui/card";
import { formatNaira } from "@/utils/mockData/utils";
import {ObjectType} from "@/services/constant/actionTypes.ts";

interface CommissionStatsProps {
  commissions: Agent;
}

const CommissionStats = ({ commissions }: CommissionStatsProps) => {


  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <Card>
        <CardContent className="pt-6">
          <div className="text-2xl font-bold">{commissions?.total_referrals}</div>
          <p className="text-xs text-muted-foreground">Total Referrals</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="pt-6">
          <div className="text-2xl font-bold">{formatNaira(commissions?.total_commissions)}</div>
          <p className="text-xs text-muted-foreground">Total Commission</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="pt-6">
          <div className="text-2xl font-bold text-green-600">{formatNaira(commissions?.paid_commissions)}</div>
          <p className="text-xs text-muted-foreground">Paid Commission</p>
        </CardContent>
      </Card>
      <Card>
        <CardContent className="pt-6">
          <div className="text-2xl font-bold text-orange-500">{formatNaira(commissions?.pending_commissions)}</div>
          <p className="text-xs text-muted-foreground">Pending Commission</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default CommissionStats;
