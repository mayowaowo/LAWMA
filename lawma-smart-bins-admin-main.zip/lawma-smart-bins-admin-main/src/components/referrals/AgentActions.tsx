
import { DollarSign, Filter, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface AgentActionsProps {
  agentId: string;
  pendingCommission: number;
  status: number;
  activateAgent: (id: string) => void;
  updateAgent: (id: string) => void;
  onPayCommission: (id: string) => void;
  onToggleStatus: (id: string) => void;
  onViewCommissionHistory: () => void;
}

const AgentActions = ({
  agentId,
  pendingCommission,
  status,
                        activateAgent,
  onPayCommission,
  onToggleStatus,
  updateAgent,
  onViewCommissionHistory,
}: AgentActionsProps) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
          <span className="sr-only">Open menu</span>
          <Filter className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {/*<DropdownMenuItem*/}
        {/*  onClick={(e) => {*/}
        {/*    e.stopPropagation();*/}
        {/*    onPayCommission(agentId);*/}
        {/*  }}*/}
        {/*  className="cursor-pointer"*/}
        {/*  disabled={pendingCommission === 0}*/}
        {/*>*/}
        {/*  <DollarSign className="h-4 w-4 mr-2" />*/}
        {/*  Pay Commission*/}
        {/*</DropdownMenuItem>*/}
        <DropdownMenuItem
          onClick={(e) => {
            e.stopPropagation();
            onViewCommissionHistory();
          }}
          className="cursor-pointer"
        >
          <Calendar className="h-4 w-4 mr-2" />
          View Commission History
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={(e) => {
            // e.stopPropagation();
            if (status === 1) {
              updateAgent(agentId);

            } else {
              activateAgent(agentId)

            }
          }}
          className="cursor-pointer"
        >
          {status === 1 ? 'Deactivate Agent' : 'Activate Agent'}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default AgentActions;
