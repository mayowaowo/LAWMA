
import { useState } from 'react';
import { format } from "date-fns";
import { Calendar } from "lucide-react";
import { Agent, Commission } from "@/utils/mockData/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import CommissionStats from "./commission/CommissionStats";
import CommissionTable from "./commission/CommissionTable";
import {useAgent} from "@/services/api/hooks/agents.ts";

interface AgentCommissionHistoryProps {
  agent: Agent;
  onClose: () => void;
}

const mockCommissions: Commission[] = [
];

const AgentCommissionHistory = ({ agent, onClose }: AgentCommissionHistoryProps) => {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [commissions, setCommissions] = useState<Commission[]>(mockCommissions);
  const { toast } = useToast();
  const {markCommissionPaid} = useAgent()
  console.log(agent)
  const filteredCommissions = selectedDate
    ? commissions.filter(comm =>
        comm.date.startsWith(format(selectedDate, 'yyyy-MM'))
      )
    : commissions;

  const toggleCommissionStatus = (commissionId: string) => {
    // setCommissions(prev => prev.map(comm => {
    //   if (comm.id === commissionId) {
    //     const newStatus = comm.status === 'paid' ? 'pending' : 'paid';
    //     return {
    //       ...comm,
    //       status: newStatus,
    //       paidDate: newStatus === 'paid' ? format(new Date(), 'yyyy-MM-dd') : undefined
    //     };
    //   }
    //   return comm;
    // }));
    const res = markCommissionPaid(commissionId)
    if (res) {
      toast({
        title: "Commission status updated",
        description: "The commission payment status has been successfully updated.",
      });
    }

  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Commission History - {agent.name}</CardTitle>
          <div className="text-sm text-muted-foreground mt-1">
            Referral Code: <span className="font-medium">{agent.referral_code}</span> |
            Commission Rate: <span className="font-medium">{new Intl.NumberFormat('en-NG', {
              style: 'currency',
              currency: 'NGN',
            }).format(agent.commision_rate)} per referral</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {/*<Popover>*/}
          {/*  <PopoverTrigger asChild>*/}
          {/*    <Button variant="outline" className="flex items-center gap-2">*/}
          {/*      <Calendar className="h-4 w-4" />*/}
          {/*      {selectedDate ? format(selectedDate, 'MMMM yyyy') : 'Filter by Month'}*/}
          {/*    </Button>*/}
          {/*  </PopoverTrigger>*/}
          {/*  <PopoverContent className="w-auto p-0" align="end">*/}
          {/*    <CalendarComponent*/}
          {/*      mode="single"*/}
          {/*      selected={selectedDate}*/}
          {/*      onSelect={setSelectedDate}*/}
          {/*      className={cn("p-3 pointer-events-auto")}*/}
          {/*    />*/}
          {/*  </PopoverContent>*/}
          {/*</Popover>*/}
          <Button variant="ghost" onClick={onClose}>Close</Button>
        </div>
      </CardHeader>
      <CardContent>
        <CommissionStats commissions={agent} />
        <div className="rounded-md border">
          <CommissionTable
            commissions={agent.commission_history}
            onToggleStatus={toggleCommissionStatus}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default AgentCommissionHistory;
