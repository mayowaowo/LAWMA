import {useEffect, useState} from 'react';
import {useForm} from 'react-hook-form';
import {z} from 'zod';
import {zodResolver} from '@hookform/resolvers/zod';
import {useToast} from '@/hooks/use-toast';
import {Button} from "@/components/ui/button";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import {Input} from "@/components/ui/input";
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";
import {mockUsers} from '@/utils/mockData';
import {useSettings} from "@/services/api/hooks/settings.ts";
import {useUsers} from "@/services/api/hooks/users.ts";
import {Eye, EyeOff, Home, Mail, MapPin, Phone, Lock, User} from 'lucide-react';
import {useAgent} from "@/services/api/hooks/agents.ts";

const formSchema = z.object({
    fullname: z.string().min(2, "Full name must be at least 2 characters"),
    email: z.string().email("Invalid email address"),
    password: z
        .string()
        .min(8, "Password must be at least 8 characters")
        .max(100, "Password is too long")
        .regex(
            /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/,
            "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
        ),
    phone: z
        .string()
        .regex(/^\d+$/, "Phone number must contain only digits")
        .length(11, "Phone number must be exactly 11 digits")
        .transform((val) => val.replace(/\D/g, '')),
    address: z.string().min(5, "Address must be at least 5 characters"),
    city: z.string().min(2, "City must be at least 2 characters"),
    postal: z.string().min(6, "Postal code must be at least 6 characters").max(6, "Postal code can not be more than 6 characters"),
});

type FormValues = z.infer<typeof formSchema>;

interface AddUserFormProps {
    onSuccess: () => void;
}

const AddAgentForm = ({onSuccess}: AddUserFormProps) => {
    const [isSubmitting, setIsSubmitting] = useState(false);
    const {toast} = useToast();
    const [showPassword, setShowPassword] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const {createAgent} = useAgent()

    const form = useForm<FormValues>({
        resolver: zodResolver(formSchema),
        defaultValues: {
            fullname: "",
            email: "",
            password: "",
            phone: "",
            address: "",
            city: "",
            postal: "",
        },
    });



    const onSubmit = async (data: FormValues) => {
        setIsLoading(true);

        const registerData = {
            fullname: data.fullname,
            email: data.email,
            password: data.password,
            phone: data.phone,
            address: data.address,
            city: data.city,
            postal: data.postal,
            password_confirmation: data.password
        };

        const {success} = await createAgent(registerData);
        if (success) {
            toast({
                title: "Create Agent",
                description: `Agent Created successfully`,
            });
            onSuccess();
            setIsLoading(false);

        }
        setIsLoading(false);


    };


    return (
        <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                    control={form.control}
                    name="fullname"
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <div className="relative">
                                <User className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                <FormControl>
                                    <Input placeholder="John Doe" {...field} className="pl-10"/>
                                </FormControl>
                            </div>
                            <FormMessage/>
                        </FormItem>
                    )}
                />

                <FormField
                    control={form.control}
                    name="email"
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Email</FormLabel>
                            <div className="relative">
                                <Mail className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                <FormControl>
                                    <Input type="email" placeholder="your@email.com" {...field} className="pl-10"/>
                                </FormControl>
                            </div>
                            <FormMessage/>
                        </FormItem>
                    )}
                />

                <FormField
                    control={form.control}
                    name="password"
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Password</FormLabel>
                            <div className="relative">
                                <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                <FormControl>
                                    <Input
                                        type={showPassword ? "text" : "password"}
                                        {...field}
                                        className="pl-10 pr-10" // Added right padding for eye icon
                                    />
                                </FormControl>
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    className="absolute right-3 top-3 h-4 w-4 text-gray-400 cursor-pointer hover:text-gray-600"
                                >
                                    {showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}
                                </button>
                            </div>
                            <FormMessage/>
                        </FormItem>
                    )}
                />

                <FormField
                    control={form.control}
                    name="phone"
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <div className="relative">
                                <Phone className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                <FormControl>
                                    <Input placeholder="+234 800 000 0000" {...field} className="pl-10"/>
                                </FormControl>
                            </div>
                            <FormMessage/>
                        </FormItem>
                    )}
                />

                <FormField
                    control={form.control}
                    name="address"
                    render={({field}) => (
                        <FormItem className="md:col-span-1">
                            <FormLabel>Address</FormLabel>
                            <div className="relative">
                                <Home className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                <FormControl>
                                    <Input placeholder="123 Main St" {...field} className="pl-10"/>
                                </FormControl>
                            </div>
                            <FormMessage/>
                        </FormItem>
                    )}
                />

                <FormField
                    control={form.control}
                    name="city"
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Local Government</FormLabel>
                            <div className="relative">
                                <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                <FormControl>
                                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                                        <SelectTrigger className="w-full pl-10">
                                            <SelectValue placeholder="Select LGA in Lagos"/>
                                        </SelectTrigger>
                                        <SelectContent>
                                            {/* Manually adding Lagos LGAs */}
                                            <SelectItem value="Agege">Agege</SelectItem>
                                            <SelectItem value="Ajeromi-Ifelodun">Ajeromi-Ifelodun</SelectItem>
                                            <SelectItem value="Alimosho">Alimosho</SelectItem>
                                            <SelectItem value="Amuwo-Odofin">Amuwo-Odofin</SelectItem>
                                            <SelectItem value="Apapa">Apapa</SelectItem>
                                            <SelectItem value="Badagry">Badagry</SelectItem>
                                            <SelectItem value="Epe">Epe</SelectItem>
                                            <SelectItem value="Eti-Osa">Eti-Osa</SelectItem>
                                            <SelectItem value="Ibeju-Lekki">Ibeju-Lekki</SelectItem>
                                            <SelectItem value="Ifako-Ijaiye">Ifako-Ijaiye</SelectItem>
                                            <SelectItem value="Ikeja">Ikeja</SelectItem>
                                            <SelectItem value="Ikorodu">Ikorodu</SelectItem>
                                            <SelectItem value="Kosofe">Kosofe</SelectItem>
                                            <SelectItem value="Lagos Island">Lagos Island</SelectItem>
                                            <SelectItem value="Lagos Mainland">Lagos Mainland</SelectItem>
                                            <SelectItem value="Mushin">Mushin</SelectItem>
                                            <SelectItem value="Ojo">Ojo</SelectItem>
                                            <SelectItem value="Oshodi-Isolo">Oshodi-Isolo</SelectItem>
                                            <SelectItem value="Shomolu">Shomolu</SelectItem>
                                            <SelectItem value="Surulere">Surulere</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </FormControl>
                            </div>
                            <FormMessage/>
                        </FormItem>
                    )}
                />

                <FormField
                    control={form.control}
                    name="postal"
                    render={({field}) => (
                        <FormItem>
                            <FormLabel>Postal Code</FormLabel>
                            <div className="relative">
                                <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400"/>
                                <FormControl>
                                    <Input placeholder="100001" {...field} className="pl-10" maxLength={6}
                                           type={"number"}/>
                                </FormControl>
                            </div>
                            <FormMessage/>
                        </FormItem>
                    )}
                />

                <div className="flex justify-end gap-2 pt-4">
                    <Button
                        type="button"
                        variant="outline"
                        onClick={onSuccess}
                    >
                        Cancel
                    </Button>
                    <Button type="submit" disabled={isLoading}>
                        {isLoading ? "Creating..." : "Create Agent"}
                    </Button>
                </div>

            </form>
        </Form>
    );
};

export default AddAgentForm;
