import { TableCell, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Agent } from "@/utils/mockData/types";
import { formatCurrency } from "@/utils/mockData";
import AgentActions from "./AgentActions";
import {format} from "date-fns";

interface AgentTableRowProps {
  agent: Agent;
  isSelected: boolean;
  onSelect: (id: string) => void;
  activateAgent: (id: string) => void;

  updateAgent: (id: string) => void;
  onPayCommission: (id: string) => void;
  onToggleStatus?: (id: string) => void;
  onViewCommissionHistory: (agent: Agent) => void;
}

const AgentTableRow = ({
  agent,
  isSelected,
  onSelect,
  updateAgent,
  onPayCommission,
  onToggleStatus,
                         activateAgent,
  onViewCommissionHistory,
}: AgentTableRowProps) => {
  return (
    <TableRow
      key={agent.id}
      className={`cursor-pointer ${isSelected ? 'bg-muted' : ''}`}
      onClick={() => onSelect(agent.id)}
    >
      <TableCell className="font-medium">{agent.id}</TableCell>
      <TableCell>
        <div>
          <div>{agent.name}</div>
          <div className="text-xs text-gray-500">{agent.email}</div>
        </div>
      </TableCell>
      <TableCell className="hidden md:table-cell">{format(new Date(agent.created_at), 'yyyy-MM-dd')}</TableCell>
      <TableCell>
        {agent.referral_code}
      </TableCell>
      <TableCell>
        <div>
          <div>{agent.total_referrals} total</div>
          <div className="text-xs text-gray-500">{agent.total_referrals} active</div>
        </div>
      </TableCell>
      <TableCell>
        <div>
          <div>{formatCurrency(agent.total_commissions)} total</div>
          <div className={`text-xs ${agent.pending_commissions > 0 ? 'text-green-600 font-medium' : 'text-gray-500'}`}>
            {formatCurrency(agent.pending_commissions)} pending
          </div>
        </div>
      </TableCell>
      <TableCell>
        <Badge variant={agent.status === 1 ? 'default' : 'secondary'}>
          {agent.status === 1 ? 'Active' : 'Inactive'}
        </Badge>
      </TableCell>
      <TableCell className="text-right">
        <AgentActions
            agentId={agent.id}
            pendingCommission={agent.pendingCommission}
            status={agent.status}
            onPayCommission={onPayCommission}
            onToggleStatus={onToggleStatus}
            onViewCommissionHistory={() => onViewCommissionHistory(agent)}
            updateAgent={updateAgent} activateAgent={activateAgent}       />
      </TableCell>
    </TableRow>
  );
};

export default AgentTableRow;
