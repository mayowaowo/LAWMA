const NairaSign = () => (
    <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-5 w-5" // You can adjust the size as you like
    >
        <line x1="3" y1="10" x2="21" y2="10"></line>
        <line x1="3" y1="14" x2="21" y2="14"></line>
        <path d="M7 21V3l10 18V3"></path>
    </svg>
);

export default NairaSign;
