
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/utils/mockData";
import { BarChart, PieChart, LineChart } from "recharts";
import {
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Pie,
  Cell,
  Line,
  ComposedChart
} from "recharts";
import { Package, DollarSign, Users, TrendingUp } from "lucide-react";
import {useDashboard} from "@/services/api/hooks/Dashboard.ts";
import {useEffect, useState} from "react";
import NairaSign from "@/components/NairaSigns.tsx";

interface StatsCardProps {
  title: string;
  value: string | number;
  description: string;
  icon: React.ReactNode;
  trend?: number;
  changeType?: "positive" | "negative" | "neutral";
}

const StatsCardSkeleton = () => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"/>
        <div className="h-10 w-10 rounded-full bg-gray-200 animate-pulse"/>
      </CardHeader>
      <CardContent>
        <div className="h-8 w-32 bg-gray-200 animate-pulse rounded mb-2"/>
        <div className="h-3 w-40 bg-gray-200 animate-pulse rounded"/>
        <div className="h-3 w-24 bg-gray-200 animate-pulse rounded mt-2"/>
      </CardContent>
    </Card>
);

const ChartCardSkeleton = ({height = "300px"}) => (
    <Card>
      <CardHeader>
        <div className="h-6 w-48 bg-gray-200 animate-pulse rounded"/>
      </CardHeader>
      <CardContent style={{height}}>
        <div className="w-full h-full bg-gray-200 animate-pulse rounded"/>
      </CardContent>
    </Card>
);

const DashboardStatsSkeleton = () => {
  return (
      <div className="space-y-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, index) => (
              <StatsCardSkeleton key={index}/>
          ))}
        </div>

        {/* Charts Grid - First Row */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <ChartCardSkeleton/>
          <ChartCardSkeleton/>
        </div>

        {/* Charts Grid - Second Row */}
        <div className="grid grid-cols-1 gap-6">
          <ChartCardSkeleton/>
        </div>

        {/* Charts Grid - Third Row */}
        <div className="grid grid-cols-1 gap-6">
          <ChartCardSkeleton/>
        </div>
      </div>
  );
};


export const StatsCard = ({
  title,
  value,
  description,
  icon,
  trend,
  changeType = "neutral"
}: StatsCardProps) => {


  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary">
          {icon}
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
        {trend !== undefined && (
          <div className={`flex items-center mt-1 text-xs ${
            changeType === "positive" ? "text-green-500" : 
            changeType === "negative" ? "text-red-500" : "text-gray-500"
          }`}>
            <TrendingUp className="h-3 w-3 mr-1" />
            <span>{trend}% from last month</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

const DashboardStats = () => {
  // Mock data for charts
  const orderStatusData = [
    { name: 'Pending', value: 28 },
    { name: 'Paid', value: 32 },
    { name: 'Processing', value: 18 },
    { name: 'Delivered', value: 98 },
    { name: 'Cancelled', value: 5 },
  ];

  const [data, setData] = useState()

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

  const {getDashboardData, dashboardData, loading} = useDashboard()

  const handleDashboard = async () => {
    try {
      const {data} = await getDashboardData()
      // console.log(data, 'data')
      setData(data)
    } catch (e) {
      console.error(e);
    }
  };

  // console.log(data, dashboardData, 'dashboardData')

  useEffect(() => {
    handleDashboard()
  }, [])

  if (loading) {
    return <DashboardStatsSkeleton/>;
  }


  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Orders"
          value={dashboardData?.overview?.total_orders.total_orders}
          description="Total orders placed"
          icon={<Package className="h-5 w-5" />}
          trend={dashboardData?.overview?.total_orders.percentage_change}
          changeType="positive"
        />
        <StatsCard
          title="Total Revenue"
          value={formatCurrency(dashboardData?.overview?.total_revenue.total_revenue)}
          description="Total revenue generated"
          icon={<NairaSign />}
          trend={dashboardData?.overview?.total_revenue.percentage_change}
          changeType="positive"
        />
        <StatsCard
          title="Active Agents"
          value={dashboardData?.overview?.active_agents.active_agents}
          description="Total referral agents"
          icon={<Users className="h-5 w-5" />}
          trend={dashboardData?.overview?.active_agents.percentage_change}
          changeType="positive"
        />
        <StatsCard
          title="Commissions Paid"
          value={formatCurrency(dashboardData?.overview?.commission_paid.commission_paid)}
          description="Total commissions disbursed"
          icon={<NairaSign />}
          trend={dashboardData?.overview?.commission_paid.percentage_change}
          changeType="positive"
        />
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Payment Status Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={dashboardData?.order_status_distribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({name, value}) => {
                      const totalSum = dashboardData?.order_status_distribution.reduce(
                          (sum, entry) => sum + entry.value,
                          0
                      );
                      const percentage = ((value / totalSum) * 100).toFixed(0);
                      return `${name}: ${percentage}%`;
                  }}
                >
                  {dashboardData?.order_status_distribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Bin Type Distribution</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                width={500}
                height={300}
                data={dashboardData?.bin_type_distribution}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis dataKey="value" />
                <Tooltip />
                <Legend />
                <Bar dataKey="value" fill="#22c55e" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                width={500}
                height={300}
                data={dashboardData?.monthly_revenue_trend}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip formatter={(value) => formatCurrency(value as number)} />
                <Legend />
                <Line type="monotone" dataKey="total" stroke="#22c55e" activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Weekly Referrals and Commissions</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart
                width={500}
                height={300}
                data={dashboardData?.weekly_referral_commissions}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis yAxisId="left" orientation="left" stroke="#3b82f6" />
                <YAxis yAxisId="right" orientation="right" stroke="#22c55e" />
                <Tooltip formatter={(value, name) => {
                  return  formatCurrency(value as number) ;
                }} />
                <Legend />
                <Bar yAxisId="left" dataKey="orders" fill="#3b82f6" />
                <Line yAxisId="right" type="monotone" dataKey="commission" stroke="#22c55e" />
              </ComposedChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardStats;
