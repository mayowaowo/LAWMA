
import {useEffect, useState} from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { mockUsers } from '@/utils/mockData';
import {useSettings} from "@/services/api/hooks/settings.ts";
import {useUsers} from "@/services/api/hooks/users.ts";

const formSchema = z.object({
    fullname: z.string().min(2, { message: "Name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  password: z.string().min(6, { message: "Password must be at least 6 characters." }),
    role_id: z.string()
});

type FormValues = z.infer<typeof formSchema>;

interface AddUserFormProps {
  onSuccess: () => void;
}

const AddUserForm = ({ onSuccess }: AddUserFormProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const {getAllRoleType, role} = useSettings()
    const {addUsers, loading} = useUsers();
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullname: '',
      email: '',
      password: '',
      role_id: ''
    },
  });

    // console.log('Role:', role); // Should be an array of objects with id and name
    // console.log('field.value:', form);


    const onSubmit = async (values: FormValues) => {
    setIsSubmitting(true);

    try {
      // In a real application, this would be an API call to create the user
      // console.log('Creating user:', values);

      // Simulate user creation by adding to the mock data
      const newUser = {
          fullname: values.fullname,
        email: values.email,
          password: values.password,
          role_id: values.role_id,
      };
        const res = await addUsers(newUser);
        // console.log(res)
        if (res.success) {
            toast({
                title: "User Created",
                description: `${values.fullname} has been successfully added as a ${values.role_id.replace('_', ' ')}.`
            });

            onSuccess();
        }


    } catch (error) {
      console.error('Error creating user:', error);
      toast({
        title: "Error",
        description: "There was a problem creating the user.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  useEffect(() => {
      getAllRoleType()
  }, [])

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="fullname"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="John Doe" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" placeholder="john@example.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="role_id"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Role</FormLabel>
              <Select
                onValueChange={field.onChange}
                // defaultValue={field.value}
                value={field.value}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a role"
                                 />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                    {
                        role.map((role) => (
                            <SelectItem key={role.id} value={role.id.toString()}>{role.name}</SelectItem>

                        ))
                    }
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={onSuccess}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading ? "Adding..." : "Add User"}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default AddUserForm;
