import {useEffect, useState} from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { User } from "@/utils/mockData/types";
import { useAuth } from "@/context/AuthContext";
import UserPermissionsForm from "./UserPermissionsForm";
import { MoreHorizontal } from "lucide-react";

// Example users data - in a real app this would come from API
import { mockUsers } from "@/utils/mockData";
import {useUsers} from "@/services/api/hooks/users.ts";
import {useSettings} from "@/services/api/hooks/settings.ts";

const UsersTableSkeleton = () => {
  return (
      <div className="rounded-md border">
        {/* Table Header */}
        <div className="grid grid-cols-5 gap-4 p-4 border-b bg-gray-50">
          {[...Array(5)].map((_, index) => (
              <div key={index} className="h-4 bg-gray-200 animate-pulse rounded"/>
          ))}
        </div>

        {/* Table Rows */}
        {[...Array(5)].map((_, rowIndex) => (
            <div key={rowIndex} className="grid grid-cols-5 gap-4 p-4 border-b">
              {/* Name column with avatar */}
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 bg-gray-200 animate-pulse rounded-full"/>
                <div className="h-4 w-32 bg-gray-200 animate-pulse rounded"/>
              </div>

              {/* Email column */}
              <div className="h-4 w-48 bg-gray-200 animate-pulse rounded"/>

              {/* Role column */}
              <div className="h-5 w-24 bg-gray-200 animate-pulse rounded"/>

              {/* Status column */}
              <div className="h-5 w-16 bg-gray-200 animate-pulse rounded"/>

              {/* Actions column */}
              <div className="flex justify-end">
                <div className="h-8 w-8 bg-gray-200 animate-pulse rounded"/>
              </div>
            </div>
        ))}
      </div>
  );
};


const UsersTable = () => {
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [isPermissionDialogOpen, setIsPermissionDialogOpen] = useState(false);
  const { hasPermission, user: currentUser } = useAuth();
  const { toast } = useToast();
  const {getUsers, loading, allUser} = useUsers()
  const {getAllRoleType, role: roles,} = useSettings()

  const canEditPermissions = hasPermission(['super_admin']);

  const handleEditPermissions = (user: User) => {
    if (!canEditPermissions) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to edit user permissions",
        variant: "destructive"
      });
      return;
    }

    setSelectedUser(user);
    setIsPermissionDialogOpen(true);
  };

  const updateUserRole = (userId: string, newRole: string) => {
    setUsers(users.map(user =>
      user.id === userId ? { ...user, role: newRole as any } : user
    ));

    toast({
      title: "User Updated",
      description: `User permissions have been updated successfully.`,
    });
  };

  useEffect(() => {
    getUsers()
  }, [])

  if (loading) {
    return <UsersTableSkeleton/>;
  }


  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {allUser.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-medium">
                  <div className="flex items-center">
                    <div className="h-8 w-8 rounded-full bg-gray-200 mr-2 overflow-hidden">
                      {user.avatar ? (
                        <img src={user.avatar} alt={user.name} className="h-full w-full object-cover" />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center bg-primary/10 text-primary font-medium">
                          {user.name.charAt(0)}
                        </div>
                      )}
                    </div>
                    {user.name}
                    {currentUser?.id === user.id && (
                      <Badge variant="outline" className="ml-2">You</Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>
                  <Badge variant={user.role === 'super_admin' ? 'destructive' : user.role === 'order_manager' ? 'default' : 'secondary'}>
                    {user.role_name || user.type}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50 border-green-200">
                    Active
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleEditPermissions(user)}>
                        Edit Permissions
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isPermissionDialogOpen} onOpenChange={setIsPermissionDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User Permissions</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <UserPermissionsForm
              user={selectedUser}
              onSave={(role) => {
                updateUserRole(selectedUser.id, role);
                getUsers()
                setIsPermissionDialogOpen(false);
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default UsersTable;
