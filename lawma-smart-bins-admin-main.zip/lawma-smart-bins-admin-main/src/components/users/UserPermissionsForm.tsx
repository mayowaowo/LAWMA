import {useEffect, useState} from 'react';
import { User } from "@/utils/mockData/types";
import { Button } from "@/components/ui/button";
import {
  RadioGroup,
  RadioGroupItem
} from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import {useSettings} from "@/services/api/hooks/settings.ts";
import {useUsers} from "@/services/api/hooks/users.ts";

interface UserPermissionsFormProps {
  user: User;
  onSave: (role: string) => void;
}

// Define a type for the valid roles
type UserRole = 'super_admin' | 'order_manager' | 'referral_manager';

const UserPermissionsForm = ({ user, onSave }: UserPermissionsFormProps) => {
  const [selectedRole, setSelectedRole] = useState('');
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const {getAllRoleType, role: roles} = useSettings()
  const {editUserRoles, loading} = useUsers()
  // console.log(user, 'jfj')
  useEffect(() => {
    getAllRoleType()
  }, []);

  const getDescription = (name: string) => {
    switch (name) {
      case 'Super Admin':
        return 'Full access to all features and settings';
      case 'Order Manager':
        return 'Can manage orders and related data';
      case 'Referral Manager':
        return 'Can manage referral agents and related data';
      default:
        return 'No description available';
    }
  };
  // const roles = [
  //   {
  //     id: 'super_admin',
  //     name: 'Administrator',
  //     description: 'Full access to all features and settings'
  //   },
  //   {
  //     id: 'order_manager',
  //     name: 'Order Manager',
  //     description: 'Can manage orders and related data'
  //   },
  //   {
  //     id: 'referral_manager',
  //     name: 'Referral Manager',
  //     description: 'Can manage referral agents and related data'
  //   }
  // ];

  const handleSave = async () => {
    if (user.role === 'super_admin' && selectedRole !== 'super_admin') {
      setIsConfirmDialogOpen(true);
      return;
    }
    const payload = {
      "role_id": selectedRole.toString(),
    }
     const {success} = await editUserRoles(user.id, payload);
    if (success) {
      onSave(selectedRole);
    }
  };

  // Create a handler for the radio group that validates the value is a valid role
  const handleRoleChange = (value: string) => {

    setSelectedRole(value);

  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <div className="h-10 w-10 rounded-full bg-gray-200 overflow-hidden">
          {user.avatar ? (
            <img src={user.avatar} alt={user.name} className="h-full w-full object-cover" />
          ) : (
            <div className="h-full w-full flex items-center justify-center bg-primary/10 text-primary font-medium">
              {user.name.charAt(0)}
            </div>
          )}
        </div>
        <div>
          <h3 className="text-lg font-medium">{user.name}</h3>
          <p className="text-sm text-muted-foreground">{user.email}</p>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="font-medium">Role</h4>
        <RadioGroup value={selectedRole} onValueChange={handleRoleChange}>
          {roles.map((role) => (
            <div key={role.id} className="flex items-start space-x-2 p-2 rounded-md hover:bg-muted/50">
              <RadioGroupItem value={role.id} id={role.id} />
              <div className="grid gap-1">
                <Label htmlFor={role.id} className="font-medium">
                  {role.name}
                </Label>
                <p className="text-sm text-muted-foreground">
                  {getDescription(role.name)}
                </p>
              </div>
            </div>
          ))}
        </RadioGroup>
      </div>

      <div className="flex justify-end gap-2">
        <Button variant="outline" onClick={() => onSave(user.role)}>
          Cancel
        </Button>
        <Button onClick={handleSave} disabled={loading}>
          {loading ? 'Loading... ': ' Save Changes'}
        </Button>
      </div>

      <AlertDialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Modify Administrator Role</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to remove administrator privileges from {user.name}.
              This will restrict their access to system-wide settings.
              Are you sure you want to continue?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              setIsConfirmDialogOpen(false);
              onSave(selectedRole);
            }}>
              Continue
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default UserPermissionsForm;
