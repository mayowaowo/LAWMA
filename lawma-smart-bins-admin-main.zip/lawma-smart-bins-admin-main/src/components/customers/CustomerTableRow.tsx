// Updated CustomerTableRow.tsx
import { TableCell, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Agent } from "@/utils/mockData/types";
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { format } from "date-fns";
import { MoreVertical, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useCustomers } from "@/services/api/hooks/Customers.ts";
import UserOrderHistoryModal from "./UserOrderHistoryModal";
import { useToast } from "@/hooks/use-toast";

interface CustomerTableRowProps {
    agent: Agent;
    isSelected: boolean;
    onSelect: (id: string) => void;
    updateAgent?: (id: string) => void;
    onPayCommission?: (id: string) => void;
    onToggleStatus?: (id: string) => void;
    onViewCommissionHistory?: (agent: Agent) => void;
}

const CustomerTableRow = ({
    agent,
    isSelected,
    onSelect,
}: CustomerTableRowProps) => {
    const [isOrderHistoryOpen, setIsOrderHistoryOpen] = useState(false);
    const [orders, setOrders] = useState<null | any[]>(null);
    const [isLoadingOrders, setIsLoadingOrders] = useState(false);
    const { getUserOrderHistory } = useCustomers();
    const { toast } = useToast();

    const handleViewOrderHistory = async (agentId: string) => {
        // console.log("Fetching order history for agent:", agentId);
        setIsLoadingOrders(true);

        try {
          const { success, results, error } = await getUserOrderHistory(agentId);

          if (!success || !results.length) {
            throw new Error(error || "No results returned");
          }

          const validatedResults = results.map(order => {
            let orderDate: Date;

            try {
              orderDate = new Date(order.order_date);
              if (isNaN(orderDate.getTime())) throw new Error();
            } catch {
              console.warn('Invalid date found, using current date:', order.order_date);
              orderDate = new Date();
            }

            return {
              ...order,
              order_date: orderDate.toISOString(),
              id: order.id || Math.random().toString(36).substr(2, 9),
              total_amount: order.total_amount ?? 0,
              status: order.status ?? 'pending',
              items: order.items ?? []
            };
          });

          setOrders(validatedResults);
          setIsOrderHistoryOpen(true);
          // console.log("Order history loaded:", validatedResults);

        } catch (error: any) {
          console.error("Error fetching order history:", error);
          toast({
            title: "Error",
            description: error.message || "An unexpected error occurred while fetching order history",
            variant: "destructive",
          });
          setOrders([]);
          setIsOrderHistoryOpen(true);
        } finally {
          setIsLoadingOrders(false);
        }
      };

    const handleCloseModal = () => {
        setIsOrderHistoryOpen(false);
        setOrders(null); // Reset orders when closing modal
    };

    return (
        <>
            <TableRow
                key={agent.id}
                className={`cursor-pointer ${isSelected ? 'bg-muted' : ''}`}
                onClick={() => onSelect(agent.id)}
            >
                <TableCell className="font-medium">{agent.id}</TableCell>
                <TableCell>
                    <div>
                        <div>{agent.name}</div>
                        <div className="text-xs text-gray-500">{agent.email}</div>
                    </div>
                </TableCell>
                <TableCell className="hidden md:table-cell">
                    {format(new Date(agent.created_at), 'yyyy-MM-dd')}
                </TableCell>
                <TableCell>{agent.phone}</TableCell>
                <TableCell>{agent.address}</TableCell>
                <TableCell>
                    <Badge variant={agent.status === 1 ? 'default' : 'secondary'}>
                        {agent.status === 1 ? 'Active' : 'Inactive'}
                    </Badge>
                </TableCell>
                <TableCell>
                    <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                            <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                                disabled={isLoadingOrders}
                            >
                                <span className="sr-only">Open menu</span>
                                {isLoadingOrders ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                    <MoreVertical className="h-4 w-4" />
                                )}
                            </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                            <DropdownMenuItem
                                onClick={(e) => {
                                    e.stopPropagation();
                                    handleViewOrderHistory(agent.id);
                                }}
                                className="cursor-pointer"
                                disabled={isLoadingOrders}
                            >
                                {isLoadingOrders ? (
                                    <>
                                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                        Loading...
                                    </>
                                ) : (
                                    'View Order History'
                                )}
                            </DropdownMenuItem>
                        </DropdownMenuContent>
                    </DropdownMenu>
                </TableCell>
            </TableRow>

            <UserOrderHistoryModal
                orders={orders}
                isOpen={isOrderHistoryOpen}
                onClose={handleCloseModal}
                userName={agent.name}
                isLoading={isLoadingOrders}
            />
        </>
    );
};

export default CustomerTableRow;
