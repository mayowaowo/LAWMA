import {useEffect, useState} from "react";
import {agents as mockAgents} from "@/utils/mockData";
import {Agent} from "@/utils/mockData/types";
import {ChevronLeft, ChevronRight, Users} from "lucide-react";
import {useToast} from "@/hooks/use-toast";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table";
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    CardDescription
} from "@/components/ui/card";
import {useAgent} from "@/services/api/hooks/agents.ts";
import {Button} from "@/components/ui/button.tsx";
import {postUpdateAgents} from "@/services/api/services/userService.ts";
import CustomerFilters from "@/components/customers/CustomerFilters.tsx";
import CustomerTableRow from "@/components/customers/CustomerTableRow.tsx";
import {useCustomers} from "@/services/api/hooks/Customers.ts";

interface CustomersTableProps {
    onSelectAgent?: (agentId: string) => void;
    selectedAgentId?: string | null;
}


const CustomersTableSkeleton = () => {
    return (
        <Card>
            <CardHeader className="pb-2">
                <CardTitle className="text-xl flex items-center gap-2">
                    <Users className="h-5 w-5"/>
                    <span>Customers</span>
                </CardTitle>
                <CardDescription>View All customers</CardDescription>
            </CardHeader>
            <CardContent>
                {/* Filters Skeleton */}
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                    <div className="w-full sm:w-64 h-10 bg-gray-200 animate-pulse rounded-md"/>
                    <div className="w-full sm:w-48 h-10 bg-gray-200 animate-pulse rounded-md"/>
                </div>

                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Agent ID</TableHead>
                                <TableHead>Name</TableHead>
                                <TableHead className="hidden md:table-cell">Join Date</TableHead>
                                <TableHead>Referrals</TableHead>
                                <TableHead>Commissions</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {/* Generate 5 skeleton rows */}
                            {[...Array(5)].map((_, index) => (
                                <TableRow key={index}>
                                    <TableCell>
                                        <div className="h-4 w-20 bg-gray-200 animate-pulse rounded"/>
                                    </TableCell>
                                    <TableCell>
                                        <div className="h-4 w-32 bg-gray-200 animate-pulse rounded"/>
                                    </TableCell>
                                    <TableCell className="hidden md:table-cell">
                                        <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"/>
                                    </TableCell>
                                    <TableCell>
                                        <div className="h-4 w-16 bg-gray-200 animate-pulse rounded"/>
                                    </TableCell>
                                    <TableCell>
                                        <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"/>
                                    </TableCell>
                                    <TableCell>
                                        <div className="h-4 w-20 bg-gray-200 animate-pulse rounded"/>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <div className="flex justify-end gap-2">
                                            <div className="h-8 w-8 bg-gray-200 animate-pulse rounded"/>
                                            <div className="h-8 w-8 bg-gray-200 animate-pulse rounded"/>
                                        </div>
                                    </TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>
    );
};


const CustomersTable = ({onSelectAgent, selectedAgentId}: CustomersTableProps) => {
    // const [ setAgents] = useState<Agent[]>(mockAgents);
    const [searchTerm, setSearchTerm] = useState("");
    const [statusFilter, setStatusFilter] = useState("all");
    const [selectedAgentForHistory, setSelectedAgentForHistory] = useState<Agent | null>(null);
    const {toast} = useToast();
    // const {getAgents, agents, loading, updateAgents} = useAgent()
    const {getCustomers, getUserOrderHistory, loading, customer} = useCustomers()

    const filteredAgents = customer.filter(agent => {
        const searchMatch =
            agent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            agent.email.toLowerCase().includes(searchTerm.toLowerCase())
        // agent.id.includes(searchTerm.toLowerCase());

        const agentStatus = agent.status === 1 ? 'Active' : 'Inactive'

        const statusMatch = statusFilter === 'all' || agentStatus === statusFilter;

        return searchMatch && statusMatch;
    });
    // Add these constants outside the component
    const ITEMS_PER_PAGE = 10;

    // Inside the OrdersTable component, add these state variables
    const [currentPage, setCurrentPage] = useState(1);

    // Add this function to handle page changes
    const handlePageChange = (pageNumber: number) => {
        setCurrentPage(pageNumber);
    };
    const totalPages = Math.ceil(filteredAgents.length / ITEMS_PER_PAGE);
    // Calculate paginated orders
    const paginatedOrders = filteredAgents.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    );

    const PaginationControls = () => {
        return (
            <div className="flex items-center justify-between px-2 py-4">
                <div className="text-sm text-muted-foreground">
                    Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, filteredAgents.length)} of {filteredAgents.length} entries
                </div>
                <div className="flex items-center space-x-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                    >
                        <ChevronLeft className="h-4 w-4"/>
                        Previous
                    </Button>
                    <div className="flex items-center space-x-1">
                        {[...Array(totalPages)].map((_, index) => (
                            <Button
                                key={index + 1}
                                variant={currentPage === index + 1 ? "default" : "outline"}
                                size="sm"
                                onClick={() => handlePageChange(index + 1)}
                            >
                                {index + 1}
                            </Button>
                        ))}
                    </div>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                    >
                        Next
                        <ChevronRight className="h-4 w-4"/>
                    </Button>
                </div>
            </div>
        );
    };

    const handleAgentClick = (agentId: string) => {
        if (onSelectAgent) {
            onSelectAgent(selectedAgentId === agentId ? null : agentId);
        }
    };

    const handleViewCommissionHistory = (agent: Agent) => {
        setSelectedAgentForHistory(agent);
    };

    useEffect(() => {
        getCustomers();
    }, [])

    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, statusFilter,]);

    if (loading) {
        return <CustomersTableSkeleton/>;
    }


    return (
        <Card>
            <CardHeader className="pb-2">

                <CardTitle className="text-xl flex items-center gap-2">
                    <Users className="h-5 w-5"/>
                    <span>Customers</span>
                </CardTitle>
                <CardDescription>View All customers</CardDescription>
            </CardHeader>
            <CardContent>
                <CustomerFilters
                    searchTerm={searchTerm}
                    onSearchChange={setSearchTerm}
                    statusFilter={statusFilter}
                    onStatusFilterChange={setStatusFilter}
                />

                <div className="rounded-md border">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Customer ID</TableHead>
                                <TableHead>Name</TableHead>
                                <TableHead className="hidden md:table-cell">Join Date</TableHead>
                                <TableHead>phone</TableHead>
                                <TableHead>address</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead className="text-right">Actions</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {paginatedOrders.length > 0 ? (
                                paginatedOrders.map((agent) => (
                                    <CustomerTableRow
                                        key={agent.id}
                                        agent={agent}
                                        isSelected={selectedAgentId === agent.id}
                                        onSelect={handleAgentClick}
                                        onViewCommissionHistory={handleViewCommissionHistory}
                                    />
                                ))
                            ) : (
                                <TableRow>
                                    <TableCell colSpan={7} className="h-24 text-center">
                                        No agents found.
                                    </TableCell>
                                </TableRow>
                            )}
                        </TableBody>
                    </Table>
                    <PaginationControls/>
                </div>

            </CardContent>
        </Card>
    );
};

export default CustomersTable;
