import { useState } from "react";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
    DialogDescription,
} from "@/components/ui/dialog";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import {
    ChevronLeft,
    ChevronRight,
    Package,
    Calendar,
    DollarSign,
    Loader2,
    ShoppingCart,
    Info,
    CreditCard,
    Clock,
    CheckCircle,
    XCircle
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import NairaSign from "@/components/NairaSigns.tsx";

interface BinPurchaseItem {
    category: string;
    quantity: number;
}

interface Transaction {
    transactionReference: string;
    amount: string;
    type: string;
    transactionType: string;
    narration: string;
    status: string;
    createdAt: string;
}

interface Order {
    id: number;
    orderReference: string;
    binPurchaseItems: BinPurchaseItem[];
    amount: string;
    expectedAmount: string;
    totalAmount: string;
    paymentPeriod: string;
    paymentStatus: string;
    status: string;
    createdAt: string;
    transactionHistory: Transaction[];
}

interface UserOrderHistoryModalProps {
    orders: Order[] | null;
    isOpen: boolean;
    onClose: () => void;
    userName: string;
    isLoading?: boolean;
}

const UserOrderHistoryModal = ({
    orders,
    isOpen,
    onClose,
    userName,
    isLoading = false
}: UserOrderHistoryModalProps) => {
    const [currentPage, setCurrentPage] = useState(1);
    const [expandedOrder, setExpandedOrder] = useState<number | null>(null);
    const ITEMS_PER_PAGE = 5;

    const getStatusColor = (status: string) => {
        switch (status.toLowerCase()) {
            case 'completed':
            case 'delivered':
                return 'default';
            case 'in progress':
                return 'secondary';
            case 'cancelled':
            case 'failed':
                return 'destructive';
            case 'pending':
                return 'outline';
            default:
                return 'secondary';
        }
    };

    const getPaymentStatusColor = (status: string) => {
        switch (status.toLowerCase()) {
            case 'completed':
                return 'default';
            case 'not completed':
                return 'destructive';
            case 'pending':
                return 'outline';
            default:
                return 'secondary';
        }
    };

    const formatCurrency = (amount: string) => {
        const num = parseFloat(amount);
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'NGN'
        }).format(num);
    };

    const toggleOrderExpansion = (orderId: number) => {
        setExpandedOrder(expandedOrder === orderId ? null : orderId);
    };

    // Calculate pagination
    const totalPages = orders ? Math.ceil(orders.length / ITEMS_PER_PAGE) : 0;
    const paginatedOrders = orders?.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    ) || [];

    const handlePageChange = (pageNumber: number) => {
        setCurrentPage(pageNumber);
    };

    // Reset pagination when modal opens
    const handleClose = () => {
        setCurrentPage(1);
        setExpandedOrder(null);
        onClose();
    };

    // Calculate summary stats
    const totalOrders = orders?.length || 0;
    const totalSpent = orders?.reduce((sum, order) => sum + parseFloat(order.totalAmount), 0) || 0;
    const completedOrders = orders?.filter(order =>
        order.paymentStatus.toLowerCase() === 'completed'
    ).length || 0;

    const PaginationControls = () => {
        if (totalPages <= 1) return null;

        return (
            <div className="flex items-center justify-between px-2 py-4">
                <div className="text-sm text-muted-foreground">
                    Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, totalOrders)} of {totalOrders} orders
                </div>
                <div className="flex items-center space-x-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                    >
                        <ChevronLeft className="h-4 w-4" />
                        Previous
                    </Button>
                    <div className="flex space-x-1">
                        {[...Array(Math.min(totalPages, 5))].map((_, index) => {
                            let pageNum;
                            if (totalPages <= 5) {
                                pageNum = index + 1;
                            } else if (currentPage <= 3) {
                                pageNum = index + 1;
                            } else if (currentPage >= totalPages - 2) {
                                pageNum = totalPages - 4 + index;
                            } else {
                                pageNum = currentPage - 2 + index;
                            }

                            return (
                                <Button
                                    key={pageNum}
                                    variant={currentPage === pageNum ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => handlePageChange(pageNum)}
                                >
                                    {pageNum}
                                </Button>
                            );
                        })}
                    </div>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                    >
                        Next
                        <ChevronRight className="h-4 w-4" />
                    </Button>
                </div>
            </div>
        );
    };

    return (
        <Dialog open={isOpen} onOpenChange={handleClose}>
            <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                        <ShoppingCart className="h-5 w-5" />
                        Order History - {userName}
                    </DialogTitle>
                    <DialogDescription>
                        View all bin purchase orders placed by this customer
                    </DialogDescription>
                </DialogHeader>

                {isLoading ? (
                    <div className="flex justify-center items-center h-32">
                        <Loader2 className="h-8 w-8 animate-spin" />
                        <span className="ml-2">Loading order history...</span>
                    </div>
                ) : (
                    <>
                        {/* Summary Cards */}
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">
                                        Total Orders
                                    </CardTitle>
                                    <Package className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{totalOrders}</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">
                                        Total Spent
                                    </CardTitle>
                                    <NairaSign />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{formatCurrency(totalSpent.toString())}</div>
                                </CardContent>
                            </Card>
                            <Card>
                                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                    <CardTitle className="text-sm font-medium">
                                        Completed Payments
                                    </CardTitle>
                                    <CreditCard className="h-4 w-4 text-muted-foreground" />
                                </CardHeader>
                                <CardContent>
                                    <div className="text-2xl font-bold">{completedOrders}</div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Orders Table */}
                        <div className="border rounded-lg">
                            <Table>
                                <TableHeader>
                                    <TableRow>
                                        <TableHead>Order Ref</TableHead>
                                        <TableHead>Date</TableHead>
                                        <TableHead>Bins</TableHead>
                                        <TableHead>Total</TableHead>
                                        <TableHead>Status</TableHead>
                                        <TableHead>Payment</TableHead>
                                        <TableHead>Details</TableHead>
                                    </TableRow>
                                </TableHeader>
                                <TableBody>
                                    {paginatedOrders.length > 0 ? (
                                        paginatedOrders.map((order) => (
                                            <Collapsible key={order.id} asChild>
                                                <>
                                                    <TableRow>
                                                        <TableCell className="font-medium">
                                                            {order.orderReference}
                                                        </TableCell>
                                                        <TableCell>
                                                            {format(new Date(order.createdAt), 'MMM dd, yyyy HH:mm')}
                                                        </TableCell>
                                                        <TableCell>
                                                            {order.binPurchaseItems.reduce((sum, item) => sum + item.quantity, 0)} bins
                                                            ({order.binPurchaseItems.length} {order.binPurchaseItems.length === 1 ? 'type' : 'types'})
                                                        </TableCell>
                                                        <TableCell>
                                                            {formatCurrency(order.totalAmount)}
                                                        </TableCell>
                                                        <TableCell>
                                                            <Badge variant={getStatusColor(order.status)}>
                                                                {order.status}
                                                            </Badge>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Badge variant={getPaymentStatusColor(order.paymentStatus)}>
                                                                {order.paymentStatus}
                                                            </Badge>
                                                        </TableCell>
                                                        <TableCell>
                                                            <Button
                                                                variant="ghost"
                                                                size="sm"
                                                                onClick={() => toggleOrderExpansion(order.id)}
                                                            >
                                                                <Info className="h-4 w-4" />
                                                                <span className="ml-2">Details</span>
                                                            </Button>
                                                        </TableCell>
                                                    </TableRow>
                                                    {expandedOrder === order.id && (
                                                        <TableRow>
                                                            <TableCell colSpan={7} className="p-0">
                                                                <div className="p-4 bg-muted/50">
                                                                    <h4 className="font-medium mb-3">Order Details - {order.orderReference}</h4>

                                                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                                                                        <div>
                                                                            <h5 className="text-sm font-medium mb-2">Order Information</h5>
                                                                            <div className="text-sm space-y-2">
                                                                                <p>
                                                                                    <span className="font-medium">Order Date:</span> {format(new Date(order.createdAt), 'MMM dd, yyyy HH:mm:ss')}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="font-medium">Payment Period:</span> {order.paymentPeriod} days
                                                                                </p>
                                                                                <p>
                                                                                    <span className="font-medium">Amount:</span> {formatCurrency(order.amount)}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="font-medium">Expected Amount:</span> {formatCurrency(order.expectedAmount)}
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                        <div>
                                                                            <h5 className="text-sm font-medium mb-2">Payment Status</h5>
                                                                            <div className="text-sm space-y-2">
                                                                                <p>
                                                                                    <span className="font-medium">Status:</span> {order.paymentStatus}
                                                                                </p>
                                                                                <p>
                                                                                    <span className="font-medium">Total Paid:</span> {formatCurrency(order.totalAmount)}
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <h5 className="text-sm font-medium mb-2">Bin Purchases</h5>
                                                                    <div className="border rounded-lg mb-4">
                                                                        <Table>
                                                                            <TableHeader>
                                                                                <TableRow>
                                                                                    <TableHead>Category</TableHead>
                                                                                    <TableHead>Quantity</TableHead>
                                                                                </TableRow>
                                                                            </TableHeader>
                                                                            <TableBody>
                                                                                {order.binPurchaseItems.map((item, index) => (
                                                                                    <TableRow key={index}>
                                                                                        <TableCell>
                                                                                            {item.category}
                                                                                        </TableCell>
                                                                                        <TableCell>
                                                                                            {item.quantity}
                                                                                        </TableCell>
                                                                                    </TableRow>
                                                                                ))}
                                                                            </TableBody>
                                                                        </Table>
                                                                    </div>

                                                                    <h5 className="text-sm font-medium mb-2">Transaction History</h5>
                                                                    {order.transactionHistory.length > 0 ? (
                                                                        <div className="border rounded-lg">
                                                                            <Table>
                                                                                <TableHeader>
                                                                                    <TableRow>
                                                                                        <TableHead>Reference</TableHead>
                                                                                        <TableHead>Date</TableHead>
                                                                                        <TableHead>Amount</TableHead>
                                                                                        <TableHead>Type</TableHead>
                                                                                        <TableHead>Status</TableHead>
                                                                                    </TableRow>
                                                                                </TableHeader>
                                                                                <TableBody>
                                                                                    {order.transactionHistory.map((txn) => (
                                                                                        <TableRow key={txn.transactionReference}>
                                                                                            <TableCell className="font-mono text-sm">
                                                                                                {txn.transactionReference}
                                                                                            </TableCell>
                                                                                            <TableCell>
                                                                                                {format(new Date(txn.createdAt), 'MMM dd, HH:mm')}
                                                                                            </TableCell>
                                                                                            <TableCell>
                                                                                                {formatCurrency(txn.amount)}
                                                                                            </TableCell>
                                                                                            <TableCell>
                                                                                                <Badge variant="outline">
                                                                                                    {txn.transactionType}
                                                                                                </Badge>
                                                                                            </TableCell>
                                                                                            <TableCell>
                                                                                                {txn.status === 'Pending' ? (
                                                                                                    <Badge variant="outline" className="flex items-center gap-1">
                                                                                                        <Clock className="h-3 w-3" /> Pending
                                                                                                    </Badge>
                                                                                                ) : txn.status === 'Completed' ? (
                                                                                                    <Badge variant="default" className="flex items-center gap-1">
                                                                                                        <CheckCircle className="h-3 w-3" /> Completed
                                                                                                    </Badge>
                                                                                                ) : (
                                                                                                    <Badge variant="destructive" className="flex items-center gap-1">
                                                                                                        <XCircle className="h-3 w-3" /> Failed
                                                                                                    </Badge>
                                                                                                )}
                                                                                            </TableCell>
                                                                                        </TableRow>
                                                                                    ))}
                                                                                </TableBody>
                                                                            </Table>
                                                                        </div>
                                                                    ) : (
                                                                        <p className="text-sm text-muted-foreground">No transaction history available</p>
                                                                    )}
                                                                </div>
                                                            </TableCell>
                                                        </TableRow>
                                                    )}
                                                </>
                                            </Collapsible>
                                        ))
                                    ) : (
                                        <TableRow>
                                            <TableCell colSpan={7} className="h-24 text-center">
                                                <div className="flex flex-col items-center justify-center gap-2">
                                                    <Package className="h-8 w-8 text-muted-foreground" />
                                                    <p>No bin purchase orders found for this customer</p>
                                                </div>
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </TableBody>
                            </Table>
                            <PaginationControls />
                        </div>
                    </>
                )}
            </DialogContent>
        </Dialog>
    );
};

export default UserOrderHistoryModal;
