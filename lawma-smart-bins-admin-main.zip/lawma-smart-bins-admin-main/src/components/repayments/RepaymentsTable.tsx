import React, { useEffect, useState } from 'react';
import { ChevronDown, ChevronUp, Eye, User, CreditCard, Package, MapPin, Calendar, DollarSign } from 'lucide-react';
import { useRepayments } from '@/services/api/hooks/Repayments';
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow
} from "@/components/ui/table";
import {
    Card,
    CardContent,
    CardHeader,
    CardTitle,
    CardDescription
} from "@/components/ui/card";
import {ChevronLeft, ChevronRight, Users} from "lucide-react";
import {Button} from "@/components/ui/button.tsx";
import TableFilters from './TableFilters';


const RepaymentsTable = () => {
    const [expandedRows, setExpandedRows] = useState(new Set());
    const [searchTerm, setSearchTerm] = useState("");
    const [statusFilter, setStatusFilter] = useState("all");
    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 10;
    
    const { 
        loading,
        repayments: repaymentData = [],
        fetchRepayments,
    } = useRepayments();

    useEffect(() => {
        fetchRepayments();
    }, []);

    useEffect(() => {
        if (repaymentData.length > 0) {
            setExpandedRows(new Set([repaymentData[0].id]));
        }
    }, [repaymentData]);

     // Define status options specific to repayments
     const repaymentStatusOptions = [
        { value: "all", label: "All Statuses" },
        { value: "completed", label: "Completed" },
        { value: "pending", label: "Pending" },
        { value: "failed", label: "Failed" },
    ];

    // Filter repayments based on search term and status filter
    const filteredRepayments = repaymentData.filter(repayment => {
        const searchMatch =
            repayment.user?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            repayment.user?.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            repayment.order_reference?.toLowerCase().includes(searchTerm.toLowerCase());

        const statusMatch = statusFilter === 'all' || 
                          repayment.status?.toLowerCase() === statusFilter.toLowerCase();

        return searchMatch && statusMatch;
    });

    // Pagination logic
    const totalPages = Math.ceil(filteredRepayments.length / ITEMS_PER_PAGE);
    const paginatedRepayments = filteredRepayments.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    );

    const handlePageChange = (pageNumber: number) => {
        setCurrentPage(pageNumber);
    };


    const toggleRow = (id) => {
        const newExpanded = new Set(expandedRows);
        if (newExpanded.has(id)) {
            newExpanded.delete(id);
        } else {
            newExpanded.add(id);
        }
        setExpandedRows(newExpanded);
    };

    const formatDate = (dateString) => {
        if (!dateString) return 'N/A';
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const getStatusColor = (status) => {
        if (!status) return 'bg-gray-100 text-gray-800';
        switch (status.toLowerCase()) {
            case 'completed':
                return 'bg-green-100 text-green-800';
            case 'pending':
                return 'bg-yellow-100 text-yellow-800';
            case 'failed':
                return 'bg-red-100 text-red-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    };

    const getPaymentTypeColor = (type) => {
        if (!type) return 'bg-gray-100 text-gray-800';
        return type === 'INSTALLMENT'
            ? 'bg-blue-100 text-blue-800'
            : 'bg-purple-100 text-purple-800';
    };

    const PaginationControls = () => {
        return (
            <div className="flex items-center justify-between px-2 py-4">
                <div className="text-sm text-muted-foreground">
                    Showing {((currentPage - 1) * ITEMS_PER_PAGE) + 1} to {Math.min(currentPage * ITEMS_PER_PAGE, filteredRepayments.length)} of {filteredRepayments.length} entries
                </div>
                <div className="flex items-center space-x-2">
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                    >
                        <ChevronLeft className="h-4 w-4"/>
                        Previous
                    </Button>
                    <div className="flex items-center space-x-1">
                        {[...Array(totalPages)].map((_, index) => (
                            <Button
                                key={index + 1}
                                variant={currentPage === index + 1 ? "default" : "outline"}
                                size="sm"
                                onClick={() => handlePageChange(index + 1)}
                            >
                                {index + 1}
                            </Button>
                        ))}
                    </div>
                    <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                    >
                        Next
                        <ChevronRight className="h-4 w-4"/>
                    </Button>
                </div>
            </div>
        );
    };


    const CustomersTableSkeleton = () => {
        return (
            <Card>
                <CardHeader className="pb-2">
                    <CardTitle className="text-xl flex items-center gap-2">
                        <span>Manual Repayments</span>
                    </CardTitle>
                    
                </CardHeader>
                <CardContent>
                    {/* Filters Skeleton */}
                    <div className="flex flex-col sm:flex-row gap-4 mb-6">
                        <div className="w-full sm:w-64 h-10 bg-gray-200 animate-pulse rounded-md"/>
                        <div className="w-full sm:w-48 h-10 bg-gray-200 animate-pulse rounded-md"/>
                    </div>
    
                    <div className="rounded-md border">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>CUSTOMER</TableHead>
                                    <TableHead>ORDER REFERENCE</TableHead>
                                    <TableHead className="hidden md:table-cell">AMOUNT</TableHead>
                                    <TableHead>PAYMENT TYPE</TableHead>
                                    <TableHead>STATUS</TableHead>
                                    <TableHead>DATE</TableHead>
                                    <TableHead className="text-right">ACTIONS</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {/* Generate 5 skeleton rows */}
                                {[...Array(5)].map((_, index) => (
                                    <TableRow key={index}>
                                        <TableCell>
                                            <div className="h-4 w-20 bg-gray-200 animate-pulse rounded"/>
                                        </TableCell>
                                        <TableCell>
                                            <div className="h-4 w-32 bg-gray-200 animate-pulse rounded"/>
                                        </TableCell>
                                        <TableCell className="hidden md:table-cell">
                                            <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"/>
                                        </TableCell>
                                        <TableCell>
                                            <div className="h-4 w-16 bg-gray-200 animate-pulse rounded"/>
                                        </TableCell>
                                        <TableCell>
                                            <div className="h-4 w-24 bg-gray-200 animate-pulse rounded"/>
                                        </TableCell>
                                        <TableCell>
                                            <div className="h-4 w-20 bg-gray-200 animate-pulse rounded"/>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <div className="flex justify-end gap-2">
                                                <div className="h-8 w-8 bg-gray-200 animate-pulse rounded"/>
                                                <div className="h-8 w-8 bg-gray-200 animate-pulse rounded"/>
                                            </div>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                </CardContent>
            </Card>
        );
    };
    

    if (loading) {
        return <CustomersTableSkeleton />;
    }

    if (!repaymentData || repaymentData.length === 0) {
        return <div className="text-center py-8">No repayment data available</div>;
    }

    return (
        <div className="w-full max-w-7xl mx-auto p-6 bg-white">
            <div className="mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Manual Repayments</h1>
                <p className="text-gray-600">Manage and track LAWMA Smart Bin purchase repayments</p>
            </div>

            <TableFilters
                searchTerm={searchTerm}
                onSearchChange={(value) => {
                    setSearchTerm(value);
                    setCurrentPage(1);
                }}
                statusFilter={statusFilter}
                onStatusFilterChange={(value) => {
                    setStatusFilter(value);
                    setCurrentPage(1);
                }}
                searchPlaceholder="Search by name, email, or reference..."
                statusOptions={repaymentStatusOptions}
            />

            <div className="sm:overflow-x-auto overflow-x-visible shadow-lg rounded-lg border border-gray-200">
            <table className="min-w-full bg-white">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-2 py-4 text-[10px] sm:px-3 sm:py-4 sm:text-xs text-leftfont-medium text-gray-500 uppercase tracking-wider">
                                Customer
                            </th>
                            <th className="px-2 py-4 text-[10px] sm:px-3 sm:py-4 sm:text-xs text-leftfont-medium text-gray-500 uppercase tracking-wider">
                                Order Reference
                            </th>
                            <th className="px-2 py-4 text-[10px] sm:px-3 sm:py-4 sm:text-xs text-leftfont-medium text-gray-500 uppercase tracking-wider">
                                Amount
                            </th>
                            <th className="px-2 py-4 text-[10px] sm:px-3 sm:py-4 sm:text-xs text-leftfont-medium text-gray-500 uppercase tracking-wider">
                                Payment Type
                            </th>
                            <th className="px-2 py-4 text-[10px] sm:px-3 sm:py-4 sm:text-xs text-leftfont-medium text-gray-500 uppercase tracking-wider">
                                Status
                            </th>
                            <th className="px-2 py-4 text-[10px] sm:px-3 sm:py-4 sm:text-xs text-leftfont-medium text-gray-500 uppercase tracking-wider">
                                Date
                            </th>
                            <th className="px-2 py-4 text-[10px] sm:px-3 sm:py-4 sm:text-xs text-leftfont-medium text-gray-500 uppercase tracking-wider">
                                Actions
                            </th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {repaymentData.map((repayment) => (
                            <React.Fragment key={repayment.id}>
                                <tr className="hover:bg-gray-50 transition-colors">
                                    <td className="px-2 py-4whitespace-nowrap">
                                        <div className="flex items-center">
                                            <div className="flex-shrink-0 h-10 w-10">
                                                <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                                                    <User className="h-5 w-5 text-indigo-600" />
                                                </div>
                                            </div>
                                            <div className="ml-4">
                                                <div className="text-sm font-medium text-gray-900">
                                                    {repayment.user.name}
                                                </div>
                                                <div className="text-sm text-gray-500">
                                                    {repayment.user.email}
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-2 py-4whitespace-nowrap">
                                        <div className="text-sm text-gray-900 font-mono">
                                            {repayment.order_reference}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                            {repayment.reference.substring(0, 20)}...
                                        </div>
                                    </td>
                                    <td className="px-2 py-4whitespace-nowrap">
                                        <div className="text-sm font-semibold text-gray-900">
                                            ₦{repayment.amount}
                                        </div>
                                        <div className="text-xs text-gray-500">
                                            of ₦{repayment.order.total_amount}
                                        </div>
                                    </td>
                                    <td className="px-2 py-4whitespace-nowrap">
                                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getPaymentTypeColor(repayment.order.payment_type)}`}>
                                            {repayment.order.payment_type}
                                            {repayment.order.payment_period && ` (${repayment.order.payment_period}mo)`}
                                        </span>
                                    </td>
                                    <td className="px-2 py-4whitespace-nowrap">
                                        <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(repayment.status)}`}>
                                            {repayment.status}
                                        </span>
                                    </td>
                                    <td className="px-2 py-4whitespace-nowrap text-sm text-gray-900">
                                        {formatDate(repayment.created_at)}
                                    </td>
                                    <td className="px-2 py-4whitespace-nowrap">
                                        <button
                                            onClick={() => toggleRow(repayment.id)}
                                            className="inline-flex items-center px-3 py-2 my-4 border border-green-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors"
                                        >
                                            <Eye className="h-4 w-4 mr-1" />
                                           
                                            {expandedRows.has(repayment.id) ? (
                                                <ChevronUp className="h-4 w-4 ml-1" />
                                            ) : (
                                                <ChevronDown className="h-4 w-4 ml-1" />
                                            )}
                                        </button>
                                    </td>
                                </tr>

                                {expandedRows.has(repayment.id) && (
                                    <tr>
                                        <td colSpan={7} className="px-2 py-4bg-gray-50">
                                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                              
                                                <div className="bg-white p-4 rounded-lg shadow-sm border mt-2">
                                                    <h4 className="flex items-center font-semibold text-gray-900 mb-3">
                                                        <User className="h-4 w-4 mr-2 text-indigo-600" />
                                                        Customer Details
                                                    </h4>
                                                    <div className="space-y-2 text-sm">
                                                        <div><span className="font-medium">Name:</span> {repayment.user.name}</div>
                                                        <div><span className="font-medium">Email:</span> {repayment.user.email}</div>
                                                        <div><span className="font-medium">Phone:</span> {repayment.user.phone}</div>
                                                        <div><span className="font-medium">City:</span> {repayment.user.city}</div>
                                                        <div><span className="font-medium">Address:</span> {repayment.user.address}</div>
                                                    </div>
                                                </div>

                                               
                                                <div className="bg-white p-4 rounded-lg shadow-sm border mt-2">
                                                    <h4 className="flex items-center font-semibold text-gray-900 mb-3">
                                                        <CreditCard className="h-4 w-4 mr-2 text-green-600" />
                                                        Payment Details
                                                    </h4>
                                                    <div className="space-y-2 text-sm">
                                                        <div><span className="font-medium">Payment Type:</span> {repayment.order.payment_type}</div>
                                                        <div><span className="font-medium">Payment Status:</span>
                                                            <span className={`ml-2 px-2 py-1 text-xs rounded-full ${getStatusColor(repayment.order.payment_status)}`}>
                                                                {repayment.order.payment_status}
                                                            </span>
                                                        </div>
                                                        <div><span className="font-medium">Current Amount:</span> ₦{repayment.amount}</div>
                                                        <div><span className="font-medium">Total Amount:</span> ₦{repayment.order.total_amount}</div>
                                                        {repayment.order.payment_period && (
                                                            <div><span className="font-medium">Payment Period:</span> {repayment.order.payment_period} months</div>
                                                        )}
                                                        {repayment.virtual_account_meta && (
                                                            <>
                                                                <div><span className="font-medium">Bank:</span> {repayment.virtual_account_meta.bank || 'N/A'}</div>
                                                                <div><span className="font-medium">Account:</span> {repayment.virtual_account_meta.account_number || 'N/A'}</div>
                                                            </>
                                                        )}
                                                    </div>
                                                </div>

                                               
                                                <div className="bg-white p-4 rounded-lg shadow-sm border mt-2">
                                                    <h4 className="flex items-center font-semibold text-gray-900 mb-3">
                                                        <Package className="h-4 w-4 mr-2 text-blue-600" />
                                                        Order Details
                                                    </h4>
                                                    <div className="space-y-2 text-sm">
                                                        <div><span className="font-medium">Order Ref:</span> {repayment.order_reference}</div>
                                                        <div><span className="font-medium">Transaction Ref:</span> {repayment.reference}</div>
                                                        <div className="mt-2">
                                                            <span className="font-medium">Bin Purchase:</span>
                                                            <div className="mt-1 space-y-1">
                                                                {Array.isArray(repayment.order.bin_purchase) ? (
                                                                    repayment.order.bin_purchase.map((item, idx) => (
                                                                        <div key={idx} className="text-xs bg-gray-100 px-2 py-1 rounded">
                                                                            {item.category} - Qty: {item.quantity}
                                                                        </div>
                                                                    ))
                                                                ) : (
                                                                    <div className="text-xs text-gray-500">No bin purchase details available</div>
                                                                )}
                                                            </div>
                                                        </div>
                                                        <div className="mt-2">
                                                            <span className="font-medium flex items-center">
                                                                <MapPin className="h-3 w-3 mr-1" />
                                                                Dispatch:
                                                            </span>
                                                            <div className="text-xs text-gray-600 mt-1">
                                                                {repayment.order.dispatch_details.dispatch_city}, {repayment.order.dispatch_details.dispatch_address}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div className="mt-4 flex justify-end space-x-3">
                                                <button className="px-4 py-4 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                                    Process Payment
                                                </button>
                                                <button className="px-4 py-4 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                                                    Send Reminder
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </React.Fragment>
                        ))}
                    </tbody>
                </table>
            </div>

            <div className="mt-4 text-sm text-gray-500 text-center">
                Showing {repaymentData.length} repayment records
            </div>
        </div>
    );
};

export default RepaymentsTable;