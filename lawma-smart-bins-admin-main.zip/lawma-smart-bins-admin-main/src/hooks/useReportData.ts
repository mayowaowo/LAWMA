
import { useState } from 'react';
import { orders, agents } from '@/utils/mockData';

export type ReportType = 'referrals' | 'direct' | 'all';

export interface ReportData {
  id: string;
  date: string;
  customerName: string;
  amount: number;
  source: string;
  status: string;
  agentName?: string;
}

export interface ReportSummary {
  totalOrders: number;
  totalAmount: number;
  referralCount: number;
  directCount: number;
  referralPercentage: number;
  directPercentage: number;
}

export const useReportData = () => {
  const [reportType, setReportType] = useState<ReportType>('all');

  const generateReportData = (): ReportData[] => {
    const allOrders = orders.map(order => {
      const agent = order.agentId ? agents.find(a => a.id === order.agentId) : undefined;
      
      return {
        id: order.id,
        date: order.orderDate,
        customerName: order.customerName,
        amount: order.totalAmount,
        source: order.agentId ? 'Referral' : 'Direct',
        status: order.status,
        agentName: agent?.name
      };
    });

    if (reportType === 'referrals') {
      return allOrders.filter(order => order.source === 'Referral');
    } else if (reportType === 'direct') {
      return allOrders.filter(order => order.source === 'Direct');
    }
    
    return allOrders;
  };

  const calculateSummary = (data: ReportData[]): ReportSummary => {
    const totalOrders = data.length;
    const totalAmount = data.reduce((sum, order) => sum + order.amount, 0);
    const referralCount = data.filter(order => order.source === 'Referral').length;
    const directCount = data.filter(order => order.source === 'Direct').length;
    
    return {
      totalOrders,
      totalAmount,
      referralCount,
      directCount,
      referralPercentage: totalOrders ? (referralCount / totalOrders) * 100 : 0,
      directPercentage: totalOrders ? (directCount / totalOrders) * 100 : 0
    };
  };

  const reportData = generateReportData();
  const summary = calculateSummary(reportData);

  return {
    reportType,
    setReportType,
    reportData,
    summary
  };
};

