
import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { bins as initialBins } from "@/utils/mockData";
import { Bin } from "@/utils/mockData/types";
import {getAllBin} from "@/services/api/services/userService.ts";
import {useSettings} from "@/services/api/hooks/settings.ts";

type ValidationErrors = {
  name?: string;
  sku?: string;
  amount?: string;
  stock?: string;
};

export const useBinManagement = () => {
  const { toast } = useToast();
  const [bins, setBins] = useState<Bin[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const {addNewBin, editBin} = useSettings()
  const [isAddingBin, setIsAddingBin] = useState(false);
  const [isEditingBin, setIsEditingBin] = useState(false);
  const [validationErrors, setValidationErrors] = useState<ValidationErrors>({});
  const [selectedBin, setSelectedBin] = useState<Partial<Bin>>({
    name: '',
    sku: '',
    description: '',
    amount: 0,
    stock: 0,
    imageUrl: '/placeholder.svg'
  });

  const validateBin = (bin: Partial<Bin>): ValidationErrors => {
    const errors: ValidationErrors = {};

    if (!bin.name?.trim()) {
      errors.name = "Bin name is required";
    }

    if (!bin.sku?.trim()) {
      errors.sku = "SKU is required";
    }

    if (bin.amount !== undefined && bin.amount < 0) {
      errors.amount = "Price must be a positive number";
    }

    if (bin.stock !== undefined && bin.stock < 0) {
      errors.stock = "Stock quantity must be a positive number";
    }

    return errors;
  };

  const handleAddBin = async (newBin: Partial<Bin>) => {
    const errors = validateBin(newBin);
    setValidationErrors(errors);

    if (Object.keys(errors).length > 0) {
      toast({
        title: "Validation Error",
        description: "Please fix the highlighted fields",
        variant: "destructive"
      });
      return;
    }

    try {
      setIsAddingBin(true);

      const formData = new FormData();

      // Add each field to the FormData
      Object.entries(newBin).forEach(([key, value]) => {
        // Skip null or undefined values
        if (value !== null && value !== undefined) {
          // Handle file/image separately if it exists
          if (key === 'image' && value && typeof value === 'object' && value instanceof File) {
            formData.append('image', value);
          } else {
            formData.append(key, value.toString());
          }
        }
      });


      const {success, results} = await addNewBin(formData)
      // console.log(success, results, 'oooo');
      if(success) {
        toast({
          title: "Success",
          description: "Bin added successfully"
        });
        setIsAddingBin(false);
        await getAllBinsType()

      }

      setIsAddingBin(false);
      setSelectedBin({
        name: '',
        sku: '',
        description: '',
        amount: 0,
        stock: 0,
        imageUrl: '/placeholder.svg'
      });
      setValidationErrors({});


    } catch (error) {
      setIsAddingBin(false);

      toast({
        title: "Error",
        description: "Failed to add bin. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleEditBin = async (updatedBin: Partial<Bin>) => {
    const errors = validateBin(updatedBin);
    setValidationErrors(errors);

    if (Object.keys(errors).length > 0) {
      toast({
        title: "Validation Error",
        description: "Please fix the highlighted fields",
        variant: "destructive"
      });
      return;
    }

    // console.log(updatedBin);

    try {
      setIsEditingBin(true);

      const formData = new FormData();


      Object.entries(updatedBin).forEach(([key, value]) => {
        // Skip null or undefined values
        if (value !== null && value !== undefined) {
          // Handle file/image separately if it exists
          if (key === 'image' && value && typeof value === 'object' && value instanceof File) {
            formData.append('image', value);
          } else {
            formData.append(key, value.toString());
          }
        }
      });


      const {success, results} = await editBin(updatedBin.id, formData)
      console.log(success, results, 'oooo');
      if (success) {
        toast({
          title: "Success",
          description: "Bin updated successfully"
        });
        setIsEditingBin(false);

        await getAllBinsType()

      }

      setIsEditingBin(false);
      setSelectedBin({
        name: '',
        sku: '',
        description: '',
        amount: 0,
        stock: 0,
        imageUrl: '/placeholder.svg'
      });
      setValidationErrors({});

    } catch (error) {
      setIsEditingBin(false);
      toast({
        title: "Error",
        description: "Failed to update bin. Please try again.",
        variant: "destructive"
      });
    }
  };

  const startEditBin = (bin: Bin) => {
    setSelectedBin(bin);
    setIsEditingBin(true);
    setValidationErrors({});
  };

  const getAllBinsType = async () => {
    let userResponse = null;
    setLoading(true);
    try {
      const response = await getAllBin();
      userResponse = response?.data?.data;
      if (userResponse) {
        setLoading(false);
        setBins(userResponse[0])
        return {success: true, results: userResponse};
      }
    } catch (e) {
      // console.log(e.response?.data?.message);
      setLoading(false);
      return {success: false, error: e.response?.data?.message};
    }

    return userResponse;
  };


  return {
    bins,
    isAddingBin,
    setIsAddingBin,
    isEditingBin,
    setIsEditingBin,
    selectedBin,
    setSelectedBin,
    handleAddBin,
    handleEditBin,
    startEditBin,
    validationErrors,
    getAllBinsType,
    loading
  };
};
