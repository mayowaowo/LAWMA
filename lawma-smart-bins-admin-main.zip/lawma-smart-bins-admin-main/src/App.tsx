import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import DashboardLayout from "./components/layout/DashboardLayout";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import Orders from "./pages/Orders";
import Referrals from "./pages/Referrals";
import Reports from "./pages/Reports";
import Users from "./pages/Users";
import NotFound from "./pages/NotFound";
import Settings from "./pages/Settings";
import {Provider} from "react-redux";
import store from "@/services/store/store.ts";
import {ProtectedRoutes} from "@/services/constant/protectedRoutes.tsx";
import SessionWrapper from "@/utils/SessionWrapper.tsx";

// Create a client
const queryClient = new QueryClient();

const App: React.FC = () => (

    <Provider store={store}>
      <SessionWrapper>
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <Toaster/>
            <Sonner/>
            {/*<Helmet titleTemplate="%s | Smart Waste Bin Admin" defaultTitle="Smart Waste Bin Admin"/>*/}
            <AuthProvider>
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<Index/>}/>
                  <Route element={<ProtectedRoutes/>}>
                    <Route path="/*" element={<DashboardLayout/>}/>
                  </Route>

                  <Route path="*" element={<NotFound/>}/>
                </Routes>
              </BrowserRouter>
            </AuthProvider>
          </TooltipProvider>
        </QueryClientProvider>
      </SessionWrapper>
    </Provider>
);
export default App;
