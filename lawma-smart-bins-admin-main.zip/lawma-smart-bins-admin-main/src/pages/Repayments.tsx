import RepaymentsTable from '@/components/repayments/RepaymentsTable';
import {useState} from 'react';

const Repayments = () => {
    const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
    const [isAddUserOpen, setIsAddUserOpen] = useState(false);


    return (
        <>
            <div className="space-y-6">
                <RepaymentsTable />
            </div>
        </>
    );
};

export default Repayments;
