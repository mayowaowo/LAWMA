
import {useEffect, useState} from 'react';
import UsersTable from '@/components/users/UsersTable';
import AddUserForm from '@/components/users/AddUserForm';
import { Button } from "@/components/ui/button";
import { PlusCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogHeader } from '@/components/ui/dialog';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import {useUsers} from "@/services/api/hooks/users.ts";

const Users = () => {
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const { hasPermission } = useAuth();
  const { toast } = useToast();
  const {getUsers, } = useUsers()
  const canManageUsers = hasPermission(['super_admin']);

  const handleOpenAddUser = () => {
    if (!canManageUsers) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to add new users",
        variant: "destructive"
      });
      return;
    }
    setIsAddUserOpen(true);
  };

  useEffect(() => {
    getUsers()
  }, [])

  return (
    <>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Users</h1>
            <p className="text-muted-foreground">
              Manage users and their permissions in the system.
            </p>
          </div>
          <Button onClick={handleOpenAddUser}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add User
          </Button>
        </div>

        <UsersTable />

        <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New User</DialogTitle>
            </DialogHeader>
            <AddUserForm onSuccess={() => setIsAddUserOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default Users;
