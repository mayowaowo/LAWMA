
import { useState } from 'react';
import { orders, agents } from '@/utils/mockData';
import AgentsTable from '@/components/referrals/AgentsTable';
import CustomerList from '@/components/referrals/CustomerList';
import {PlusCircle} from "lucide-react";
import {Button} from "@/components/ui/button.tsx";
import AddUserForm from "@/components/users/AddUserForm.tsx";
import AddAgentForm from "@/components/referrals/AddAgent.tsx";
import {Dialog, DialogContent, DialogHeader, DialogTitle} from "@/components/ui/dialog.tsx";

const Referrals = () => {
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);


  const handleOpenAddUser = () => {

    setIsAddUserOpen(true);
  };
  return (
    <>
      <div className="space-y-6">
        <div className={'flex flex-wrap justify-between'}>
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Agents Management</h1>
            <p className="text-muted-foreground">
              Track agent performance, manage commissions and agent referrals.
              Each agent earns a commission when their referral code is used on a purchase.
            </p>
          </div>
          <Button onClick={handleOpenAddUser}>
            <PlusCircle className="mr-2 h-4 w-4"/>
            Add Agent
          </Button>
        </div>


        <AgentsTable onSelectAgent={setSelectedAgentId} selectedAgentId={selectedAgentId} />

        {/*{selectedAgentId && (*/}
        {/*  <CustomerList */}
        {/*    agentId={selectedAgentId}*/}
        {/*    agent={agents.find(a => a.id === selectedAgentId)}*/}
        {/*    customers={orders.filter(order => order.agentId === selectedAgentId)}*/}
        {/*  />*/}
        {/*)}*/}
        <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Agent</DialogTitle>
            </DialogHeader>
            <AddAgentForm onSuccess={() => setIsAddUserOpen(false)}/>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
};

export default Referrals;
