
import React, {useEffect, useState} from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { toast } from "@/hooks/use-toast";
import {useDispatch, useSelector} from "react-redux";
import {handleFailure, handleLoginRequest, updateEmailVerification} from "@/services/constant/actions.ts";
import {RootState} from "@/services/reducers/rootReducer.ts";
import {Auth} from "@/services/constant/actionTypes.ts";
import {Eye, EyeOff} from "lucide-react";
import {emailVerification} from "@/services/api/hooks/Login.ts";
import OtpModal from "@/components/OtpModal.tsx";

const Index = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const AuthState = useSelector((state: RootState) => state.auth as Auth);
  const UserState = useSelector((state: RootState) => state.user);
  const {loading} = AuthState;
  const {user} = UserState;

  const [showPassword, setShowPassword] = useState(false);
  const [isOtpModalOpen, setIsOtpModalOpen] = useState(false)
  const [submitLoading, setSubmitLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault(); // Prevent the form from refreshing the page
    // console.log('hshs')
    // console.log("Setting isLoading to true...");
    setIsLoading(true); // Log here
    // console.log("isLoading State (after true):", isLoading);

    // Check if email or password is missing
    if (!email || !password) {
      toast({
        title: "Login failed",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }


    try {
      const loginData = {
        email: email,
        password: password,
      };

      // Dispatch login request and handle the success callback
      dispatch(
          handleLoginRequest({
            payload: loginData,
            navigate: navigate,
            onSuccess: () => {
              if (email === 'lsb@admin.com') {
                navigate("/dashboard");
              } else {
                setIsOtpModalOpen(true);
              }
              // navigate("/dashboard");
            },
          })
      );
    } catch (error) {
      // Handle errors (if the `handleLoginRequest` action fails)
      toast({
        title: "Login failed",
        description: "Invalid email or password",
        variant: "destructive",
      });
      console.error("Error during login:", error);
    } finally {
      // Ensure setIsLoading(false) is always executed
      setIsLoading(false);
    }
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      await login(email, password);
      toast({
        title: "Login successful",
        description: "Welcome to the Smart Waste Bin Admin Portal",
      });
      navigate("/dashboard");
    } catch (error) {
      toast({
        title: "Login failed",
        description: "Invalid email or password",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOtpSubmit = async (otp: string) => {
    setSubmitLoading(true)
    const payload = {
      id: user.uuid,
      otp: otp,
    }
    const res = await emailVerification(payload, navigate)
    if (res.success) {
      setSubmitLoading(false)
      dispatch(updateEmailVerification(false))
      setIsOtpModalOpen(false)
      navigate("/dashboard");
    }
    setSubmitLoading(false)

  }

    useEffect(() => {
        dispatch(handleFailure())
    }, []);
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-green-50 to-green-100 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-green-700">Smart Waste Bins</h1>
          <p className="text-gray-600 mt-2" onClick={() => setIsLoading(true)}>Smart Waste Bin Management System</p>
        </div>

        <Card>
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold text-center">Admin Login</CardTitle>
            <CardDescription className="text-center">
              Enter your credentials to access the admin portal
            </CardDescription>
          </CardHeader>
          <form onSubmit={handleLogin}>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                  <a href="#" className="text-xs text-primary hover:underline">
                    Forgot password?
                  </a>
                </div>
                <div className={'relative'}>
                  <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                  />
                  <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 h-4 w-4 text-gray-400 cursor-pointer hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff size={16}/> : <Eye size={16}/>}
                  </button>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                type="submit"
                className="w-full bg-primary hover:bg-primary/90"
                disabled={loading}
              >
                {loading ? "Signing in..." : "Sign In"}
              </Button>
            </CardFooter>
          </form>
          <OtpModal
              isOpen={isOtpModalOpen}
              onClose={() => {
                dispatch(updateEmailVerification(false))
                setIsOtpModalOpen(false)
              }}
              onSubmit={handleOtpSubmit}
              loading={submitLoading}/>
        </Card>

        <div className="text-center mt-6 text-sm text-gray-600">
          <p>&copy; {new Date().getFullYear()} Smart Waste Bin Management. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default Index;
