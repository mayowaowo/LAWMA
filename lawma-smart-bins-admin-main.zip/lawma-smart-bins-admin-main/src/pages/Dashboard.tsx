import DashboardStats from '@/components/dashboard/DashboardStats';

const Dashboard = () => {
  return (
    <>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome to the Smart Waste Bin Admin Portal. Here's an overview of your system.
          </p>
        </div>

        <DashboardStats />
      </div>
    </>
  );
};

export default Dashboard;
