
import {useEffect, useState} from 'react';
import ReportGenerator from '@/components/reports/ReportGenerator';
import ReportFilters from '@/components/reports/ReportFilters';
import ReportComparison from '@/components/reports/ReportComparison';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Filter, BarChart2 } from 'lucide-react';
import {useReport} from "@/services/api/hooks/reports.ts";
import {ReportFilter} from "@/services/constant/actionTypes.ts";

const CardSkeleton = () => (
    <Card>
      <CardHeader className="space-y-2">
        <div className="flex items-center gap-2">
          <div className="h-5 w-5 rounded bg-gray-200 animate-pulse"/>
          {/* Icon */}
          <div className="h-6 w-48 bg-gray-200 rounded animate-pulse"/>
          {/* Title */}
        </div>
        <div className="h-4 w-72 bg-gray-200 rounded animate-pulse"/>
        {/* Description */}
      </CardHeader>
      <CardContent>
        {/* Content Skeleton */}
        <div className="space-y-4">
          <div className="h-10 bg-gray-200 rounded animate-pulse"/>
          <div className="grid grid-cols-3 gap-4">
            <div className="h-32 bg-gray-200 rounded animate-pulse"/>
            <div className="h-32 bg-gray-200 rounded animate-pulse"/>
            <div className="h-32 bg-gray-200 rounded animate-pulse"/>
          </div>
          <div className="h-40 bg-gray-200 rounded animate-pulse"/>
        </div>
      </CardContent>
    </Card>
);

const ReportsSkeleton = () => {
  return (
      <div className="space-y-6">
        {/* Header Section */}
        <div className="space-y-2">
          <div className="h-9 w-48 bg-gray-200 rounded animate-pulse"/>
          {/* Title */}
          <div className="h-5 w-96 bg-gray-200 rounded animate-pulse"/>
          {/* Subtitle */}
        </div>

        {/* Tabs Section */}
        <div className="space-y-6">
          {/* Tab Triggers */}
          <div className="grid grid-cols-3 gap-2 w-full max-w-md">
            {[...Array(3)].map((_, index) => (
                <div
                    key={index}
                    className="h-10 bg-gray-200 rounded animate-pulse"
                />
            ))}
          </div>

          {/* Tab Content */}
          <div className="mt-6">
            <CardSkeleton/>
          </div>
        </div>
      </div>
  );
};




const Reports = () => {
  const [activeTab, setActiveTab] = useState('generator');
  const {getReports, loading, report, exportReports} = useReport()

  useEffect(() => {
    getReports()
  }, []);

  // State for filters
  const [filters, setFilters] = useState<ReportFilter>({
    customerName: '',
    source: 'all',
    status: 'all',
    binType: 'all',
    dateRange: {
      from: undefined,
      to: undefined
    }
  });

  // State for filtered report data
  const [filteredReport, setFilteredReport] = useState(report);

  useEffect(() => {
    getReports();
  }, []);

  useEffect(() => {
    if (!report) return;

    // Create a deep copy of the report
    const reportCopy = JSON.parse(JSON.stringify(report));

    // Apply filters to the orders
    if (reportCopy.order && reportCopy.order.length > 0) {
      reportCopy.order = reportCopy.order.filter(order => {
        // Filter by customer name
        if (filters.customerName &&
            !order.users.name.toLowerCase().includes(filters.customerName.toLowerCase())) {
          return false;
        }

        // Filter by source
        if (filters.source !== 'all') {
          const isReferral = order.referral === 1;
          if ((filters.source === 'referral' && !isReferral) ||
              (filters.source === 'direct' && isReferral)) {
            return false;
          }
        }

        // Filter by status
        if (filters.status !== 'all' && order.status !== filters.status) {
          return false;
        }

        // Filter by bin type
        if (filters.binType !== 'all' && order.bin_type !== filters.binType) {
          return false;
        }

        // Filter by date range
        if (filters.dateRange.from || filters.dateRange.to) {
          const orderDate = new Date(order.created_at);

          if (filters.dateRange.from && orderDate < filters.dateRange.from) {
            return false;
          }

          if (filters.dateRange.to) {
            // Add one day to include the end date
            const endDate = new Date(filters.dateRange.to);
            endDate.setDate(endDate.getDate() + 1);
            if (orderDate > endDate) {
              return false;
            }
          }
        }

        return true;
      });

      // Recalculate summary stats based on filtered orders
      if (reportCopy.summary) {
        const totalAmount = reportCopy.order.reduce((sum, order) => sum + Number(order.total_amount), 0);
        const referralCount = reportCopy.order.filter(order => order.agentId).length;
        const directCount = reportCopy.order.filter(order => !order.agentId).length;
        const totalCount = reportCopy.order.length;

        reportCopy.summary = {
          ...reportCopy.summary,
          total_amount: totalAmount,
          total_orders: totalCount,
          referral_count: referralCount,
          direct_count: directCount,
          referral_percentage: totalCount ? (referralCount / totalCount) * 100 : 0,
          direct_percentage: totalCount ? (directCount / totalCount) * 100 : 0
        };
      }
    }

    // console.log(reportCopy, 'reports copy');
    setFilteredReport(reportCopy);
  }, [report, filters]);

  const handleApplyFilters = (newFilters) => {
    setFilters(newFilters);
    setActiveTab('generator');
  };


  if (loading) {
    return <ReportsSkeleton/>;
  }

  return (
    <>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
          <p className="text-muted-foreground">
            Generate, filter, compare, and export sales and referral data.
          </p>
        </div>

        <Tabs defaultValue="generator" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-3 w-full max-w-md">
            <TabsTrigger value="generator" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              <span>Generator</span>
            </TabsTrigger>
            <TabsTrigger value="filters" className="flex items-center gap-2">
              <Filter className="h-4 w-4" />
              <span>Filters</span>
            </TabsTrigger>
            <TabsTrigger value="comparison" className="flex items-center gap-2">
              <BarChart2 className="h-4 w-4" />
              <span>Comparison</span>
            </TabsTrigger>
          </TabsList>

          <div className="mt-6">
            <TabsContent value="generator">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    <span>Report Generator</span>
                  </CardTitle>
                  <CardDescription>
                    Generate comprehensive reports on sales and referrals
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportGenerator report={filteredReport} exportReports={exportReports} filters={filters}
                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="filters">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Filter className="h-5 w-5" />
                    <span>Report Filters</span>
                  </CardTitle>
                  <CardDescription>
                    Filter data for more targeted report analysis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportFilters
                      initialFilters={filters}
                      onApplyFilters={handleApplyFilters}

                  />
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="comparison">
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl flex items-center gap-2">
                    <BarChart2 className="h-5 w-5" />
                    <span>Report Comparison</span>
                  </CardTitle>
                  <CardDescription>
                    Compare data across different time periods or categories
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ReportComparison />
                </CardContent>
              </Card>
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </>
  );
};

export default Reports;
