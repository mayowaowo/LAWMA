import { useAuth } from '@/context/AuthContext';
import RoleManagement from '@/components/settings/RoleManagement';
import BinManagement from '@/components/settings/BinManagement';
import CommissionManagement from '@/components/settings/CommissionManagement';
import { Shield } from 'lucide-react';

const Settings = () => {
  const { hasPermission } = useAuth();
  const canManageRoles = hasPermission(['super_admin']);
  const canManageBins = hasPermission(['super_admin', 'order_manager']);
  const canManageCommissions = hasPermission(['super_admin', 'referral_manager']);

  return (
    <>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground">
            Manage system settings and configurations.
          </p>
        </div>

        {canManageCommissions && <CommissionManagement />}
        {canManageBins && <BinManagement />}
        {canManageRoles && <RoleManagement />}
      </div>
    </>
  );
};

export default Settings;
