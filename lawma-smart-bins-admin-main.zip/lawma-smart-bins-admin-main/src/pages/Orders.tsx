
import OrdersTable from '@/components/orders/OrdersTable';
import {useEffect} from "react";
import {useOrder} from "@/services/api/hooks/order.ts";

const Orders = () => {
    // const {getOrders} = useOrder()
    //
    // useEffect(() => {
    //     getOrders();
    // }, [])
  return (
    <>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Orders</h1>
          <p className="text-muted-foreground">
            Manage customer waste bin orders, payments, and deliveries.
          </p>
        </div>

        <OrdersTable />
      </div>
    </>
  );
};

export default Orders;
