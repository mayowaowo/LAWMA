import {useState} from 'react';
import {orders, agents} from '@/utils/mockData';
import AgentsTable from '@/components/referrals/AgentsTable';
import CustomerList from '@/components/referrals/CustomerList';
import {PlusCircle} from "lucide-react";
import {Button} from "@/components/ui/button.tsx";
import AddUserForm from "@/components/users/AddUserForm.tsx";
import AddAgentForm from "@/components/referrals/AddAgent.tsx";
import {Dialog, DialogContent, DialogHeader, DialogTitle} from "@/components/ui/dialog.tsx";
import CustomersTable from "@/components/customers/CustomersTable.tsx";

const Customers = () => {
    const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);
    const [isAddUserOpen, setIsAddUserOpen] = useState(false);


    return (
        <>
            <div className="space-y-6">
                <div className={'flex flex-wrap justify-between'}>
                    <div>
                        <h1 className="text-3xl font-bold tracking-tight">Customers</h1>
                        <p className="text-muted-foreground">
                            View and manage all registered customers.
                        </p>
                    </div>

                </div>


                <CustomersTable onSelectAgent={setSelectedAgentId} selectedAgentId={selectedAgentId}/>

            </div>
        </>
    );
};

export default Customers;
