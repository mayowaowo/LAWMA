import ActivityLogTable from '@/components/ActivityLogTable';

const ActivityLog = () => {
  
    return (
            <div>
                <ActivityLogTable />
            </div>
    );
};

export default ActivityLog;
