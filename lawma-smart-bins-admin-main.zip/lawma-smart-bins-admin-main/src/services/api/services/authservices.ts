import {unauthorized} from "@/services/api/constant/axios.ts";
import {
  EMAIL_VERIFICATION,
  FORGOT_PASSWORD,
  LOGIN,
  REGISTER,
  RESEND_OTP
} from "@/services/api/constant/service-routes.ts";
import {Login} from "@/services/constant/actionTypes.ts";
import {Register} from "@tanstack/react-query";


export const postLogin = (payload: Login) => {
  return unauthorized.post(LOGIN, payload);
};

export const postRegister = (payload: Register) => {
  return unauthorized.post(REGISTER, payload);
};

// export const postVerifyOtp = (payload: Otp) => {
//   return unauthorized.post(REGISTER_VERIFY_OTP, payload);
// };

// export const postForgottenPassword = (payload: ForgotPassword) => {
//   return unauthorized.post(FORGOT_PASSWORD, payload);
// };

export const getResendOtp = (uuid) => {
  return unauthorized.get(`${RESEND_OTP}/${uuid}`);
};

export const postEmailVerification = (payload) => {
  return unauthorized.post(EMAIL_VERIFICATION, payload);
};
