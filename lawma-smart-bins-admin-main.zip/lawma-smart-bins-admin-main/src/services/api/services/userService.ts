import {
  ADD_ADMIN_USER,
  ADD_BIN, CREATE_AGENT, EDIT_BIN, EDIT_COMMISSION, EXPORT_REPORTS, GET_AGENTS, GET_BIN, GET_COMMISSION, GET_CUSTOMERS,
  GET_DASHBOARD,
  GET_ORDER, GET_REPORTS, GET_ROLES, GET_USER,
  ORDER_HISTORY,
  REPAYMENT_ORDER, UPDATE_ORDER_STATUS, GET_USER_ORDER,
  GET_REPAYMENTS,
  GET_ACTIVITYLOG,
  GET_ORDER_INFO, EDIT_USER_ROLES, POST_MARK_COMMISSION
} from "@/services/api/constant/service-routes.ts";
import {authorized, unauthorized} from "@/services/api/constant/axios.ts";
import {ObjectTypes, OrderPayload} from "@/services/constant/actionTypes.ts";

export const getDashboard = () => {
  return authorized.get(`${GET_DASHBOARD}`);
};

export const getOrders = () => {
  return authorized.get(`${GET_ORDER}`);
};

export const getOrderHistory = () => {
  return authorized.get(ORDER_HISTORY);
};

export const postRepayment = (payload) => {
  return authorized.post(REPAYMENT_ORDER, payload);
};

export const postOrderStatus = (id,payload) => {
  return authorized.post(`${UPDATE_ORDER_STATUS}/${id}`, payload);
};

export const getAllRoles = () => {
  return authorized.get(GET_ROLES);
};

export const getAllBin = () => {
  return authorized.get(GET_BIN);
};

export const postAddBin = (payload) => {
  return authorized.post(ADD_BIN, payload);
};

export const postEditBin = (id, payload) => {
  return authorized.post(`${EDIT_BIN}/${id}`, payload);
};

export const getAllCommission = () => {
  return authorized.get(GET_COMMISSION);
};

export const postEditCommission = (id, payload) => {
  return authorized.post(`${EDIT_COMMISSION}/${id}`, payload);
};

export const postAddAdminUser = ( payload) => {
  return authorized.post(`${ADD_ADMIN_USER}`, payload);
};

export const getAllAgents = () => {
  return authorized.get(GET_AGENTS);
};

export const getAllCustomers = () => {
  return authorized.get(GET_CUSTOMERS);
};

export const postUpdateAgents = (agentId) => {
  return authorized.post(`${GET_AGENTS}/deactivate/${agentId}`);
};

export const postMarkCommissions = (agentId) => {
  return authorized.post(`${POST_MARK_COMMISSION}/${agentId}`);
};

export const putEditUserRoles = (userid, payload) => {
  return authorized.put(`${EDIT_USER_ROLES}/${userid}/role`, payload);
};

export const postActivateAgents = (agentId) => {
  return authorized.post(`${GET_AGENTS}/activate/${agentId}`);
};


export const postCreateAgent = (payload) => {
  return authorized.post(`${CREATE_AGENT}`, payload);
};

export const getAllReports = () => {
  return authorized.get(GET_REPORTS);
};

export const getExportReport = (params: ObjectTypes) => {
  return authorized.get(`${EXPORT_REPORTS}`, {
    params,
    responseType: "blob",
      }
  );
};

export const getAllUser = () => {
  return authorized.get(GET_USER);
};

export const getUserOrder = (userId: string) => {
  return authorized.get(`${GET_USER_ORDER}/${userId}`);
};

export const getRepayments = () => {
  return authorized.get(GET_REPAYMENTS);
};

export const getActivityLogs = () => {
  return authorized.get(GET_ACTIVITYLOG);
};

export const getOrderInfo = (orderReference) => {
  return authorized.get(`${GET_ORDER_INFO}/${orderReference}`);
};
