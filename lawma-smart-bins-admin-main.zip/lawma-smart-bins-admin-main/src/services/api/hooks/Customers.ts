import { useRef, useState } from "react";
import {
    getAllAgents, getAllCustomers, getUserOrder, postCreateAgent, postUpdateAgents,
} from "@/services/api/services/userService.ts";
import { toast } from "sonner";

export const useCustomers = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const didFetch = useRef<boolean>(false);
    const [customer, setAgents] = useState([]);

    const getCustomers = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getAllCustomers();
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setAgents(userResponse[0])
                return { success: true, results: userResponse };
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return { success: false, error: e.response?.data?.message };
        }

        return userResponse;
    };

    const getUserOrderHistory = async (userId: string) => {
        try {
            const response = await getUserOrder(userId);
            // console.log("Order history API response:", response);

            const rawResults = response?.data?.data[0];
            // console.log("Order history API rawResults:", rawResults);

            const orders = response?.data?.data[0].data || [];
            // console.log("Order history API orders:", orders);

            return {
                success: orders.length > 0, // Base success on having data
                // OR if you know the API structure better:
                // success: rawResults && Array.isArray(rawResults.data),
                results: Array.isArray(orders) ? orders : [],
                error: null,
            };
        } catch (error: any) {
            console.error("Error in getUserOrderHistory:", error);
            return {
                success: false,
                results: [],
                error: error?.response?.data?.message || "Failed to fetch orders",
            };
        }
    };


    return {
        loading,
        getCustomers,
        getUserOrderHistory,
        customer,
    }
}
