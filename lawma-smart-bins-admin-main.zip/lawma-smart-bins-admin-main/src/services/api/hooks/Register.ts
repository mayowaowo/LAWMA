import { postRegister } from '../services/authservices';
import { NavigateFunction } from 'react-router-dom';
import {Register} from "@/services/constant/actionTypes.ts";

export const registerUser = async (payload: Register, navigate: NavigateFunction) => {
  let userResponse = null;

  try {
    const response = await postRegister(payload);
    console.log('registerUser', response);
    userResponse = response?.data?.data[0];
    if (userResponse) {
      console.log(navigate);
      const { uuid } = userResponse;
      // navigate('/account')
      return { success: true, data: uuid, user: userResponse };
    }
  } catch (e) {
    const allErrors = e?.response?.data?.errors;
    const firstError = allErrors ? Object.values(allErrors).find(error => error) : e.response.data.message;
    console.log('kddk', allErrors);
    return { success: false, error: firstError };
  }

  return userResponse;
};
