import { Login } from '@/services/constant/actionTypes';
import { NavigateFunction } from 'react-router-dom';
import {getResendOtp, postEmailVerification, postLogin} from "@/services/api/services/authservices.ts";
import {toast} from "sonner";
import store from "@/services/store/store.ts";
import {handleLoginSuccess, handleSaveUserData} from "@/services/constant/actions.ts";

// const stores = store.getState()

export const loginUser = async (payload: Login, navigate: NavigateFunction) => {
  let userResponse = null;
  // const { showToast } = useToast();
  try {
    const response = await postLogin(payload);
    userResponse = response?.data?.data;
    // console.log(userResponse, 'login user response');
    if (userResponse) {
      const access_token = userResponse.token;
      // navigate('/order');
      return { success: true, data: access_token, user: userResponse.user };
    }
  } catch (e) {
    // console.log('gdgdgd', e);
    // showToast('Error', e.response.data.message, 'error');
    return { success: false, error: e.response.data.message };
  }

  return userResponse;
};

export const getOtp = async (uuid) => {
  let userResponse = null;

  try {
    const response = await getResendOtp(uuid);
    userResponse = response?.data?.data[0];
    if (userResponse) {
      toast.success('Otp Sent Successful!');

      // navigate('/account')
      return {success: true, data: uuid, user: userResponse};
    }
  } catch (e) {
    const allErrors = e?.response?.data?.errors;
    const firstError = allErrors ? Object.values(allErrors).find(error => error) : e.response.data.message;
    return {success: false, error: firstError};
  }

  return userResponse;
};

export const emailVerification = async (payload, navigate: NavigateFunction, source?: 'register' | 'login'
) => {
  let userResponse = null;

  try {
    const response = await postEmailVerification(payload);
    // console.log(response);
    userResponse = response?.data?.data;
    if (userResponse) {
      const {user, token} = userResponse;
      store.dispatch(handleLoginSuccess({token, email: user.email}));

      store.dispatch(handleSaveUserData( user));

      navigate('/dashboard');

      toast.success(response.data.message);

      return {success: true, data: user, user: userResponse};
    }
  } catch (e) {
    const allErrors = e?.response?.data?.message;
    const firstError = allErrors ? Object.values(allErrors).find(error => error) : e.response.data.message;
    toast.error(allErrors);

    return {success: false, error: firstError};
  }

  return userResponse;
};
