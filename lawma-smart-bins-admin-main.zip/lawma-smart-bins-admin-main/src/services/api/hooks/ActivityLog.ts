import { useRef, useState } from "react";
import { toast } from "sonner";
import { getActivityLogs } from "@/services/api/services/userService";

interface User {
    id?: number;
    name?: string;
    email?: string;
    email_verified_at?: string | null;
    created_at?: string;
    updated_at?: string;
    uuid?: string | null;
    type?: string;
    phone?: string;
    city?: string | null;
    postal_code?: string | null;
    address?: string | null;
    status?: number;
    referral_code?: string | null;
    last_login?: string;
    login_count?: number;
    installment_verification_status?: number;
    commision_rate?: number | null;
  }
  
  export interface ActivityLog {
    id?: number;
    user_id?: number;
    resource?: string;
    payload?: string;
    response?: string | null;
    ip_address?: string;
    action?: string;
    description?: string;
    created_at?: string;
    updated_at?: string;
    user?: User;
  }

export const useActivityLogs = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const didFetch = useRef<boolean>(false);

  const fetchActivityLogs = async (params?: Record<string, any>) => {
    if (didFetch.current && !params?.forceRefresh) return;

    setLoading(true);
    try {
      const response = await getActivityLogs();
      const data = response?.data?.data;

      if (Array.isArray(data) && data.length > 0) {
        setActivityLogs(data);
        didFetch.current = true;
        return { success: true, results: data };
      } else {
        toast.error("No activity logs found.");
        return { success: false, error: "Empty data" };
      }
    } catch (error: any) {
      const errorMsg = error?.response?.data?.message || "Failed to fetch activity logs";
      toast.error(errorMsg);
      return { success: false, error: errorMsg };
    } finally {
      setLoading(false);
    }
  };

  const refreshActivityLogs = async () => {
    didFetch.current = false;
    return await fetchActivityLogs({ forceRefresh: true });
  };

  return {
    loading,
    activityLogs,
    fetchActivityLogs,
    refreshActivityLogs,
  };
};