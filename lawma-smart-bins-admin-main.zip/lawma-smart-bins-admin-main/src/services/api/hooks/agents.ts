import {useRef, useState} from "react";
import {
    getAllAgents, postActivateAgents, postCreateAgent, postMarkCommissions, postUpdateAgents,
} from "@/services/api/services/userService.ts";
import {toast} from "sonner";

export const useAgent = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const didFetch = useRef<boolean>(false);
    const [agents, setAgents] = useState([]);

    const getAgents = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getAllAgents();
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setAgents(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const markCommissionPaid = async (id) => {
        // if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postMarkCommissions(id);
            // console.log('update agent', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setAgents(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const updateAgents = async (id) => {
        // if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postUpdateAgents(id);
            // console.log('update agent', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setAgents(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const activateAgents = async (id) => {
        // if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postActivateAgents(id);
            // console.log('update agent', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setAgents(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const createAgent = async (payload) => {
        // if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postCreateAgent(payload);
            // console.log('create agent', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setAgents(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            const allErrors = e?.response?.data?.errors;
            if (allErrors) {
                // Iterate through each error in the object
                const errors = Object.values(allErrors).filter(Boolean); // Get only truthy errors
                for (const error of errors) {
                    // @ts-ignore
                    toast.error(error);
                    // Add a delay before showing the next toast (e.g., 1.5 seconds)
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }

            } else {
                // Fallback: Show the single error message if `allErrors` is not present
                toast.error(e.response?.data?.message || "An error occurred",);
            }

            // toast.error(e.response?.data?.message);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    return {
        loading,
        getAgents,
        agents,
        updateAgents,
        createAgent,
        activateAgents,
        markCommissionPaid
    }
}
