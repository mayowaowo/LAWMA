import {useRef, useState} from "react";
import {
    getAllUser, postAddAdminUser, putEditUserRoles,
} from "@/services/api/services/userService.ts";
import {toast} from "sonner";

export const useUsers = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const didFetch = useRef<boolean>(false);
    const [allUser, setAllUser] = useState([]);
    const getUsers = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getAllUser();
            // console.log('all users history', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setAllUser(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };
    const addUsers = async (payload) => {
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postAddAdminUser(payload);
            // console.log('admin user history', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setAllUser(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            const allErrors = e?.response?.data?.errors;
            if (allErrors) {
                // Iterate through each error in the object
                const errors = Object.values(allErrors).filter(Boolean); // Get only truthy errors
                for (const error of errors) {
                    // @ts-ignore
                    toast.error(error);
                    // Add a delay before showing the next toast (e.g., 1.5 seconds)
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }

            } else {
                // Fallback: Show the single error message if `allErrors` is not present
                toast.error(e.response?.data?.message || "An error occurred",);
            }
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const editUserRoles = async (userId,payload) => {
        let userResponse = null;
        setLoading(true);
        try {
            const response = await putEditUserRoles(userId, payload);
            // console.log('edit user roles', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setAllUser(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            const allErrors = e?.response?.data?.errors;
            if (allErrors) {
                // Iterate through each error in the object
                const errors = Object.values(allErrors).filter(Boolean); // Get only truthy errors
                for (const error of errors) {
                    // @ts-ignore
                    toast.error(error);
                    // Add a delay before showing the next toast (e.g., 1.5 seconds)
                    await new Promise((resolve) => setTimeout(resolve, 1000));
                }

            } else {
                // Fallback: Show the single error message if `allErrors` is not present
                toast.error(e.response?.data?.message || "An error occurred",);
            }
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    return {
        loading,
        getUsers,
        addUsers,
        allUser,
        editUserRoles
    }
}
