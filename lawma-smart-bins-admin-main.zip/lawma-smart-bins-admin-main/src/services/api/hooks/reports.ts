import {useRef, useState} from "react";
import {
    getAllAgents,
    getAllBin, getAllReports,
    getAllRoles, getExportReport,
    getOrders,
    postAddBin,
    postEditBin
} from "@/services/api/services/userService.ts";
import {toast} from "sonner";
import {ObjectType} from "@/services/constant/actionTypes.ts";

export const useReport = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const didFetch = useRef<boolean>(false);
    const [report, setReport] = useState<ObjectType>({});
    const [reportOrders, setReportOrders] = useState([]);
    const [reportAgent, setReportAgent] = useState([]);


    const getReports = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getAllReports();
            // console.log('report history', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setReport(userResponse[0])
                setReportOrders(userResponse[0].order);
                setReportAgent(userResponse[0].agent_comparison);
                return {success: true, results: userResponse[0]};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const exportReports = async (params: ObjectType) => {
        if (didFetch.current) return;
        let userResponse = null;
        // setLoading(true);
        try {
            const response = await getExportReport(params);
            // console.log('report history', response);
            userResponse = response?.data;
            if (userResponse) {
                setLoading(false);
                // setReport(userResponse[0])

                // Create a Blob from the response data
                const csvBlob = new Blob([userResponse], {type: "text/csv"}); // Ensure MIME type matches your file type
                const url = window.URL.createObjectURL(csvBlob);

                // Create a temporary <a> element to trigger the download
                const link = document.createElement("a");
                link.href = url;
                link.download = "report.csv"; // Set the desired file name
                link.click(); // Programmatically trigger a click
                window.URL.revokeObjectURL(url);
                toast.success(`Report has been exported Successfully!`);
                // return {success: true, results: userResponse[0]};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    return {
        reportAgent,
        loading,
        getReports,
        report,
        exportReports,
        reportOrders
    }
}
