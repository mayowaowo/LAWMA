import {getDashboard} from "@/services/api/services/userService.ts";

export const getDashboardData = async () => {
  let userResponse = null;
  try {
    const response = await getDashboard();
    // console.log('dashboard', response);
    userResponse = response;
    if (userResponse) {
      return { success: true, result: response.data.data };
    }
  } catch (e) {
    // console.log(e.response);
    return { success: false, error: e.response?.data?.message };
  }

  return userResponse;
};

import {useRef, useState} from "react";
import {useDispatch} from "react-redux";

export const useDashboard = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const didFetch = useRef<boolean>(false);
  const [dashboardData, setDashboardData] = useState(null);

  const dispatch = useDispatch();
  const getDashboardData = async () => {
    let userResponse = null;
    setLoading(true);
    try {
      const response = await getDashboard();
      // console.log('dashboard', response);
      userResponse = response?.data?.data;
      if (userResponse) {
        setLoading(false);
        setDashboardData(userResponse[0])
        return {success: true, results: userResponse};
      }
    } catch (e) {
      // console.log(e.response?.data?.message);
      setLoading(false);
      return {success: false, error: e.response?.data?.message};
    }

    return userResponse;
  };

  return {
    loading,
    getDashboardData,
    dashboardData,
  }
}

