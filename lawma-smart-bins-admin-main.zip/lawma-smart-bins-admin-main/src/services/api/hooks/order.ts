import {useRef, useState} from "react";
import {useDispatch} from "react-redux";
import {getOrderHistory, getOrderInfo, getOrders, postOrderStatus, postRepayment} from "@/services/api/services/userService.ts";

export const useOrder  = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const didFetch = useRef<boolean>(false);
    const [orderHistory, setOrderHistory] = useState([]);
    const [paymentSchedule, setPaymentSchedule] = useState([]);

    const dispatch = useDispatch();
    const getOrderHistory = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getOrders();
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setOrderHistory(userResponse[0].data)
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };


    const repaymentHistory = async (payload) => {
        let userResponse = null;
        // setLoading(true);
        try {
            const response = await postRepayment(payload);
            // console.log('repayment hitory', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setOrderHistory(userResponse[0].data)
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const updateOrderStatus = async (id, payload) => {
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postOrderStatus(id, payload);
            // console.log('update Order hitory', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                // setOrderHistory(userResponse[0].data)
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    const getOrderPaymentInfo = async (orderReference: string) => {
        let orderResponse = null;
        setLoading(true);

        try {
            const response = await getOrderInfo(orderReference);

            orderResponse = response?.data?.data;
            if (orderResponse) {
                setLoading(false);
                setPaymentSchedule(orderResponse[0].payment_schedule);
                return {success: true, results: orderResponse};
            }
        } catch (e) {
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return orderResponse;
    };



    return {getOrderHistory, orderHistory, loading, repaymentHistory, updateOrderStatus, getOrderPaymentInfo, paymentSchedule }
}
