import {useRef, useState} from "react";
import {useDispatch} from "react-redux";
import {
    getAllBin,
    getAllCommission,
    getAllRoles,
    getOrders,
    postAddBin,
    postEditBin, postEditCommission
} from "@/services/api/services/userService.ts";

export const useSettings = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const [editLoading, setEditLoading] = useState<boolean>(false);

    const didFetch = useRef<boolean>(false);
    const [orderHistory, setOrderHistory] = useState([]);
    const [commissionHistory, setCommissionHistory] = useState([]);

    const [role, setRoles] = useState([]);

    const dispatch = useDispatch();
    const getAllBinsType = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getAllBin();
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setOrderHistory(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };
    const getAllRoleType = async () => {
        // if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getAllRoles();
            // console.log('roles', response);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setRoles(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };
    const addNewBin = async (payload) => {
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postAddBin(payload);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setOrderHistory(userResponse[0])
                return {success: true, results: userResponse[0]};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };
    const editBin = async (id, payload) => {
        let userResponse = null;
        setLoading(true);
        try {
            const response = await postEditBin(id, payload);
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                setOrderHistory(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };
    const getAllCommissions = async () => {
        if (didFetch.current) return;
        let userResponse = null;
        setLoading(true);
        try {
            const response = await getAllCommission();
            userResponse = response?.data?.data;
            if (userResponse) {
                setLoading(false);
                const nestedData = Object.values(userResponse[0]);
                // console.log('nestedData', nestedData);
                setCommissionHistory(nestedData)

                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };
    const editCommission = async (id, payload) => {
        let userResponse = null;
        setEditLoading(true);
        try {
            const response = await postEditCommission(id, payload);
            userResponse = response?.data?.data;
            if (userResponse) {
                setEditLoading(false);
                setOrderHistory(userResponse[0])
                return {success: true, results: userResponse};
            }
        } catch (e) {
            // console.log(e.response?.data?.message);
            setEditLoading(false);
            return {success: false, error: e.response?.data?.message};
        }

        return userResponse;
    };

    return {
        loading,
        getAllBinsType,
        getAllRoleType,
        addNewBin,
        editBin,
        orderHistory,
        role,
        commissionHistory,
        getAllCommissions,
        editCommission,
        editLoading,
    }
}
