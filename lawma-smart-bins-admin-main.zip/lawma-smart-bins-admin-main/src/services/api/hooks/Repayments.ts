import { useRef, useState } from "react";
import { getRepayments } from "@/services/api/services/userService";
import { toast } from "sonner";

export const useRepayments = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const [repayments, setRepayments] = useState<any[]>([]);
    const didFetch = useRef<boolean>(false);

    const fetchRepayments = async () => {
        if (didFetch.current) return;

        setLoading(true);
        try {
            const response = await getRepayments();
            const data = response?.data?.data;

            if (Array.isArray(data) && data.length > 0) {
                const flattened = data.flat();
                setRepayments(flattened);
                // console.log("Repayments data:", flattened);
                didFetch.current = true;
                return { success: true, results: flattened };
            } else {
                toast.error("No repayments found.");
                return { success: false, error: "Empty data" };
            }
        } catch (error: any) {
            const errorMsg = error?.response?.data?.message || "Failed to fetch repayments";
            toast.error(errorMsg);
            return { success: false, error: errorMsg };
        } finally {
            setLoading(false);
        }
    };

    const refreshRepayments = async () => {
        didFetch.current = false;
        return await fetchRepayments();
    };

    return {
        loading,
        repayments,
        fetchRepayments,
        refreshRepayments,
    };
};
