import {Matcher} from "vite";

export interface Auth {
    token: string | null;
    isAuthenticated: boolean;
    loading: boolean,
    error: string | null,
    success: boolean
    next: boolean,
    email: string,
}

export interface User {
    [key: string]: any;
}

export interface ObjectTypes {
    [key: string]: any;
}

export interface userData {
    user: User;
    pageLoading: boolean;
}

export interface Login {
    email: string;
    password: string;
}

export interface Otp {
    email: string;
    otp: string;
}

export type UserType = 'USER' | 'AGENT';

export interface Register {
    fullname: string;
    email: string;
    phone: string;
    address: string;
    postal: string;
    city: string;
    type: UserType;
    referral?: string;
    password: string;
    password_confirmation: string;
}


export interface ForgotPassword {
    email: string;
}

export interface RequestForgotPassword {
    ForgotPassword: ForgotPassword;
    navigate: () => void;
}

export interface ObjectType {
    [key: string]: never;
}

export interface Icon {
    size: number
    color: string
}

export interface UserData {
    first_name: string;
    last_name: string;
    maiden_name: string;
    gender: string;
    in_diaspora: number;
    dob: string;
    country_code: number;
    phone: string;
    email: string;
}

export interface OrderPayload {
    color: string;
    quantity: string;
    category: string;
    dispatch_address: string;
    dispatch_city: string;
    dispatch_postal: string;
    receiver_name: string;
    receiver_phone: string;
    save_dispatch_details: boolean;
    payment_type: "INSTALLMENT" | "ONEOFF";
    postal: string;
    amount: number;
    payment_period?: string;
}


export interface DateRange {
    from?: number | undefined;
    to?: number | undefined;
}


export interface ReportFilter {
    customerName?: string;
    source?: string;
    status?: string;
    binType?: string;
    dateRange?: any
}

