import { createReducer, PayloadAction } from '@reduxjs/toolkit';

import {Auth} from "@/services/constant/actionTypes.ts";
import {
  handleFailure,
  handleForgotPassword,
  handleLoginFailure,
  handleLoginRequest,
  handleLoginSuccess,
  handleLogout,
  handleRegisterRequest, handleRegisterSuccess, handleSuccess, resetOtpState
} from "@/services/constant/actions.ts";

const initialState: Auth = {
  token: null,
  isAuthenticated: false,
  loading: false,
  error: null,
  success: false,
  next: false,
  email: '',
};

const authReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(handleLoginRequest, (state: Auth) => {
      state.loading = true;
    })
    .addCase(handleLoginSuccess, (state: Auth, action: PayloadAction<{ token: string, email: string }>) => {
      // console.log('handleLoginSuccess', action.payload );
      state.loading = false;
      state.isAuthenticated = true;
      state.token = action.payload.token;
      state.error = null;
      state.email = action.payload.email;
    })
    .addCase(
      handleLoginFailure,
      (state: Auth, action: PayloadAction<string>) => {
        state.loading = false;
        state.error = action.payload;
      },
    )
    .addCase(handleLogout, (state: Auth) => {
      state.isAuthenticated = false;
      state.token = null;
      state.error = null;
      state.loading = false;
    })
    .addCase(handleRegisterRequest, (state: Auth) => {
      state.loading = true;
    })
    .addCase(handleForgotPassword, (state: Auth) => {
      state.loading = true;
    })
    .addCase(handleRegisterSuccess, (state: Auth, action: PayloadAction<{ token: string }>) => {
      // console.log('reducer', action.payload);
      state.loading = false;
      // state.isAuthenticated = true;
      // state.token = action.payload.token;
      state.error = null;
      state.next = true;
    })
    .addCase(handleSuccess, (state: Auth) => {
      state.loading = false;
      state.success = true;
      state.error = null;
    })
    .addCase(resetOtpState, (state: Auth) => {
      state.next = false;
    })
    .addCase(handleFailure, (state: Auth, action: PayloadAction<string>) => {
      // console.log('reducer failure', action.payload);
      state.loading = false;
      // console.log('reducer', action.payload);
      state.error = action.payload;
    })
});

export default authReducer;
