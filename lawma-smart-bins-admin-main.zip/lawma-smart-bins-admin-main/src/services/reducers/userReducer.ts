import { createReducer, PayloadAction } from '@reduxjs/toolkit';

import {User, userData} from "@/services/constant/actionTypes.ts";
import {handlePageLoading, handleSaveUserData} from "@/services/constant/actions.ts";


const initialState: userData = {
  user: {},
  pageLoading: false,
};

const userReducer = createReducer(initialState, (builder: any) => {
  builder
    .addCase(handleSaveUserData, (state: userData, action: PayloadAction<User>) => {
      // console.log('user', action.payload);
      state.user = action.payload;
    })
    .addCase(handlePageLoading, (state: userData, action: PayloadAction<boolean>) => {
      state.pageLoading = action.payload;
    })

});

export default userReducer;
