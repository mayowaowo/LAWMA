
import { Stats } from '../types';

export const stats: Stats = {
  totalOrders: 152,
  pendingOrders: 28,
  deliveredOrders: 98,
  totalRevenue: 78500,
  totalAgents: 12,
  totalCommissions: 9450,
};
