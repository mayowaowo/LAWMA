
import { Bin } from '../types';

export const bins: Bin[] = [
  {
    id: '1',
    name: 'General Waste Bin',
    sku: 'GWB-001',
    description: 'Standard general waste bin for household use',
    price: 450,
    stock: 50,
    imageUrl: '/placeholder.svg',
    image: null
  },
  {
    id: '2',
    name: 'Recyclable Waste Bin',
    sku: 'RWB-001',
    description: 'Specialized bin for recyclable materials',
    price: 550,
    stock: 30,
    imageUrl: '/placeholder.svg',
    image: null

  }
];
