import { Order } from '../types';

export const orders: Order[] = [
  {
    id: 'order-1',
    customerName: 'John Doe',
    customerEmail: 'john@example.com',
    customerPhone: '+1234567890',
    orderDate: '2025-04-20',
    binType: 'both',
    paymentOption: 'full',
    totalAmount: 950,
    status: 'paid',
    agentId: 'agent-1',
    referralCode: 'ALEX500',
    deliveryAddress: '123 Main St, City',
    paymentDate: '2025-04-20',
    deliveryDate: '2025-04-25',
  },
  {
    id: 'order-2',
    customerName: 'Jane Smith',
    customerEmail: 'jane@example.com',
    customerPhone: '+1234567891',
    orderDate: '2025-04-21',
    binType: 'general',
    paymentOption: 'installment',
    totalAmount: 490,
    status: 'pending',
    agentId: 'agent-2',
    referralCode: 'EMMA500',
    deliveryAddress: '456 Second Ave, Town',
  },
  {
    id: 'order-3',
    customerName: 'Robert Johnson',
    customerEmail: 'robert@example.com',
    customerPhone: '+1234567892',
    orderDate: '2025-04-22',
    binType: 'recyclable',
    paymentOption: 'full',
    totalAmount: 475,
    status: 'processing',
    deliveryAddress: '789 Third Blvd, Village',
    paymentDate: '2025-04-22',
  },
  {
    id: 'order-4',
    customerName: 'Sarah Williams',
    customerEmail: 'sarah@example.com',
    customerPhone: '+1234567893',
    orderDate: '2025-04-18',
    binType: 'both',
    paymentOption: 'installment',
    totalAmount: 980,
    status: 'delivered',
    agentId: 'agent-1',
    referralCode: 'ALEX500',
    deliveryAddress: '321 Fourth St, Suburb',
    paymentDate: '2025-04-18',
    deliveryDate: '2025-04-23',
  },
  {
    id: 'order-5',
    customerName: 'Michael Brown',
    customerEmail: 'michael@example.com',
    customerPhone: '+1234567894',
    orderDate: '2025-04-23',
    binType: 'general',
    paymentOption: 'full',
    totalAmount: 475,
    status: 'pending',
    agentId: 'agent-3',
    referralCode: 'DAVID500',
    deliveryAddress: '654 Fifth Ave, District',
  },
];

export const getOrderStatusCounts = () => {
  const statusCounts = {
    pending: 0,
    paid: 0,
    processing: 0,
    delivered: 0,
    cancelled: 0
  };
  
  orders.forEach(order => {
    statusCounts[order.status]++;
  });
  
  return statusCounts;
};

export const getBinTypeCounts = () => {
  const typeCounts = {
    general: 0,
    recyclable: 0,
    both: 0
  };
  
  orders.forEach(order => {
    typeCounts[order.binType]++;
  });
  
  return typeCounts;
};
