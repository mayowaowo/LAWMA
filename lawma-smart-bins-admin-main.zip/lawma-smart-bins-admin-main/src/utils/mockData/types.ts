import {ObjectType} from "@/services/constant/actionTypes.ts";

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'super_admin' | 'order_manager' | 'referral_manager';
  avatar?: string | null;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  orderDate: string;
  binType: 'general' | 'recyclable' | 'both';
  paymentOption: 'full' | 'installment';
  totalAmount: number;
  status: 'pending' | 'paid' | 'processing' | 'delivered' | 'cancelled';
  agentId?: string;
  referralCode?: string;
  deliveryAddress: string;
  paymentDate?: string;
  deliveryDate?: string;
}

export interface Agent {
  id: string;
  name: string;
  email: string;
  created_at: string;
  phone: string;
  joinDate: string;
  referralCode: string;
  commissionRate: number;
  totalReferrals: number;
  activeReferrals: number;
  totalCommission: number;
  pendingCommission: number;
  address?: string;
  commision_rate?: number;
  total_referrals?: string;
  total_commissions?: number;
  pending_commissions?: number;
  status: number;
  referral_code?: string;
  commission_history?: ObjectType[];
  paid_commissions?: number;
}

export interface Stats {
  totalOrders: number;
  pendingOrders: number;
  deliveredOrders: number;
  totalRevenue: number;
  totalAgents: number;
  totalCommissions: number;
}

export interface Bin {
  id: string;
  name: string;
  sku: string;
  description: string;
  amount: number;
  stock: number;
  imageUrl: string;
  image: File | null | string;
}

export interface Commission {
  id: string;
  agentId: string;
  orderId: string;
  referralCode: string;
  amount: number;
  date: string;
  status: 'paid' | 'pending';
  paidDate?: string;
}

