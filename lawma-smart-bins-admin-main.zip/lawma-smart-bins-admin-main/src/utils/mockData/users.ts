
import { User } from '../types';

export const currentUser: User = {
  id: 'user-1',
  name: 'Admin User',
  email: 'admin@example.com',
  role: 'super_admin',
  avatar: 'https://api.dicebear.com/6.x/initials/svg?seed=AU'
};

export const mockUsers: User[] = [
  {
    id: 'user-1',
    name: 'Alex Johnson',
    email: 'alex@example.com',
    role: 'super_admin',
    avatar: null
  },
  {
    id: 'user-2',
    name: 'Sarah Williams',
    email: 'sarah@example.com',
    role: 'order_manager',
    avatar: null
  },
  {
    id: 'user-3',
    name: 'Michael Chen',
    email: 'michael@example.com',
    role: 'referral_manager',
    avatar: null
  }
];
