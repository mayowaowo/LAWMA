
export interface User {
  id: string;
  name: string;
  email: string;
  role: 'super_admin' | 'order_manager' | 'referral_manager';
  avatar?: string | null;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  orderDate: string;
  binType: 'general' | 'recyclable' | 'both';
  paymentOption: 'full' | 'installment';
  totalAmount: number;
  status: 'pending' | 'paid' | 'processing' | 'delivered' | 'cancelled';
  agentId?: string;
  referralCode?: string;
  deliveryAddress: string;
  paymentDate?: string;
  deliveryDate?: string;
}

export interface Agent {
  id: string;
  name: string;
  email: string;
  phone: string;
  joinDate: string;
  referralCode: string;
  commissionRate: number;
  totalReferrals: number;
  activeReferrals: number;
  totalCommission: number;
  pendingCommission: number;
  status: 'active' | 'inactive';
}

export interface Stats {
  totalOrders: number;
  pendingOrders: number;
  deliveredOrders: number;
  totalRevenue: number;
  totalAgents: number;
  totalCommissions: number;
}

export interface Bin {
  id: string;
  name: string;
  sku: string;
  description: string;
  price: number;
  stock: number;
  imageUrl: string;
  image: File | null;
}
