<?php

use App\Http\Middleware\AdminMiddleware;
use App\Http\Middleware\PapertrailMiddleware;
use App\Utilities\Helpers;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Route;
use Illuminate\Foundation\Application;
use App\Http\Middleware\ApiLogMiddleware;
use App\Http\Middleware\JSONOnlyMiddleware;
use App\Http\Middleware\SanctumTokenMiddleware;
use Illuminate\Auth\Middleware\Authenticate;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
        then: function() {
            Route:: middleware('api')
            ->prefix('api/merchant')
            ->group(base_path('routes/merchant.php'));

            Route:: middleware('api')
            ->prefix('api/admin')
            ->group(base_path('routes/admin.php'));

            Route:: middleware('api')
            ->prefix('api/wema')
            ->group(base_path('routes/wema.php'));

            Route:: middleware('api')
            ->prefix('api/cddw')
            ->group(base_path('routes/cddw.php'));
        }
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->api(
            append: [
                JSONOnlyMiddleware::class,
                \Illuminate\Http\Middleware\HandleCors::class,
            ]
        );
        $middleware->alias([
            'auth' => Authenticate::class,
            'apiLog' => ApiLogMiddleware::class,
            'papertrail' => PapertrailMiddleware::class,
            'admin' => AdminMiddleware::class,
            'auth:sanctum' => SanctumTokenMiddleware::class,
            'cors' => \Illuminate\Http\Middleware\HandleCors::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->render(function (NotFoundHttpException $e) {
            return (new Helpers())->errorResponse(
                message: "Resource not found: ".$e->getMessage()
            );
        });
    })->create();
