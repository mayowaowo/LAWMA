<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;


class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       
        // Create permissions

        Permission::create(['name' => 'manage reports']);
        Permission::create(['name' => 'manage agents']);


        $role = Role::where('name', 'Super Admin')->first();
     

        $role->givePermissionTo(['manage reports', 'manage agents']);
        //$role = Role::firstOrCreate(['name' => 'Super Admin']);
        // Permission::create(['name' => 'manage users']);
        // Permission::create(['name' => 'manage roles']);
        // Permission::create(['name' => 'manage settings']);
        // Permission::create(['name' => 'manage referrals']);
        // Permission::create(['name' => 'manage orders']);
       
        // // Create a role and assign existing permissions
        // $role1 = Role::create(['name' => 'Super Admin']);
        // $role2 = Role::create(['name' => 'Order Manager']);
        // $role3 = Role::create(['name' => 'Referral Manager']);

        // $role1->givePermissionTo('manage users');
        // $role1->givePermissionTo('manage roles');
        // $role1->givePermissionTo('manage settings');
        // $role1->givePermissionTo('manage referrals');
        // $role1->givePermissionTo('manage orders');

        // $role2->givePermissionTo('manage orders');

        // $role3->givePermissionTo('manage referrals');


    }
}
