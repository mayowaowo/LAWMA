<?php

namespace Database\Seeders;

use App\Enums\Category;
use App\Models\Bin;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class BinSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $bin = Bin::where("name", Category::GENERAL)->first();
        if (!$bin){
            $bin = new Bin();
            $bin->name = Category::GENERAL;
            $bin->image = "";
            $bin->sku = Category::GENERAL;
            $bin->amount = 100000.00;
            $bin->stock = 0;
            $bin->description = "";
            $bin->save();
        }

        $recycle = Bin::where("name", Category::RECYCLABLES)->first();
        if (!$recycle){
            $recycle = new Bin();
            $recycle->name = Category::RECYCLABLES;
            $recycle->image = "";
            $recycle->sku = Category::RECYCLABLES;
            $recycle->amount = 100000.00;
            $recycle->stock = 0;
            $recycle->description = "";
            $recycle->save();
        }
    }
}
