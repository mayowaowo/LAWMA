<?php

namespace Database\Seeders;

use App\Models\User;
use Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;


class WemaUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $user = new User();
        $user->name = "Admin";
        $user->email = "lsb@admin.com";
        $user->phone = "111111111";
        $user->password = Hash::make('password');
        $user->type = \App\Enums\Profile::ADMIN;

        $user->commission_rate = 0;

        
        $user->save();
    }
}
