<?php

namespace Database\Seeders;

use App\Enums\Profile;
use App\Models\CddwAdmin;
use App\Models\User;
use Hash;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //$user = new User();
        $user = new CddwAdmin();
        $user->name = "Admin";
        $user->email = "cddw@admin.com";
        // $user->phone = "0000000000000";
        $user->password = Hash::make('password');
        // $user->type = Profile::ADMIN;
        // $user->commission_rate = 0;
        
        $user->save();
    }
}
