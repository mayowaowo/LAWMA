<?php

namespace Database\Seeders;

use App\Models\CddwPermission;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permissions = [
            // =========================
            // ADMINISTRATION
            // =========================
            ['name' => 'manage_users', 'display_name' => 'Manage Users', 'description' => 'Can create, edit, and delete users'],
            ['name' => 'manage_roles', 'display_name' => 'Manage Roles', 'description' => 'Can create, edit, and delete roles'],
            ['name' => 'manage_settings', 'display_name' => 'Manage Settings', 'description' => 'Can update application settings'],
            ['name' => 'system_configuration', 'display_name' => 'System Configuration', 'description' => 'Can configure system-wide parameters'],
            ['name' => 'delete_data', 'display_name' => 'Delete Data', 'description' => 'Can permanently delete data from the system'],

            // =========================
            // REPORTING
            // =========================
            ['name' => 'view_analytics', 'display_name' => 'View Analytics', 'description' => 'Can view analytics and insights'],
            ['name' => 'generate_reports', 'display_name' => 'Generate Reports', 'description' => 'Can generate various system reports'],
            ['name' => 'export_data', 'display_name' => 'Export Data', 'description' => 'Can export data to external formats like Excel or PDF'],

            // =========================
            // FINANCIAL
            // =========================
            ['name' => 'process_payments', 'display_name' => 'Process Payments', 'description' => 'Can initiate or process payment transactions'],
            ['name' => 'manage_payments', 'display_name' => 'Manage Payments', 'description' => 'Can view, approve, or reject payments'],

            // =========================
            // OPERATIONS
            // =========================
            ['name' => 'verify_documents', 'display_name' => 'Verify Documents', 'description' => 'Can review and verify uploaded documents'],
            ['name' => 'view_registrations', 'display_name' => 'View Registrations', 'description' => 'Can access and view all registrations'],
            ['name' => 'update_status', 'display_name' => 'Update Status', 'description' => 'Can update registration or transaction statuses'],
        ];

        foreach ($permissions as $perm) {
            CddwPermission::updateOrCreate(
                ['name' => $perm['name']],
                [
                    'display_name' => $perm['display_name'],
                    'description' => $perm['description'],
                ]
            );
        }

    }
}
