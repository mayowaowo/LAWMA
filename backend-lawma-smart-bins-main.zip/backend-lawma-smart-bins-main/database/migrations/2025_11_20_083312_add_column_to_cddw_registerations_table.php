<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cddw_registerations', function (Blueprint $table) {
            $table->string('region')->nullable()->change();
            $table->string('company_address')->nullable()->change();
            $table->string('site_address')->nullable()->change();
            $table->string('company_phone')->nullable()->change();
            $table->string('site_phone')->nullable()->change();
            $table->string('site_description')->nullable()->change();
            $table->string('payment_type')->nullable()->change();
            $table->timestamp('effective_date')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cddw_registerations', function (Blueprint $table) {
            $table->string('region')->nullable(false)->change();
            $table->string('company_address')->nullable(false)->change();
            $table->string('site_address')->nullable(false)->change();
            $table->string('company_phone')->nullable(false)->change();
            $table->string('site_phone')->nullable(false)->change();
            $table->string('site_description')->nullable(false)->change();
            $table->string('payment_type')->nullable(false)->change();
            $table->timestamp('effective_date')->nullable(false)->change();
        });
    }
};
