<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cddw_users', function (Blueprint $table) {
            $table->string('registration_levy_paid')->nullable();
            $table->string('registration_levy_amount')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cddw_users', function (Blueprint $table) {
            //
        });
    }
};
