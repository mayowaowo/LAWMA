<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cddw_activity_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->string('resource')->nullable();
            $table->json('payload')->nullable();
            $table->text('response')->nullable();
            $table->string('ip_address')->nullable();
            $table->text('action')->nullable();
            $table->text('description')->nullable();
            $table->foreign('user_id')->references('id')->on('cddw_admins')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cddw_activity_logs');
    }
};
