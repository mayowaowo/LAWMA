<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cddw_registerations', function (Blueprint $table) {
            $table->decimal('land_size', 12, 2)->nullable(); 
            $table->unsignedInteger('number_of_floors')->nullable();
            $table->string('location_density')->nullable();
            $table->string('bin_type')->nullable();
            $table->unsignedInteger('evacuation_trips')->nullable();
            $table->bigInteger('user_id')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cddw_registerations', function (Blueprint $table) {
            //
        });
    }
};
