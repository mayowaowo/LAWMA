<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->index();
            $table->string('order_reference')->nullable()->index();
            $table->json('bin_purchase')->nullable();
            $table->string('color')->nullable();
            $table->string('payment_type')->nullable()->index();
            $table->decimal('amount', 20,2)->index();
            $table->decimal('expected_amount', 20,2)->index();
            $table->decimal('total_amount', 20,2)->index();
            $table->decimal('remitted_amount', 20,2)->nullable()->index();
            $table->string('payment_period')->nullable();
            $table->string('payment_status')->nullable();
            $table->string('status')->default('In Progress');
            $table->json('dispatch_details')->nullable();
            $table->json('receiver_details')->nullable();
            $table->integer('store_dispatch_details')->default(0);
            $table->string('account_number')->nullable()->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
