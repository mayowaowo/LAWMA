<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {

        Schema::create('cddw_roles', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('display_name')->nullable();
            $table->string('description')->nullable();
            $table->boolean('removable')->default(true);
            $table->timestamps();
        });

        // Pivot tables
        Schema::create('cddw_role_user', function (Blueprint $table) {
            $table->foreignId('role_id')->constrained('cddw_roles')->onDelete('cascade');
            $table->foreignId('user_id')->constrained('cddw_admins')->onDelete('cascade');
            $table->primary(['role_id', 'user_id']);
        });

        

    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cddw_roles');
    }
};
