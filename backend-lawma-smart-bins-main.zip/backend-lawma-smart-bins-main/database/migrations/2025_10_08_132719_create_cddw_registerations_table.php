<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cddw_registerations', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('customer_reference');
            $table->string('transaction_reference');
            $table->string('email');
            $table->string('phone');
            $table->string('region');
            $table->string('company_address');
            $table->string('site_address');
            $table->string('company_phone');
            $table->string('site_phone');
            $table->string('site_description');
            $table->string('payment_type');
            $table->string('payment_status');
            $table->string('status');
            $table->decimal('amount', 20,2);
            $table->timestamp('effective_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cddw_registerations');
    }
};
