<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cddw_users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('rc_number')->nullable();
            $table->string('address')->nullable();
            $table->string('contact_person_name');
            $table->string('contact_person_title')->nullable();
            $table->string('phone', 30)->nullable();
            $table->string('email')->nullable();
            $table->string('password'); 
            $table->string('project_title');
            $table->string('project_type')->nullable();
            $table->string('project_address')->nullable();
            $table->date('planned_start_date')->nullable();
            $table->date('planned_end_date')->nullable();
            $table->text('hazardous_materials')->nullable();
            $table->string('site_plan_path')->nullable();
            $table->boolean('undertaking')->default(false);
            $table->string('signature')->nullable(); 
            $table->decimal('land_size', 12, 2)->nullable(); 
            $table->unsignedInteger('number_of_floors')->nullable();
            $table->string('location_density')->nullable(); 
            $table->string('bin_type')->nullable();
            $table->unsignedInteger('evacuation_trips')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cddw_users');
    }
};
