<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cddw_transactions', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->index();
            $table->string('order_reference')->nullable()->index();
            $table->string('account_number')->nullable()->index();
            $table->string('reference')->nullable()->index();
            $table->string('provider_reference')->nullable()->index();
            $table->decimal('amount', 20,2)->index();
            $table->string('type')->nullable();
            $table->string('transaction_type')->nullable();
            $table->string('narration')->nullable();
            $table->string('channel')->nullable();
            $table->string('status')->nullable()->index();
            $table->string('provider_status')->nullable()->index();
            $table->json('virtual_account_meta')->nullable();
            $table->json('meta')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cddw_transactions');
    }
};
