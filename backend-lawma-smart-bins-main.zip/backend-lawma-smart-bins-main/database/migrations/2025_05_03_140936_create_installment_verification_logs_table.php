<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('installment_verification_logs', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->index();
            $table->string('bvn')->nullable()->index();
            $table->string('nin')->nullable()->index();
            $table->string('bvn_provider_response')->nullable();
            $table->string('nin_provider_response')->nullable();
            $table->json('bvn_meta')->nullable();
            $table->json('nin_meta')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('installment_verification_logs');
    }
};
