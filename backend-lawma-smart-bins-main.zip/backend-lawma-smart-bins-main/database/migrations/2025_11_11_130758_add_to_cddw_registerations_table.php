<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('cddw_registerations', function (Blueprint $table) {
            $table->timestamp('collection_date')->nullable();
            $table->string('payment_receipt')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cddw_registerations', function (Blueprint $table) {
            //
        });
    }
};
