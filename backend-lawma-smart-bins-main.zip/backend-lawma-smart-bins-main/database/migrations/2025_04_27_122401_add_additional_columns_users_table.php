<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->string('uuid')->nullable()->index();
            $table->string('type')->nullable()->index();
            $table->string('phone')->unique();
            $table->string('city')->nullable();
            $table->string('postal_code')->nullable();
            $table->string('address')->nullable();
            $table->integer('status')->default(1)->index();
            $table->string('referral_code')->nullable()->index();
            $table->datetime('last_login')->nullable();
            $table->integer('login_count')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['uuid', 'type', 'phone', 'city', 'postal_code', 'address', 'status', 'referral_code', 'last_login', 'login_count']);
        });
    }
};
