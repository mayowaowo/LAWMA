<?php

namespace App\Enums;

class Category
{
    const GENERAL = "GENERAL";
    const RECYCLABLES = "RECYCLABLES";

    static $types = [
        self::GENERAL,
        self::RECYCLABLES
    ];
}
