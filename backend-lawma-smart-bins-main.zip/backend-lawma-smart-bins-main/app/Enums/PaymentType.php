<?php

namespace App\Enums;

class PaymentType
{
    const ONEOFF = "ONEOFF";
    const INSTALLMENT = "INSTALLMENT";

    static $types = [
        self::ONEOFF,
        self::INSTALLMENT
    ];
}
