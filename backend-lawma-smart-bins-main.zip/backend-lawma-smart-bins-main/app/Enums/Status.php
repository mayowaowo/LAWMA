<?php

namespace App\Enums;

class Status
{
    const ACTIVE = "Active";
    const IN_ACTIVE = "Inactive";
    const PENDING = "Pending";
    const PAID = "Paid";
    const IN_PROGRESS = "In Progress";
    const SUCCESSFUL = "Successful";
    const COMPLETED = "COMPLETED";
    const NOT_COMPLETED = "NOT COMPLETED";
    const COLLECTION = "COLLECTION";
    const CREDIT = "Credit";
    const ACTIVE_NUMERIC = 1;
    const IN_ACTIVE_NUMERIC = 0;
    const PENDING_NUMERIC = 0;
    const SUCCESS_IDENTITY_RESPONSE = "Valid Identity";
    const ERROR_IDENTITY_RESPONSE = "Invalid Identity";

    static $actionStatus = [
        self::ACTIVE,
        self::IN_ACTIVE,
        self::PENDING,
        self::ACTIVE_NUMERIC,
        self::IN_ACTIVE_NUMERIC,
        self::PENDING_NUMERIC
    ];
}
