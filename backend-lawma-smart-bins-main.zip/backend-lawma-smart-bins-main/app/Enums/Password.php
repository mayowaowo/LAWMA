<?php

namespace App\Enums;

class Password
{
    const RESET_PASSWORD = 12345;
}