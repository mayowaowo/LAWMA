<?php

namespace App\Enums;

class Profile
{
    const USER = "USER";
    const AGENT = "AGENT";

    const ADMIN = "ADMIN";

    const WEMA_ADMIN = "WEMA-ADMIN";

    static $types = [
        self::USER,
        self::AGENT,
        self::ADMIN

    ];
}
