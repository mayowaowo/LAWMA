<?php

namespace App\Jobs;

use Exception;
use Carbon\Carbon;
use App\Models\User;
use App\Enums\Status;
use App\Models\Order;
use App\Mail\Repayment;
use App\Utilities\Helpers;
use App\Models\Transaction;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Mail;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class ProcessInstallmentOrderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected mixed $itemId;
    protected mixed $transaction_fee;
    protected mixed $expected_amount;
    protected mixed $order_request;

    protected mixed $userData;
    protected mixed $payment;
    protected mixed $helper;
    protected mixed $payment_response;

    protected mixed $transaction_data;
    protected mixed $lawmaSmartBinWebBaseUrl;
    
    /**
     * Create a new job instance.
     */
    public function __construct($itemId)
    {
        $this->itemId = $itemId;
        $this->helper = new Helpers();
        $this->lawmaSmartBinWebBaseUrl = config('payment.lawma_smart_bin_frontend_base_url');
;    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        $this->order_request = Order::find($this->itemId);
        $date = Carbon::parse($this->order_request->created_at);
        $todayDay = Carbon::today()->day;
        if ($this->order_request && $date->day === $todayDay) {
            if($this->order_request->remitted_amount < $this->order_request->total_amount) {
                $order_next_payment = ( $this->order_request->total_amount / 100 ) * 25;
                $repayment_amount = ( $this->order_request->total_amount - $order_next_payment );
                $payable_amount = ( $repayment_amount / (int) $this->order_request->payment_period );
                $this->transaction_fee = ( 1.25 / 100 ) * $payable_amount;
                $this->expected_amount = ( $payable_amount + $this->transaction_fee );
                $this->userData = User::where('id', $this->order_request->user_id)->first();
                $this->initiateNextPayment();
            }
        }
    }

    /**
     * Initiate Next Payment
     * @return void 
     */
    protected function initiateNextPayment():void
    {
        try {
            /** Initiate virtual account for payment */
            $this->inititateVirtualAccount();
            $this->createTransaction();
            $this->updateOrder();
            Log::info($this->payment_response);
            $repayment_data = [
                "amountTopay" => $this->expected_amount, 
                "reference" => $this->payment_response["data"]["customer_reference"], 
                "bankName" => "Globus", 
                "account_name" => $this->payment_response["data"]["account_name"], 
                "account_number" => $this->payment_response["data"]["account_number"]
            ];
            $jsonData = json_encode($repayment_data);
            $encryptedData = base64_encode($jsonData);
            $repaymentLink = "{$this->lawmaSmartBinWebBaseUrl}/repayment/{$encryptedData}";
            Mail::to($this->userData->email)->queue(new Repayment($this->userData->name, $this->expected_amount, $repaymentLink));
        } catch (Exception $exception) {
            Log::error($exception->getMessage());
        }
    }

    /**
     * Initiate virtual account
     * payment
     * 
     * @return void
     * @throws Exception
     */
    protected function inititateVirtualAccount():void
    {
        try {
            $payload = [
                "account_name" => $this->userData['name'],
                "amount" => $this->expected_amount,
                "customer_reference" => $this->helper->generateReference(),
                "type" => "Corporate",
                "channel" => "Globus"
            ];
            $header = [
                'api-key' => config('payment.sarepay_secret_key')
            ];
            $endpoint = config('payment.sarepay_base_url')."/api/virtual-accounts/onetime";
            $response = Http::withHeaders($header)->asJson()->post($endpoint, $payload, [])->json();
            if(!$response || !isset($response["data"]) || $response["data"]["status"] !== Status::ACTIVE) { 
                Log::error("Unable to process payment at the moment, please try again later");
                return;
            }
            $this->payment_response = $response;
        } catch (Exception $exception) {
            Log::error($exception);
        }
    }

    /**
     * Create transaction
     * @return void
     * @throws Exception
     */
    private function createTransaction():void
    {
        try {
            $transaction = new Transaction();
            $transaction->user_id = $this->userData->id;
            $transaction->order_reference = $this->order_request->order_reference;
            $transaction->account_number = $this->payment_response["data"]["account_number"];
            $transaction->reference = $this->payment_response["data"]["customer_reference"];
            $transaction->provider_reference = null;
            $transaction->amount = $this->expected_amount;
            $transaction->transaction_fee = $this->transaction_fee;
            $transaction->type = Status::CREDIT;
            $transaction->transaction_type = Status::COLLECTION;
            $transaction->narration = "LAWMA SMART BIN PURCHASE";
            $transaction->channel = "SAREPAY";
            $transaction->status = Status::PENDING;
            $transaction->provider_status = Status::PENDING;
            $transaction->virtual_account_meta = ($this->payment_response ) ? json_encode($this->payment_response) : null;
            $transaction->save();
            $this->transaction_data = $transaction;
        } catch (Exception $exception) {
            Log::error($exception->getMessage());
        }
    }

    /**
     * Update Order
     * @return void 
     */
    protected function updateOrder():void
    {
        $this->order_request->account_number = $this->payment_response['data']['account_number'];
        $this->order_request->save();
        return;
    }
}
