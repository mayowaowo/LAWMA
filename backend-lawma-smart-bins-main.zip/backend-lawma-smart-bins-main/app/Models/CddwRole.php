<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CddwRole extends Model
{
    protected $fillable = ['name', 'display_name', 'description', 'removable'];

    public function permissions()
    {
        return $this->belongsToMany(CddwPermission::class, 'cddw_permission_role',   
            'role_id',                
            'permission_id'  );
    }

    public function admins()
    {
        return $this->belongsToMany(CddwAdmin::class, 'cddw_role_user', 'role_id', 'user_id');
    }
}
