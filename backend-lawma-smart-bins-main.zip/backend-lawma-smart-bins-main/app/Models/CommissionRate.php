<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CommissionRate extends Model
{
    public function users()
    {
        return $this->belongsTo(User::class);
    }
}
