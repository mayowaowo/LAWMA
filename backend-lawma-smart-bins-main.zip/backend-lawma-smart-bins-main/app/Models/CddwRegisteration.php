<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CddwRegisteration extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'email',
        'phone',
        'region',
        'company_address',
        'site_address',
        'company_phone',
        'site_phone',
        'site_description',
        'payment_type',
        'payment_receipt',
        'amount',
        'effective_date',
        'customer_reference',
        'transaction_reference',
        'payment_status',
        'user_id',
        'status',
        'collection_date',
        'land_size','number_of_floors','location_density','bin_type','evacuation_trips'
    ];


    public function users()
    {
        return $this->belongsTo(CddwUser::class, 'user_id', 'id');
    }
}

