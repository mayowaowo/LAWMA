<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class CddwUser extends Model
{

    use HasApiTokens, HasFactory;

    protected $fillable = [
        'name','rc_number','address',
        'contact_person_name','contact_person_title','phone','email',
        'password',
        'project_title','project_type','project_address',
        'planned_start_date','planned_end_date',
        'hazardous_materials',
        'site_plan_path',
        'undertaking','signature',
       'land_size','number_of_floors','location_density','bin_type','evacuation_trips','payment_receipt'
    ];

    protected $casts = [
        'planned_start_date'   => 'date',
        'planned_end_date'     => 'date',
        'undertaking'          => 'boolean',
        'land_size'            => 'decimal:2',
        'number_of_floors'     => 'integer',
        'evacuation_trips'     => 'integer',
    ];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
        ];
    }
    protected $hidden = ['password'];
}
