<?php

namespace App\Models;

use App\Enums\Status;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Order extends Model
{
    use HasFactory;

    protected $appends = ['total_quantity'];
    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class, 'order_reference', 'order_reference')->orderBy('created_at', 'desc');
    }

    public function firstPaidTransaction()
    {
        return $this->hasOne(Transaction::class, 'order_reference', 'order_reference')
                    ->where('status', Status::PAID)
                    ->oldestOfMany(); 
    }

    public function firstPendingTransaction()
    {
        return $this->hasOne(Transaction::class, 'order_reference', 'order_reference')
                    ->where('status', 'PENDING')
                    ->oldestOfMany();
    }

    public function getRemainingPendingTransactionAttribute()
    {
        return $this->transactions()
            ->where('status', 'PENDING')
            ->sum('amount');
    }
    
    public function latestTransaction(): HasOne
    {
        return $this->hasOne(Transaction::class, 'order_reference', 'order_reference')
                    ->oldestOfMany();
    }


    public function users()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public static function revenue()
    {
        return static::where('status', Status::SUCCESSFUL)->sum('remitted_amount');
    }

    public function commissionHistory(): HasMany
    {
        return $this->hasMany(CommissionHistory::class, 'order_id', 'id')->orderBy('created_at', 'desc');
    }

    public function getTotalQuantityAttribute()
    {

                 
        $quantity = 0;
        $binData = is_array($this->bin_purchase)
        ? $this->bin_purchase
        : json_decode($this->bin_purchase, true);

        
        if (is_string($binData)) {
            $orderArray = json_decode($binData, true);
        } else {
            $orderArray = $binData;
        }
        
       
        foreach ($orderArray as $item) {
            $quantity += $item['quantity'];  
        }


       return $quantity;

        // if (!is_array($binData)) {
        //     return 0;
        // }

        //return collect($binData)->sum('quantity');
    }
}