<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class CddwActivityLogs extends Model
{
    protected $table = "cddw_activity_logs";

    protected $fillable = [
        'user_id',
        'resource',
        'payload',
        'response',
        'ip_address',
        'action',
        'description'
    ];

    public function user()
    {
        return $this->belongsTo(CddwAdmin::class);
    }

    public static function log(Request $request, int $user_id, string $resource, $payload= null, $response=null, string $action, string $description) : self
    {
        return self::create([
            'user_id' => $user_id,
            'resource' => $resource,
            'payload' => $payload,
            'response' => $response,
            'ip_address' => $request->ip(),
            'action' => $action,
            'description' => $description
        ]);
    }
}
