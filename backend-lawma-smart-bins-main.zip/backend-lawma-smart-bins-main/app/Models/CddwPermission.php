<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CddwPermission extends Model
{
    protected $fillable = ['name', 'display_name', 'description'];

    public function roles()
    {
        return $this->belongsToMany(CddwRole::class);
    }
}
