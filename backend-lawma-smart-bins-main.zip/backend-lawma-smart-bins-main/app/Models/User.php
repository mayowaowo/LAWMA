<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Enums\Status;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasApiTokens, HasFactory, Notifiable, HasRoles;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    public function savedDispatchDetails(): HasMany
    {
        return $this->hasMany(Order::class)->where("store_dispatch_details", Status::ACTIVE_NUMERIC)->orderBy('created_at', 'desc');
    }

    public function referrals(): HasMany
    {
        return $this->hasMany(Referral::class, 'referral_id', 'id')->orderBy('created_at', 'desc');
    }

    public function commissionHistory(): HasMany
    {
        return $this->hasMany(CommissionHistory::class, 'user_id', 'id')->orderBy('created_at', 'desc');
    }

    public function agentTotalCommission(): float
    {
        return $this->hasMany(CommissionHistory::class, 'user_id', 'id')->sum('commission');
    }
}
