<?php

namespace App\Services\Merchant\User;

use Exception;
use App\Models\User;
use App\Enums\Status;
use App\Enums\Profile;
use App\Mail\AgentEmailVerification;
use App\Models\Referral;
use App\Utilities\Helpers;
use Illuminate\Support\Str;
use App\Mail\OneTimePasscode;
use Illuminate\Support\Carbon;
use App\Mail\EmailVerification;
use Spatie\Permission\Models\Role;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redis;


class UserService
{
    protected mixed $data;
    protected mixed $user;
    protected mixed $referral;
    protected mixed $helper;

    public function __construct($data = null, $user = null)
    {
        $this->data = $data;
        $this->user = $user;
        $this->helper = new Helpers();
    }

    const EMAIL_VERIFICATION = "Email-Verification";

    /**
     * Create user
     * 
     * @return mixed
     * @throws Exception
     */
    public function initiateUserCreation(): mixed
    {
        try {
            $userExists = User::where('email', $this->data['email'])
            ->orWhere('phone', $this->data['phone'])
            ->exists();
            if ($userExists) {
                throw new \Exception('A user with this email or phone number already exists.');
            }
            $smartBinsUser = $this->createUser();
            if(isset($this->data['referral']) && !empty($this->data['referral'])) {
                $this->referral = User::where('referral_code', $this->data['referral'])->first();
                if($this->referral) $this->smartBinsReferral($smartBinsUser->id);
            }
            $this->emailVerification("EmailVerify", $smartBinsUser);
            return $smartBinsUser;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Email Verification
     * 
     * @param string $type
     * @param User $smartBinsUser
     * @return void 
     */
    public function emailVerification(string $type, User $smartBinsUser):void
    {
        $oneTimePasscode = $this->helper->randomNumbers(); 
        if($type === "EmailVerify") {
            Mail::to($smartBinsUser->email)->queue(new EmailVerification($smartBinsUser->name, $oneTimePasscode));
        } else {
            Mail::to($smartBinsUser->email)->queue(new OneTimePasscode($smartBinsUser->name, $oneTimePasscode));
        }
        Redis::set(self::EMAIL_VERIFICATION, $oneTimePasscode, 'EX', 180); /** Put values in Redis for 3 minutes */
    }

    public function AgentEmailVerification(User $smartBinsUser, string $referralCode, string $password, string $resetLink):void
    {
        Mail::to($smartBinsUser->email)->send(new AgentEmailVerification($smartBinsUser->name, $password, $referralCode, $resetLink, $smartBinsUser->email));
       
    }


       /**
     * Create Admin
     * 
     * @return mixed
     * @throws Exception
     */
    public function initiateAdminCreation(): mixed
    {
        try {
            $role = Role::find($this->data['role_id']);
            if (!$role) {
                throw new Exception("Invalid role");
            }

            $smartBinsUser = $this->createUser();            
            $smartBinsUser->assignRole($role);

            return $smartBinsUser;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Create user
     * @return mixed
     * @throws Exception
     */
    public function createUser(): mixed
    {
        try {
            $user = new User();
            $user->name = $this->data["fullname"];
            $user->email = $this->data["email"];
            $user->phone = $this->data["phone"];
            $user->address = $this->data["address"];
            $user->postal_code = $this->data["postal"];
            $user->city = $this->data["city"];
            $user->password = $this->data["password"];
            $user->referral_code = (new Helpers())->generateReferralCode();
            $user->type = $this->data["type"];
            $user->uuid = (string) Str::uuid();
            $user->save();
            return $user;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Smart Bins Referral
     * @return void
     * @throws Exception
     */
    public function smartBinsReferral($smartBinsUserID): void
    {
        try {
            $referral = new Referral();
            $referral->referral_id = $this->referral->id;
            $referral->user_id = $smartBinsUserID;
            $referral->save();
            return;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }


    /**
     * Login user
     * @return mixed
     * @throws Exception
     */
    public function loginUser(): mixed
    {
        try {
            $user = User::where('email', $this->data["email"])->first();
            if(!$user) {
                throw new Exception("Invalid credentials provided");
            } elseif(!Hash::check($this->data["password"], $user->password)) {
                throw new Exception("Invalid credentials provided");
            } elseif($user->status !== Status::ACTIVE_NUMERIC) {
                throw new Exception("Your account has been blocked, kindly contact support");
            }
            /** Update login user */    
            $user->last_login = Carbon::now();
            $user->login_count = $user->login_count + 1;
            $user->save();

            return $user;
        } catch (Exception $exception) {
            Log::error($exception->getMessage());
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Get user by Id
     * @param mixed $id
     * @return mixed
     * @throws Exception
     */
    public function getUserById(mixed $id): mixed
    {
        $userData = User::where('id', $id)->first();
        if(!$userData) throw new Exception("User not found");
        return $userData;
    }

    /**
     * Get user by UUID
     * 
     * @param mixed $uuid
     * @return mixed
     * @throws Exception
     */
    public function getUserByUuid(mixed $uuid): mixed
    {
        $userData = User::where('uuid', $uuid)->first();
        if(!$userData) throw new Exception("User not found");
        return $userData;
    }

    public function getAllAgents(): mixed
    {
        $user = User::where("type", Profile::AGENT)->get();

        return $user;
    }

    public function getAllAdmin(): mixed
    {
        $users = User::where("type", Profile::ADMIN)->get();

        foreach($users as $user){
            $roles = $user->getRoleNames();
            $user['roles'] = $roles;
        }
       
        return $users;
    }

    public function editRate($id)
    {
        $userData = User::where('id', $id)->first();
        $userData->commission_rate = $this->data['rate'];
        $userData->save();

        return $userData;
    }

    /**
     * Validate One Time Passcode
     * 
     * @return mixed
     * @throws Exception
     */
    public function validateOtp(): mixed
    {
        try {
            $user = $this->getUserByUuid($this->data["uuid"]);
            if($user->email_verified_at && $user->email_verified_at !== null) {
                throw new Exception("Your email address already verified");
            }
            $response = Redis::get(self::EMAIL_VERIFICATION); /** Retrieve values from Redis */
            if($response) {
                if($this->data['otp'] !== $response) {
                    throw new Exception("Invalid OTP provided");
                }
                return true;
            } else {
                throw new Exception("OTP has expired");
            }
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Validate One Time Passcode
     * for forgot password
     * 
     * @return mixed
     * @throws Exception
     */
    public function forgotPasswordValidateOtp(): mixed
    {
        try {
            $user = $this->getUserByUuid($this->data["uuid"]);
            $response = Redis::get(self::EMAIL_VERIFICATION); /** Retrieve values from Redis */
            if($response) {
                if($this->data['otp'] !== $response) {
                    throw new Exception("Invalid OTP provided");
                }
                return true;
            } else {
                throw new Exception("OTP has expired");
            }
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Update user
     * 
     * @return mixed
     * @throws Exception
     */
    public function updateUser(): mixed
    {
        try {
            if ( $this->user ) $userData = $this->user;
            else $userData = User::where("uuid", $this->data["uuid"])->first();
            if(isset($this->data["name"]) && !empty($this->data["name"])) $userData->name = $this->data["name"];
            if(isset($this->data["email"]) && !empty($this->data["email"])) $userData->email = $this->data["email"];
            if(isset($this->data["email_verified_at"]) && !empty($this->data["email_verified_at"])) $userData->email_verified_at = $this->data["email_verified_at"];
            if(isset($this->data["phone"]) && !empty($this->data["phone"])) $userData->phone = $this->data["phone"];
            if(isset($this->data["status"]) && !empty($this->data["status"])) $userData->status = $this->data["status"];
            if(isset($this->data["password"]) && !empty($this->data["password"])) $userData->password = $this->data["password"];
            if(isset($this->data["installment_verification_status"])) {
                $userData->transaction_notification_email = ( $this->data["installment_verification_status"] === true ) ? Status::ACTIVE_NUMERIC : Status::IN_ACTIVE_NUMERIC;
            }
            $userData->save();
            return $userData;
        } catch (Exception $exception) {
            Log::error($exception->getMessage());
            throw new Exception($exception->getMessage());
        }
    }

     /**
     * Fetch user by UUid
     * 
     * @return mixed
     * @throws Exception
     */
    public function fetchUserByUUID(): mixed
    {
        $userData = User::where('uuid', $this->data["uuid"])->first();
        if(!$userData) throw new Exception("User not found");
        return $userData;
    }

    /**
     * Checks for pending 
     * onboarding proccess
     * 
     * @return array<string, mixed>
     */
    public function pendingOnboardingProcess(): array
    {
        /** Email checks */
        if(isset($this->data["email"]) && !empty($this->data["email"])) {
            $userEmail = User::where('email', $this->data["email"])->first();
            if($userEmail) {
                if($userEmail->email === $this->data["email"] && $userEmail->email_verified_at === null) {
                    Log::info("I got in here");
                    $this->emailVerification("EmailVerify", $userEmail);
                    return ["status" => true, "message" => "Incomplete onboarding process.", "data" => $userEmail];
                }
            }
        }
        /** Phone checks */
        if(isset($this->data["phone"]) && !empty($this->data["phone"])) {
            $userPhone = User::where('phone', $this->data["phone"])->first();
            if($userPhone) {
                if($userPhone->phone === $this->data["phone"] && $userPhone->email_verified_at === null) {
                    return ["status" => true, "message" => "Incomplete onboarding process.", "data" => $userPhone];
                }
            }
        }
        return ["status" => false, "message" => "No incomplete onboarding"];
    }

    /**
     * Checks if email address
     * 
     * @return mixed
     * @throws Exception
     */
    public function emailExists(): mixed
    {
        try {
            $userEmail = User::where('email', $this->data["email"])->first();
            if(!$userEmail) throw new Exception("Email address does not exists");
            return $userEmail;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }
}
