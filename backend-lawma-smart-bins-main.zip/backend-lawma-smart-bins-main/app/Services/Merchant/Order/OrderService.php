<?php

namespace App\Services\Merchant\Order;

use App\Models\Bin;
use Exception;
use App\Models\User;
use App\Enums\Status;
use App\Models\Order;
use App\Enums\PaymentType;
use App\Utilities\Helpers;
use App\Models\Transaction;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use App\Models\InstallmentVerification;
use App\Models\InstallmentVerificationLog;
use App\Http\Resources\Merchant\OrderCollection;

class OrderService
{
    protected mixed $data;
    protected mixed $user;
    protected mixed $helper;
    protected mixed $expected_amount;
    protected mixed $order_request;
    protected mixed $payment;
    protected mixed $installment_verification_log;
    protected mixed $transaction_fee;
    protected mixed $purchase_amount;

    protected string $dojahBaseUrl;
    protected string $dojahSecretKey;
    protected string $dojahAppId;
    protected string $dojahTestBvn;
    protected string $dojahTestNin;

    public function __construct($data = null, $user = null)
    {
        $this->data = $data;
        $this->user = $user;
        $this->helper = new Helpers();

        $this->dojahBaseUrl = config('payment.dojah_base_url');
        $this->dojahSecretKey = config('payment.dojah_secret_key');
        $this->dojahAppId = config('payment.dojah_app_id');
        $this->dojahTestBvn = config('payment.dojah_test_bvn');
        $this->dojahTestNin = config('payment.dojah_test_nin');
    }

    const SMART_BIN_AMOUNT_TEST = 100;
    const SMART_BIN_AMOUNT = 100000;
    const BANK_VERIFICATION_NUMBER_QUERY = "bvn/full?bvn=";
    const NATIONAL_IDENTIFICATION_NUMBER_QUERY = "nin/advance?nin=";
    const IDENTIFICATION_PRODUCT_NAME = "kyc";

    /**
     * Create ordering
     * 
     * @return mixed
     * @throws Exception
     */
    public function initiateOrder(): mixed
    {
        try {
            $totalQuantity = 0;
            foreach ($this->data['bin_purchase'] as $item) {
                $totalQuantity += $item['quantity'];

                $bin = Bin::where("name", $item['category'])->first();
                if ($bin->stock < $item['quantity']){
                    throw new Exception("Requested quantity exceeds available stock. Please reduce the quantity and try again.");
                }

            }

            
            $this->purchase_amount = ( config("app.env") === "local" || config("app.env") === "staging" ) ? self::SMART_BIN_AMOUNT_TEST : self::SMART_BIN_AMOUNT;
            $this->expected_amount = ( $this->purchase_amount * $totalQuantity );
            if($this->data['payment_type'] === PaymentType::INSTALLMENT) {
                if(!in_array($this->data['payment_period'], ["3", "5"])) throw new Exception("Invalid payment period selected");
                if($this->user['installment_verification_status'] === Status::IN_ACTIVE_NUMERIC) {

                    if(!isset($this->data['bvn']) || empty($this->data['bvn'])) throw new Exception("Bvn was not provided");
                    if(!isset($this->data['nin']) || empty($this->data['nin'])) throw new Exception("Nin was not provided");

                    /** Checks if details already exists */
                    $installmentVerification = InstallmentVerification::where(function ($query) {
                        $query->where('bvn', $this->data['bvn'])
                            ->orWhere('nin', $this->data['nin']);
                    })->exists();

                    if($installmentVerification) throw new Exception("Invalid Identity Verification...");
                    /** Validate BVN and NIN */
                    $this->identityVerification();
                    $this->createInstallmentVerification(); /** Create installment record */
                    $this->updateUser(); /** Update user */
                }
            }

            $this->order_request = $this->createOrder();
            /** Initiate virtual account for payment */
            $this->payment = $this->inititateVirtualAccount($this->order_request->expected_amount);
            $this->createTransaction($this->order_request->expected_amount);
            $this->updateOrder();

            Log::info($this->payment);
            return [
                "amountTopay" => $this->order_request->expected_amount, 
                "reference" => $this->payment["data"]["customer_reference"], 
                "bankName" => "Globus", 
                "account_name" => $this->payment["data"]["account_name"], 
                "account_number" => $this->payment["data"]["account_number"]
            ];
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Create Order
     * 
     * @return mixed
     * @throws Exception
     */
    public function createOrder(): mixed
    {
        try {
            $dispatch_details = [
                "dispatch_address" => $this->data['dispatch_address'],
                "dispatch_city" => $this->data['dispatch_city'],
                "dispatch_postal" => $this->data['dispatch_postal']
            ];
            $receiver_details = [
                "receiver_name" => $this->data['receiver_name'] ?? null,
                "receiver_phone" => $this->data['receiver_phone'] ?? null
            ];

            /** ONE-OFF PAYMENT */
            $payable_amount=0;
            if($this->data['payment_type'] === PaymentType::ONEOFF) {
               // $discounted_rate = $this->expected_amount; //( 5 / 100 ) * 
               // - $discounted_rate
                $payable_amount = $this->expected_amount;
                $this->transaction_fee = ( 1.25 / 100 ) * $payable_amount;
                $payable_amount = $payable_amount + $this->transaction_fee;
            } else {
                /** INSTALLMENT PAYMENT */
                $first_installment_payment = ($this->expected_amount / 100 ) * 25;
                $this->transaction_fee = ( 1.25 / 100 ) * $first_installment_payment;
                $payable_amount = ( $first_installment_payment + $this->transaction_fee);
            }

            $order = new Order();
            $order->user_id = $this->user['id'];
            $order->order_reference = $this->helper->generateOrderId();
            $order->bin_purchase = json_encode($this->data['bin_purchase']);
            $order->color = $this->data['color'];
            if(isset($this->data['save_dispatch_details']) && $this->data['save_dispatch_details'] === true) $order->store_dispatch_details = $this->data['save_dispatch_details'];
            $order->dispatch_details = json_encode($dispatch_details);
            if( isset($this->data['receiver_name']) && !empty($this->data['receiver_name'])) $order->receiver_details = json_encode($receiver_details);
            $order->payment_type = $this->data['payment_type'];
            if( isset($this->data['payment_period']) && !empty($this->data['payment_period']) && $this->data['payment_type'] === PaymentType::INSTALLMENT) $order->payment_period = $this->data['payment_period'];
            $order->payment_status = Status::COMPLETED;
            $order->amount = $this->purchase_amount;
            $order->expected_amount = ( $this->user['email'] === "olajide@uniswitchng.com" ) ? 100 : $payable_amount;
            // $order->expected_amount = $payable_amount;
            $order->total_amount = $this->expected_amount;
            $order->status = Status::PENDING;
            $order->save();
            return $order;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Create virtual account
     * @param mixed $expected_amount
     * @return mixed
     * @throws Exception
     */
    private function inititateVirtualAccount(mixed $expected_amount): mixed
    {
        try {
            $payload = [
                "account_name" => $this->user['name'],
                "amount" => $expected_amount,
                "customer_reference" => $this->helper->generateReference(),
                "type" => "Corporate",
                "channel" => "Globus"
            ];
            $header = [
                'api-key' => config('payment.sarepay_secret_key')
            ];
            $endpoint = config('payment.sarepay_base_url')."/api/virtual-accounts/onetime";
            $response = Http::withHeaders($header)->asJson()->post($endpoint, $payload, [])->json();
            if(!$response || !isset($response["data"]) || $response["data"]["status"] !== Status::ACTIVE) throw new Exception("Unable to process payment at the moment, please try again later");
            return $response;
        } catch (Exception $exception) {
            Log::info($exception);
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Create transaction
     * @param mixed $expect_amount
     * @return Transaction
     * @throws Exception
     */
    private function createTransaction(mixed $expected_amount): Transaction
    {
        try {
            $transaction = new Transaction();
            $transaction->user_id = $this->user['id'];
            $transaction->order_reference = $this->order_request->order_reference;
            $transaction->account_number = $this->payment["data"]["account_number"];
            $transaction->reference = $this->payment["data"]["customer_reference"];
            $transaction->provider_reference = null;
            $transaction->amount = $expected_amount;
            $transaction->transaction_fee = $this->transaction_fee;
            $transaction->type = Status::CREDIT;
            $transaction->transaction_type = Status::COLLECTION;
            $transaction->narration = "LAWMA SMART BIN PURCHASE";
            $transaction->channel = "SAREPAY";
            $transaction->status = Status::PENDING;
            $transaction->provider_status = Status::PENDING;
            $transaction->virtual_account_meta = ($this->payment ) ? json_encode($this->payment) : null;
            $transaction->save();
            return $transaction;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Update Order
     * @return void 
     */
    private function updateOrder():void
    {
        $this->order_request->account_number = $this->payment['data']['account_number'];
        $this->order_request->save();
        return;
    }


     /**
     * Get All Order
     * @return mixed 
     */
    public function getAllOrders(array $filters = []): mixed
    {
        $query = Order::with('users');

        if (!empty($filters['status'])) {
            $query->where('status', strtolower($filters['status']));
        }

        if (!empty($filters['category'])) {
            $query->where('category', strtolower($filters['category']));
        }

        return $query->get();
    }

    /**
     * Fetch Order hsitory
     */
    public function fetchOrderHistory(): mixed
    {
        try {
            $order = Order::where("user_id", $this->user->id);
            $order = $order->orderBy("created_at", "desc");
            $order = $order->paginate(env('PAGE_ROWS'));
            return new OrderCollection($order);
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }

    }

    /**
     * Initiate Next Payment
     * @return array{amountTopay: mixed, reference: mixed, bankName: string, account_name: mixed, account_number: mixed} 
     * @throws Exception 
     */
    public function initiateNextPayment(): mixed
    {
        try {
            $this->order_request = Order::where('order_reference', $this->data['order_reference'])->first();
            if($this->order_request->payment_type !== PaymentType::INSTALLMENT) throw new Exception("Payment not accepted.");
            if($this->order_request->payment_status === Status::COMPLETED) throw new Exception("Payment was already completed.");

            /** Initiate virtual account for payment */
            $this->payment = $this->inititateVirtualAccount($this->data['amount']);
            $this->createTransaction($this->data['amount']);
            $this->updateOrder();
            Log::info($this->payment);

            return [
                "amountTopay" => $this->data['amount'], 
                "reference" => $this->payment["data"]["customer_reference"], 
                "bankName" => "Globus", 
                "account_name" => $this->payment["data"]["account_name"], 
                "account_number" => $this->payment["data"]["account_number"]
            ];
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Validate BVN
     *
     * @return array
     */
    public function validateBvn(): array
    {
        if(config('app.env') === "local" || config('app.env') === "staging") $validateBvn = $this->dojahTestBvn;
        else $validateBvn = $this->data["bvn"];

        $response = $this->makeProtectedDojahApiGet($validateBvn, self::BANK_VERIFICATION_NUMBER_QUERY);
        if(isset($response["entity"])) {

            if(config('app.env') === "local" || config('app.env') === "staging") {
                $this->installment_verification_log->bvn_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                $this->installment_verification_log->bvn_meta = json_encode($response["entity"]);
                $this->installment_verification_log->save();
                return ["status" => true];
            }
            
            if($response["entity"]["first_name"] || $response["entity"]["last_name"] || $response["entity"]["middle_name"]) {
                $names = [strtoupper($response["entity"]["first_name"]), strtoupper($response["entity"]["last_name"]), strtoupper($response["entity"]["middle_name"])];
                if(!in_array(strtoupper($this->user['name']), $names)) {
                    $this->installment_verification_log->bvn_provider_response = Status::ERROR_IDENTITY_RESPONSE;
                    $this->installment_verification_log->bvn_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => false];
                } else {
                    $this->installment_verification_log->bvn_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                    $this->installment_verification_log->bvn_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => true];
                }
            }
        } else {
            $this->installment_verification_log->bvn_provider_response = Status::ERROR_IDENTITY_RESPONSE;
            $this->installment_verification_log->bvn_meta = json_encode($response["error"]);
            $this->installment_verification_log->save();
            return ["status" => false];
        }

        $this->installment_verification_log->bvn_provider_response = "An error occurred";
        $this->installment_verification_log->bvn_meta = json_encode([]);
        $this->installment_verification_log->save();
        return ["status" => false, "message" => "An error occurred"];
    }

    /**
     * Validate NIN
     * 
     * @return array
     */
    public function validateNin(): array
    {
        if(config('app.env') === "local" || config('app.env') === "staging") $validateNin = $this->dojahTestNin;
        else $validateNin = $this->data["nin"];

        $response = $this->makeProtectedDojahApiGet($validateNin, self::NATIONAL_IDENTIFICATION_NUMBER_QUERY);
        if(isset($response["entity"])) {

            if(config('app.env') === "local" || config('app.env') === "staging") {
                $this->installment_verification_log->nin_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                $this->installment_verification_log->nin_meta = json_encode($response["entity"]);
                $this->installment_verification_log->save();
                return ["status" => true];
            }
            
            if($response["entity"]["first_name"] || $response["entity"]["last_name"] || $response["entity"]["middle_name"]) {
                $names = [strtoupper($response["entity"]["first_name"]), strtoupper($response["entity"]["last_name"]), strtoupper($response["entity"]["middle_name"])];
                if(!in_array(strtoupper($this->user['name']), $names)) {
                    $this->installment_verification_log->nin_provider_response = Status::ERROR_IDENTITY_RESPONSE;
                    $this->installment_verification_log->nin_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => false];
                } else {
                    $this->installment_verification_log->nin_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                    $this->installment_verification_log->nin_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => true];
                }
            }
        } else {
            $this->installment_verification_log->nin_provider_response = Status::ERROR_IDENTITY_RESPONSE;
            $this->installment_verification_log->nin_meta = json_encode($response["error"]);
            $this->installment_verification_log->save();
            return ["status" => false];
        }

        $this->installment_verification_log->nin_provider_response = "An error occurred";
        $this->installment_verification_log->nin_meta = json_encode([]);
        $this->installment_verification_log->save();
        return ["status" => false, "message" => "An error occurred"];
    }

    /**
     * Identity checks
     * 
     * @param mixed $queryParam 
     * @param mixed $path 
     * @return mixed 
     */
    protected function makeProtectedDojahApiGet(mixed $queryParam, mixed $path): mixed
    {
        $url = $this->dojahBaseUrl."/".self::IDENTIFICATION_PRODUCT_NAME."/".$path.$queryParam;
        $response = Http::withHeaders(
            [
                'AppId' => $this->dojahAppId,
                'Authorization' => $this->dojahSecretKey
            ]
        )->asJson()->get($url)->json();
        
        return $response;
    }

    /**
     * Identity Verification
     * @return mixed
     * @throws Exception 
     */
    public function identityVerification(): mixed
    {
        try {
            $this->installment_verification_log = $this->installmentVerificationLog();
            $validation_response = $this->validateBvn();
            if($validation_response["status"] === false) throw new Exception("Invalid Identity Verification..");
            $validation_response = $this->validateNin();
            if($validation_response["status"] === false) throw new Exception("Invalid Identity Verification.");
            return true;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Installment Verification Log
     * 
     * @return InstallmentVerificationLog
     */
    public function installmentVerificationLog(): InstallmentVerificationLog
    {
        $installmentVerificationLog = new InstallmentVerificationLog();
        $installmentVerificationLog->user_id = $this->user['id'];
        $installmentVerificationLog->bvn = $this->data['bvn'];
        $installmentVerificationLog->nin = $this->data['nin'];
        $installmentVerificationLog->save();
        return $installmentVerificationLog;
    }

    /**
     * Create Installment Verification
     * 
     * @return void
     */
    public function createInstallmentVerification():void
    {
        $installmentVerification = new InstallmentVerification();
        $installmentVerification->user_id = $this->user['id'];
        $installmentVerification->bvn = $this->data['bvn'];
        $installmentVerification->nin = $this->data['nin'];
        $installmentVerification->save();
    }

    /**
     * Update user
     * 
     * @return void
     */
    public function updateUser():void
    {
        /** Update user table */
        $user = User::where('id', $this->user['id'])->first();
        $user->installment_verification_status = 1;
        $user->save();
    }
}
