<?php

namespace App\Services\Admin\Order;

use App\Enums\Category;
use App\Models\CommissionHistory;
use App\Models\Referral;
use Exception;
use App\Models\User;
use App\Enums\Status;
use App\Models\Order;
use App\Enums\PaymentType;
use App\Utilities\Helpers;
use App\Models\Transaction;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Http;
use App\Models\InstallmentVerification;
use App\Models\InstallmentVerificationLog;
use App\Http\Resources\Merchant\OrderCollection;

class OrderService
{
    protected mixed $data;
    protected mixed $user;
    protected mixed $helper;
    protected mixed $expected_amount;
    protected mixed $order_request;
    protected mixed $payment;
    protected mixed $installment_verification_log;

    protected string $dojahBaseUrl;
    protected string $dojahSecretKey;
    protected string $dojahAppId;
    protected string $dojahTestBvn;
    protected string $dojahTestNin;

    public function __construct($data = null, $user = null)
    {
        $this->data = $data;
        $this->user = $user;
        $this->helper = new Helpers();
    }

    const GENERAL_SMART_BINS_AMOUNT = 100;
    const RECYCLABLES_SMART_BINS_AMOUNT = 100;
    const SMART_BIN_AMOUNT = 100;
    const BANK_VERIFICATION_NUMBER_QUERY = "bvn/full?bvn=";
    const NATIONAL_IDENTIFICATION_NUMBER_QUERY = "nin/advance?nin=";
    const IDENTIFICATION_PRODUCT_NAME = "kyc";

    

     /**
     * Get All Order
     * @return mixed 
     */
    public function getAllOrders(array $filters = []): mixed
    {
        $query = Order::with(['users']);

        if (!empty($filters['status'])) {
            $query->where('status', strtolower($filters['status']));
        }

        if (!empty($filters['category'])) {
            $query->where('category', strtolower($filters['category']));
        }


        if (!empty($filters['date'])) {
            $query->whereDate('created_at', $filters['date']);
        }

        $orders = $query->latest()->get()->map(function ($order) {
            $details = is_array($order->bin_purchase)
                ? $order->bin_purchase
                : json_decode($order->bin_purchase, true);

            $secDetails = is_string($details) ? json_decode($details, true) : $details;

           
            $categories = collect($secDetails)->pluck('category')->unique();
        
            
            $binName = match (true) {
                $categories->count() === 2 && $categories->contains(Category::GENERAL) && $categories->contains(Category::RECYCLABLES) => 'both',
                default => $categories->first(),
            };
        
            // Determine referral status based on receiver_details
            $referral = is_null($order->receiver_details) ? 0 : 1;


            $agentName = null;
            $refer = Referral::where("user_id", $order->user_id)->first();
               
            if ($refer){
                $agent = User::find($refer->referral_id);            
               
                $agentName = $agent->name;
            }

            // Return full order data + bin_type + referral
            return $order->toArray() + [
                'bin_type' => $binName,
                'referral' => $referral,
                'agent' => $agentName
            ];
        });

        return $orders;
        
    }

    /**
     * Fetch Order hsitory
     */
    public function fetchOrderHistory(): mixed
    {
        try {
            $order = Order::where("user_id", $this->user->id);
            $order = $order->orderBy("created_at", "desc");
            $order = $order->paginate(env('PAGE_ROWS'));
            return new OrderCollection($order);
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }

    }

    

    
    /**
     * Validate BVN
     *
     * @return array
     */
    public function validateBvn(): array
    {
        if(config('app.env') === "local" || config('app.env') === "staging") $validateBvn = $this->dojahTestBvn;
        else $validateBvn = $this->data["bvn"];

        $response = $this->makeProtectedDojahApiGet($validateBvn, self::BANK_VERIFICATION_NUMBER_QUERY);
        if(isset($response["entity"])) {

            if(config('app.env') === "local" || config('app.env') === "staging") {
                $this->installment_verification_log->bvn_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                $this->installment_verification_log->bvn_meta = json_encode($response["entity"]);
                $this->installment_verification_log->save();
                return ["status" => true];
            }
            
            if($response["entity"]["first_name"] || $response["entity"]["last_name"] || $response["entity"]["middle_name"]) {
                $names = [strtoupper($response["entity"]["first_name"]), strtoupper($response["entity"]["last_name"]), strtoupper($response["entity"]["middle_name"])];
                if(!in_array(strtoupper($this->user['name']), $names)) {
                    $this->installment_verification_log->bvn_provider_response = Status::ERROR_IDENTITY_RESPONSE;
                    $this->installment_verification_log->bvn_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => false];
                } else {
                    $this->installment_verification_log->bvn_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                    $this->installment_verification_log->bvn_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => true];
                }
            }
        } else {
            $this->installment_verification_log->bvn_provider_response = Status::ERROR_IDENTITY_RESPONSE;
            $this->installment_verification_log->bvn_meta = json_encode($response["error"]);
            $this->installment_verification_log->save();
            return ["status" => false];
        }

        $this->installment_verification_log->bvn_provider_response = "An error occurred";
        $this->installment_verification_log->bvn_meta = json_encode([]);
        $this->installment_verification_log->save();
        return ["status" => false, "message" => "An error occurred"];
    }

    /**
     * Validate NIN
     * 
     * @return array
     */
    public function validateNin(): array
    {
        if(config('app.env') === "local" || config('app.env') === "staging") $validateNin = $this->dojahTestNin;
        else $validateNin = $this->data["nin"];

        $response = $this->makeProtectedDojahApiGet($validateNin, self::NATIONAL_IDENTIFICATION_NUMBER_QUERY);
        if(isset($response["entity"])) {

            if(config('app.env') === "local" || config('app.env') === "staging") {
                $this->installment_verification_log->nin_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                $this->installment_verification_log->nin_meta = json_encode($response["entity"]);
                $this->installment_verification_log->save();
                return ["status" => true];
            }
            
            if($response["entity"]["first_name"] || $response["entity"]["last_name"] || $response["entity"]["middle_name"]) {
                $names = [strtoupper($response["entity"]["first_name"]), strtoupper($response["entity"]["last_name"]), strtoupper($response["entity"]["middle_name"])];
                if(!in_array(strtoupper($this->user['name']), $names)) {
                    $this->installment_verification_log->nin_provider_response = Status::ERROR_IDENTITY_RESPONSE;
                    $this->installment_verification_log->nin_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => false];
                } else {
                    $this->installment_verification_log->nin_provider_response = Status::SUCCESS_IDENTITY_RESPONSE;
                    $this->installment_verification_log->nin_meta = json_encode($response["entity"]);
                    $this->installment_verification_log->save();
                    return ["status" => true];
                }
            }
        } else {
            $this->installment_verification_log->nin_provider_response = Status::ERROR_IDENTITY_RESPONSE;
            $this->installment_verification_log->nin_meta = json_encode($response["error"]);
            $this->installment_verification_log->save();
            return ["status" => false];
        }

        $this->installment_verification_log->nin_provider_response = "An error occurred";
        $this->installment_verification_log->nin_meta = json_encode([]);
        $this->installment_verification_log->save();
        return ["status" => false, "message" => "An error occurred"];
    }

    /**
     * Identity checks
     * 
     * @param mixed $queryParam 
     * @param mixed $path 
     * @return mixed 
     */
    protected function makeProtectedDojahApiGet(mixed $queryParam, mixed $path): mixed
    {
        $url = $this->dojahBaseUrl."/".self::IDENTIFICATION_PRODUCT_NAME."/".$path.$queryParam;
        $response = Http::withHeaders(
            [
                'AppId' => $this->dojahAppId,
                'Authorization' => $this->dojahSecretKey
            ]
        )->asJson()->get($url)->json();
        
        return $response;
    }

    /**
     * Identity Verification
     * @return mixed
     * @throws Exception 
     */
    public function identityVerification(): mixed
    {
        try {
            $this->installment_verification_log = $this->installmentVerificationLog();
            $validation_response = $this->validateBvn();
            if($validation_response["status"] === false) throw new Exception("Invalid Identity Verification..");
            $validation_response = $this->validateNin();
            if($validation_response["status"] === false) throw new Exception("Invalid Identity Verification.");
            return true;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Installment Verification Log
     * 
     * @return InstallmentVerificationLog
     */
    public function installmentVerificationLog(): InstallmentVerificationLog
    {
        $installmentVerificationLog = new InstallmentVerificationLog();
        $installmentVerificationLog->user_id = $this->user['id'];
        $installmentVerificationLog->bvn = $this->data['bvn'];
        $installmentVerificationLog->nin = $this->data['nin'];
        $installmentVerificationLog->save();
        return $installmentVerificationLog;
    }

    public function editOrderStatus($id)
    {
        $order = Order::with('latestTransaction')->where("id", $id)->first();
        $latest = $order->latestTransaction;

        if ($latest->status == Status::SUCCESSFUL){
            $order->delivery_status = Status::COMPLETED;
            $order->save();
    
            return $order;
        }

        return $order;
       
    }
    /**
     * Create Installment Verification
     * 
     * @return void
     */
    public function createInstallmentVerification():void
    {
        $installmentVerification = new InstallmentVerification();
        $installmentVerification->user_id = $this->user['id'];
        $installmentVerification->bvn = $this->data['bvn'];
        $installmentVerification->nin = $this->data['nin'];
        $installmentVerification->save();
    }


    /**
     * Create Installment Verification
     * 
     * @return void
     */
    public function createCommissionHistroy():void
    {
        $commissionHistory = new CommissionHistory();
        $commissionHistory->user_id = $this->user['id'];
        $commissionHistory->order_id = ''; //$this->order['id'];
        $commissionHistory->commission = ''; //$this->data['nin'];
        $commissionHistory->status = Status::PENDING;
        $commissionHistory->save();
    }

    /**
     * Update user
     * 
     * @return void
     */
    public function updateUser():void
    {
        /** Update user table */
        $user = User::where('id', $this->user['id'])->first();
        $user->installment_verification_status = 1;
        $user->save();
    }
}
