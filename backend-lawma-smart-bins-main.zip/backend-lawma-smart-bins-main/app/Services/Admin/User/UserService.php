<?php

namespace App\Services\Admin\User;

use App\Enums\Profile;
use App\Mail\OneTimePasscode;
use App\Models\CommissionHistory;
use Exception;
use App\Models\User;
use App\Enums\Status;
use App\Models\Referral;
use App\Utilities\Helpers;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Hash;
use Mail;
use Spatie\Permission\Models\Role;


class UserService
{
    protected mixed $data;
    protected mixed $user;

    protected mixed $helper;
    const COMMISSION_RATE = 3000;
    public function __construct($data = null, $user = null)
    {
        $this->data = $data;
        $this->user = $user;
        $this->helper = new Helpers();
    }

    const EMAIL_VERIFICATION = "Email-Verification";

    /**
     * Create user
     * 
     * @return mixed
     * @throws Exception
     */
    public function initiateUserCreation(): mixed
    {
        try {
            $smartBinsUser = $this->createUser();
            // if(isset($this->data['referral']) && !empty($this->data['referral'])) {
            //     $referral = User::where('referral', $this->data['referral'])->first();
            //     if($referral) $this->smartBinsReferral($smartBinsUser->id);
            // }
            return $smartBinsUser;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    public function initiateAgentCreation(): mixed
    {
        try {
            $smartBinsUser = $this->createAgent();
            return $smartBinsUser;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }


       /**
     * Create Admin
     * 
     * @return mixed
     * @throws Exception
     */
    public function initiateAdminCreation(): mixed
    {
        try {
            $role = Role::find($this->data['role_id']);
            if (!$role) {
                throw new Exception("Invalid role");
            }

            $smartBinsUser = $this->createUser();            
            $smartBinsUser->assignRole($role);

            return $smartBinsUser;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Create user
     * @return mixed
     * @throws Exception
     */
    public function createUser(): mixed
    {
        try {
            $user = new User();
            $user->name = $this->data["fullname"];
            $user->email = $this->data["email"];
            $user->phone = (new Helpers())->generateReferralCode();
            $user->commision_rate = 0;
            // $user->postal_code = $this->data["postal"];
            // $user->city = $this->data["city"];
            $user->password = $this->data["password"];
            $user->referral_code = (new Helpers())->generateReferralCode();
            $user->type = Profile::ADMIN;
            $user->uuid = (string) Str::uuid();;
            $user->save();
            return $user;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }


      /**
     * Create user
     * @return mixed
     * @throws Exception
     */
    public function createAgent(): mixed
    {
        try {
            $user = new User();
            $user->name = $this->data["fullname"];
            $user->email = $this->data["email"];
            $user->phone = $this->data["phone"];
            $user->address = $this->data["address"];
            $user->postal_code = $this->data["postal"];
            $user->city = $this->data["city"];
            $user->password = $this->data["password"];
            $user->referral_code = (new Helpers())->generateReferralCode();
            $user->type = Profile::AGENT;
            $user->commision_rate = self::COMMISSION_RATE;
            $user->email_verified_at = now();
            $user->uuid = (string) Str::uuid();
            $user->save();
            return $user;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Smart Bins Referral
     * @return void
     * @throws Exception
     */
    public function smartBinsReferral($smartBinsUserID): void
    {
        try {
            $referral = new Referral();
            $referral->user_id = $smartBinsUserID;
            $referral->save();
            return;
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }


    /**
     * Login user
     * @return mixed
     * @throws Exception
     */
    public function loginUser(): mixed
    {
        try {
            $user = User::where('email', $this->data["email"])->first();
            if(!$user) {
                throw new Exception("Invalid credentials provided");
            } elseif(!Hash::check($this->data["password"], $user->password)) {
                throw new Exception("Invalid credentials provided");
            } elseif($user->status !== Status::ACTIVE_NUMERIC) {
                throw new Exception("Your account has been blocked, kindly contact support");
            }

            /** Update login user */    
            $user->last_login = Carbon::now();
            $user->login_count = $user->login_count + 1;
            $user->save();

            return $user;
        } catch (Exception $exception) {
            Log::error($exception->getMessage());
            throw new Exception($exception->getMessage());
        }
    }

    /**
     * Get user by Id
     * @param mixed $id
     * @return mixed
     * @throws Exception
     */
    public function getUserById(mixed $id): mixed
    {
        $userData = User::where('id', $id)->first();
        if(!$userData) throw new Exception("User not found");
        return $userData;
    }

    public function getAllAgents(): mixed
    {
        $users = User::with('commissionHistory.orders')->where("type", Profile::AGENT)->latest()->get();

        foreach($users as $user){
            $total_referral = Referral::where("referral_id", $user->id)->count();
            //commissionscommissionscommissions$commissions = $user->commision_rate * $total_referral;

            $pending = CommissionHistory::where("user_id", $user->id)->where("status", Status::PENDING)->sum("commission");
            $paid = CommissionHistory::where("user_id", $user->id)->where("status", Status::PAID)->sum("commission");
            $commissions = CommissionHistory::where("user_id", $user->id)->sum("commission");

            $user['total_commissions'] = $commissions;
            $user['pending_commissions'] = $pending;
            $user['paid_commissions'] = $paid;
            $user['total_referrals'] = $total_referral;
        }

        return $users;
    }

    public function deactivateAgent($id)
    {
        $user = User::where("id", $id)->first();

        if (!$user){
            throw new Exception("User not found");
        }

        $user->status = 0;
        $user->save();
        
        return $user;
    }

    public function activateAgent($id)
    {
        $user = User::where('id', $id)->first();
        if (!$user){
            throw new Exception("User not found");
        }
        $user->status = 1;
        $user->save();

        return $user;
    }

    public function getAllAdmin(): mixed
    {
        $users = User::where("type", Profile::ADMIN)->where("status", Status::ACTIVE_NUMERIC)->get();

        foreach($users as $user){
            
            //$roles = $user->getRoleNames()->first();;
            $user->role_name = $user->getRoleNames()->first();
        }
       
        return $users;
    }


    public function getAllUsers(): mixed
    {
        $users = User::where("type", Profile::USER)->whereNotNull("email_verified_at")->orderBy('created_at', 'desc')->get();

        return $users;
    }


    public function editRate($id)
    {
        $userData = User::where('id', $id)->first();
        $userData->commision_rate = $this->data['rate'];
        $userData->save();

        return $userData;
    }

    public function sendOtp(): void
    {
        $oneTimePasscode = $this->helper->randomNumbers(); 
        
        Mail::to($this->data->email)->queue(new OneTimePasscode($this->data->name, $oneTimePasscode));
        

        $key = self::EMAIL_VERIFICATION . $this->data->email;
        Redis::set($key, $oneTimePasscode, 'EX', 180);
       
    }

    public function getUserByUuid(mixed $uuid): mixed
    {
        $userData = User::where('uuid', $uuid)->first();
        if(!$userData) throw new Exception("User not found");
        return $userData;
    }

    /**
     * Validate One Time Passcode
     * 
     * @return mixed
     * @throws Exception
     */
    public function validateOtp(): mixed
    {
        try {
            $user = $this->getUserByUuid($this->data["id"]);
            
            $response = Redis::get(self::EMAIL_VERIFICATION.$user->email); /** Retrieve values from Redis */
            if($response) {
                if($this->data['otp'] !== $response) {
                    throw new Exception("Invalid OTP provided");
                }
                Redis::del($response);
                return $user;
            } else {
                throw new Exception("OTP has expired");
            }
        } catch (Exception $exception) {
            throw new Exception($exception->getMessage());
        }
    }
}
