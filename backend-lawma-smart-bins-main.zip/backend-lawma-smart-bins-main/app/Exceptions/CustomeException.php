<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Contracts\Container\BindingResolutionException;

class CustomException extends Exception
{
    protected $message;
    protected $code;

    public function __construct($message = "Something went wrong!", $code = 400)
    {
        $this->message = $message;
        $this->code = $code;
    }

    /**
     * @param mixed $request 
     * @return JsonResponse
     */
    public function render($request): JsonResponse
    {
        return errorResponse(
            [],
            message: $this->message,
            statusCode: $this->code
        );
    }
}
