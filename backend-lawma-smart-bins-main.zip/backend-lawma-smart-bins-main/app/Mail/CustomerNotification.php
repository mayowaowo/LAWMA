<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class CustomerNotification extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     */
    public function __construct(protected array $data)
    {
        //
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: 'New Registeration',
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            markdown: 'mail.cddw-registration-notification',
            with: [
                'name' => $this->data["name"],
                'referenceID' => $this->data["referenceID"],
                'customerID' => $this->data["customerID"],
                'payerName' => $this->data["payerName"],
                'amount' => $this->data["amount"],
                'paymentType' => $this->data["paymentType"],
                'effectiveDate' => $this->data["effectiveDate"],
                'region' => $this->data["region"],
                'status' => $this->data["status"],
                'siteAddress' => $this->data["siteAddress"],
                'transactionReference' => $this->data["transactionReference"],
                'transactionDate' => $this->data["transactionDate"],
            ]
        );

    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
