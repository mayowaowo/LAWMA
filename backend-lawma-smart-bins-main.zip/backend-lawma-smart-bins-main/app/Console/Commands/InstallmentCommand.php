<?php

namespace App\Console\Commands;

use App\Enums\Status;
use App\Models\Order;
use App\Enums\PaymentType;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use App\Jobs\ProcessInstallmentOrderJob;

class InstallmentCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:installment-command';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $installment_order = Order::where("payment_type", PaymentType::INSTALLMENT)
                                    ->where("payment_status", Status::NOT_COMPLETED)
                                    ->where("status", Status::SUCCESSFUL)
                                    ->take(100)
                                    ->get();
        Log::info($installment_order);

        foreach ($installment_order as $items) {
            ProcessInstallmentOrderJob::dispatch($items->id);
        }

        $this->info('Your command was successfully executed.');
    }
}
