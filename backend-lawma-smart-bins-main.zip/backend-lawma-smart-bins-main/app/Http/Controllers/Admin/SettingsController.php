<?php

namespace App\Http\Controllers\Admin;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\Merchant\UserResource;
use Spatie\Permission\Models\Role;


class SettingsController extends Controller
{
    public function roleMgt(): JsonResponse
    {
        $roles = Role::with('permissions:id,name')->get(['id', 'name']);
        return $this->helper()->successResponse(message: "Roles successful", data: [$roles]);
    }

}