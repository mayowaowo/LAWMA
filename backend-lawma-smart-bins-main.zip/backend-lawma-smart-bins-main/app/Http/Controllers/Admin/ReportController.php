<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Category;
use App\Enums\Profile;
use App\Enums\Status;
use App\Http\Controllers\Controller;
use App\Models\CommissionHistory;
use App\Models\Order;
use App\Models\Referral;
use App\Models\Transaction;
use App\Models\User;
use App\Services\Admin\Order\OrderService;
use App\Services\Admin\User\UserService;
use Exception;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Illuminate\Http\Request;
use Nette\Utils\Helpers;

class ReportController extends Controller
{
    public function reports(Request $request)
    {
        try {
            $filters = $request->only(['status', 'category', 'name', 'date']);

            $orders = (new OrderService())->getAllOrders($filters);
            
            
            $revenue = Transaction::where("status", Status::SUCCESSFUL)->sum("amount");

            $referral = 0; //Order::whereNotNull('receiver_details')->count();
            $direct = 0;
            
            $categoryTotals = [];
            foreach ($orders as $purchase) {

               
                $details = is_array($purchase['bin_purchase'])
                ? $purchase['bin_purchase']
                : json_decode($purchase['bin_purchase'], true);

                
                if (is_string($details)) {
                    $orderArray = json_decode($details, true); // second decode
                } else {
                    $orderArray = $details;
                }
                
                
               

                foreach ($orderArray as $item) {
                    $category = $item['category'];
                    $quantity = $item['quantity'];

                    if (!isset($categoryTotals[$category])) {
                        $categoryTotals[$category] = 0;
                    }

                   
                    $categoryTotals[$category] += $quantity;

                    //if ($purchase['users']['type'] == Profile::USER){
                        $refer = Referral::where("user_id", $purchase['users']['id'])->first();
                        if ($refer){
                            $referral+=$quantity;
                            
                            $agent = User::find($refer->referral_id);
                            $purchase['agent'] = $agent;
                        }else{
                            $direct+=$quantity;
                            $purchase['agent'] = [];
                        }
                   // }
                }

                
            }

            $totalOrder = array_sum($categoryTotals);

            $topReferrers = User::withCount('referrals')
                    ->orderByDesc('referrals_count')
                    ->limit(4)
                    ->get();
            foreach($topReferrers as $user){
                $total_referral = Referral::where("referral_id", $user->id)->count();
                $commissions = $user->commision_rate * $total_referral;
    
                $pending = CommissionHistory::where("user_id", $user->id)->where("status", Status::PENDING)->count();
    
                $user['total_commissions'] = $commissions;
                $user['pending_commissions'] = $pending;
                $user['total_referrals'] = $total_referral;
            }

            $reports = [
                "total_orders" => $totalOrder,
                "total_revenue" => $revenue,
                "referral_orders" => $referral,
                "direct_orders" => $direct,
                "order" => $orders,
                "agent_comparison" => $topReferrers
            ];

        } catch (Exception $exception) {
            return (new \App\Utilities\Helpers())->errorResponse(message: $exception->getMessage());
        }

        return $this->helper()->successResponse(message: "Reports fetch successful", data: [$reports]);
    }
    public function export(Request $request)
    {
        $type = $request->query('type', 'csv'); // default to CSV

        $source = $request->query('source');
        $customerName = $request->query('name');
        $dateRange = $request->query('date');
        $paymentStatus = $request->query('status');
        $binType = $request->query('bin');


        if (!in_array($type, ['csv', 'pdf'])) {
            return (new \App\Utilities\Helpers())->errorResponse(message: 'Invalid export type');
        }
       
        $reports = Order::with('users') 
        ->when($customerName, function ($query, $customerName) {
            $query->whereHas('users', function ($q) use ($customerName) {
                $q->where('name', 'like', '%' . $customerName . '%');
            });
        })
        ->when($dateRange, function ($query, $dateRange) {
            [$startDate, $endDate] = explode(' - ', $dateRange);
            $query->whereBetween('created_at', [
                \Carbon\Carbon::parse($startDate)->startOfDay(),
                \Carbon\Carbon::parse($endDate)->endOfDay()
            ]);
        })
        ->when($paymentStatus && $paymentStatus !== 'all', function ($query) use ($paymentStatus) {
            
            $query->where('status', $paymentStatus);

        })
        ->when($binType === 'GENERAL', function ($query) {
            $query->whereRaw("JSON_CONTAINS(bin_purchase, '[{\"category\": \"GENERAL\"}]')")
            ->whereRaw("NOT JSON_CONTAINS(bin_purchase, '[{\"category\": \"RECYCLABLES\"}]')");
        })
        ->when($binType === 'RECYCLABLES', function ($query) {
            $query->whereRaw("JSON_CONTAINS(bin_purchase, '[{\"category\": \"RECYCLABLES\"}]')")
            ->whereRaw("NOT JSON_CONTAINS(bin_purchase, '[{\"category\": \"GENERAL\"}]')");
        })
        ->when($binType === 'both', function ($query) {
            $query->whereRaw("JSON_CONTAINS(bin_purchase, '[{\"category\": \"GENERAL\"}]')")
            ->whereRaw("JSON_CONTAINS(bin_purchase, '[{\"category\": \"RECYCLABLES\"}]')");
        })
     
        ->when($binType === 'all', function ($query) {
           
        }) 
   
        ->latest()
        ->get();

        
       

        $direct = [];
        $referrer = [];
        
        foreach ($reports as $item) {
            $user = $item->users;
            $refer = $user ? Referral::where("user_id", $user->id)->first() : null;

            $agentName = null;
            if ($refer){
                $agent = User::find($refer->referral_id);
                $agentName = $agent->name;
            }

            $item['agent'] = $agentName;

            if ($refer) {
                $referrer[] = $item;
            } else {
                $direct[] = $item;
            }
        }
        
        if ($source == 'referral'){
            $order = $referrer;
        }else if ($source == 'direct'){
            $order = $direct;
        }else{
            $order = $reports;
        }
      
        
        
        if ($type === 'csv') {
            return $this->exportCsv($order, $source);
        }
        
        return $this->exportCsv($order, $source);
     
    }

    public function exportCsv($order, $source)
    {
            $fileName = 'reports_' . now()->format('Y_m_d_His') . '.csv';
      
            $handle = fopen('php://temp', 'r+');

            if ($source == 'referral'){
                fputcsv($handle, ['Order Reference', 'Customer Name', 'Phone Number', 'Address', 'Customer Email', 'Bin Type', 'Bin Color', 'Bin Quantity', 'Agent Name', 'Amount', 'Payment Status', 'Delivery Status', 'Date of Purchase']);                
            }else if ($source == 'direct'){
                fputcsv($handle, ['Order Reference', 'Customer Name', 'Phone Number', 'Address', 'Customer Email', 'Bin Type', 'Bin Color', 'Bin Quantity', 'Amount', 'Payment Status', 'Delivery Status', 'Date of Purchase']);
            }else{
                fputcsv($handle, ['Order Reference', 'Customer Name', 'Phone Number', 'Address', 'Customer Email', 'Bin Type', 'Bin Color', 'Bin Quantity', 'Agent Name', 'Amount', 'Payment Status', 'Delivery Status', 'Date of Purchase']);
            }
           
            $reports = $order;
            //Order::with('users')->get();

            foreach ($reports as $report) {

                
                $details = [];
                $customerName = null;
                $customerPhone = null;

                $customerAddress = null;

            
                if ($report->receiver_details) {
                    $details = json_decode($report->receiver_details, true);
                    // dd($details);
                    // if (is_string($details)) {
                    //     $receiverDetails = json_decode($details, true);
                    // }
    
                    if (isset($details['receiver_name']) && !empty($details['receiver_name'])) {
                       
                        $customerName = $details['receiver_name'];
                        $customerPhone = $details['receiver_phone'];
                    }
                }

             

                
               
            
                if (!$customerName && isset($report->users->name)) {
                    $customerName = $report->users->name;
                    $customerPhone = $report->users->phone;
                }
            
                $customerName = $customerName ?? 'Unknown';
            
                $customerPhone = $customerPhone ?? '';

                $binDetails = is_array($report->bin_purchase)
                ? $report->bin_purchase
                : json_decode($report->bin_purchase, true);

                $secDetails = is_string($binDetails) ? json_decode($binDetails, true) : $binDetails;

            
                $categories = collect($secDetails)->pluck('category')->unique();
            

                
                $binName = match (true) {
                    $categories->count() === 2 && $categories->contains(Category::GENERAL) && $categories->contains(Category::RECYCLABLES) => 'both',
                    default => $categories->first(),
                };
            

                $color = match ($binName) {
                    Category::GENERAL => 'green',
                    Category::RECYCLABLES => 'blue',
                    default => 'both', // fallback if undefined
                };

                $totalQuantity = 0;

                $binDetails = json_decode($report->bin_purchase, true);
                if (is_string($binDetails)) {
                    $binDetails = json_decode($binDetails, true);
                }

                if (!is_array($binDetails)) {
                    return; 
                }



                if ($report->dispatch_details) {
                    $dispatch = json_decode($report->dispatch_details, true);
            
                    if (is_array($dispatch) && isset($dispatch['dispatch_address']) && !empty($dispatch['dispatch_city'])) {
                        $customerAddress = $dispatch['dispatch_address'].' '.$dispatch['dispatch_city'];
                       
                    }
                }
                
                if (!$customerAddress && isset($report->users->address)) {
                    $customerAddress = $report->users->address;
                }
            
                $customerAddress = $customerAddress ?? '';
               
               
                // Calculate total quantity
                $totalQuantity = collect($binDetails)->sum('quantity');
                
                if ($source == 'referral'){
                    fputcsv($handle, [
                        $report->order_reference,
                        $customerName,
                        $customerPhone,
                        $customerAddress,
                        $report->users->email,
                        $binName,
                        $color,
                        $totalQuantity,
                        $report->agent,
                        $report->expected_amount,
                        $report->status,
                        $report->delivery_status,
                        $report->created_at->toDateString(),
                    ]);
                }else if ($source == 'direct'){
                    fputcsv($handle, [
                        $report->order_reference,
                        $customerName,
                        $customerPhone,
                        $customerAddress,
                        $report->users->email,
                        $binName,
                        $color,
                        $totalQuantity,
                        $report->expected_amount,
                        $report->status,
                        $report->delivery_status,
                        $report->created_at->toDateString(),
                    ]);
                }else{
                    fputcsv($handle, [
                        $report->order_reference,
                        $customerName,
                        $customerPhone,
                        $customerAddress,
                        $report->users->email,
                        $binName,
                        $color,
                        $totalQuantity,
                        $report->agent,
                        $report->expected_amount,
                        $report->status,
                        $report->delivery_status,
                        $report->created_at->toDateString(),
                    ]);
                }
            }

            rewind($handle);

            // Read the CSV content into a string
            $csvData = stream_get_contents($handle);
            fclose($handle);

            // Save to Laravel storage (storage/app/)
            Storage::put($fileName, $csvData);
            

            return response()->download(Storage::path($fileName), $fileName)->deleteFileAfterSend(true);
    }

}


