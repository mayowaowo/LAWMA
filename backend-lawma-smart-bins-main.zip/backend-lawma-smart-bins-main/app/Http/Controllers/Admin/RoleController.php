<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleController extends Controller
{
    public function update(Request $request, User $user)
    {
        $request->validate([
            'role_id' => 'required|string|exists:roles,id',
        ]);
       
         $role = Role::findOrFail($request->input('role_id'));
         
         $user->syncRoles([$role->name]);

         $resource = Role::class;
         ActivityLog::log($request, Auth::id(), $resource, json_encode($request->all()), null, "Updated User Role ", sprintf('Updated user role'));
         return $this->helper()->successResponse(message: "User role updated successfully.", data: [ 'user' => $user->only(['id', 'name', 'email']),
         'role' => $user->getRoleNames()->first()]);
      
    }
}
 