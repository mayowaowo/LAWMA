<?php

namespace App\Http\Controllers\Admin;

use Exception;
use App\Utilities\Helpers;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Admin\UserRequest;
use App\Services\Admin\User\UserService;
use Illuminate\Support\Facades\Password;
use App\Http\Requests\Admin\RegisterRequest;
use App\Http\Resources\Merchant\UserResource;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Services\Merchant\User\UserService as MerchantService;


class UserController extends Controller
{


    public function createAgent(RegisterRequest $request): JsonResponse
    {
        $data = $request->validated();
        $response = (new MerchantService($data))->pendingOnboardingProcess(); /** Checks for pending onboarding process to be continued */
        if($response["status"] === true) {
            $userData = new UserResource($response["data"]);
            return (new Helpers())->successResponse(data: [$userData], message: $response["message"]);
        }
        try {
            $user = (new UserService($data))->initiateAgentCreation();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }

        $email = $user->email;
        $referralCode = $user->referral_code;
        $password = $data['password']; ;
        $resetLink = url("https://lawmasmartbin.com/login");
        //(new MerchantService($data))->emailVerification("EmailVerify", $user);
        (new MerchantService($data))->AgentEmailVerification($user, $referralCode, $password, $resetLink, $email);
        $userData = new UserResource($user);
        $resource = User::class;
        ActivityLog::log($request, Auth::id(), $resource, json_encode($request->all()), null, "Created an agent ", sprintf('Created agent %s', $user->name));
       
        return (new Helpers())->successResponse(data: [$userData], message: "You have successfully created an agent!");
    }


    public function getAllAgents(Request $request): JsonResponse
    {
        try {
            $agents = (new UserService())->getAllAgents();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Agents fetch successful", data: [$agents]);
    }


    public function deactivateAgent(Request $request, $id): JsonResponse
    {
        try {
            $agent = (new UserService())->deactivateAgent($id);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }

        $resource = User::class;
        ActivityLog::log($request, Auth::id(), $resource, json_encode($request->all()), null, "Deactivated an agent ", sprintf('Agent %s was deactivated', $agent->name));
        return $this->helper()->successResponse(message: "Agent deactivated successfully", data: [$agent]);
    }

    public function activateAgent(Request $request, $id): JsonResponse
    {
        try {
            $agent = (new UserService())->activateAgent($id);
        } catch (Exception $exception) {
           return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $resource = User::class;
        ActivityLog::log($request, Auth::id(), $resource, json_encode($request->all()), null, "Activated an agent ", sprintf('Agent %s was activated', $agent->name));
    
        return $this->helper()->successResponse(message: "Agent activated successfully", data: [$agent]);
    }

    public function addAdmin(UserRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $user = (new UserService($data))->initiateAdminCreation();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $userData = new UserResource($user);
        
        $resource = User::class;
        $adminId = Auth::id() ?? 1;
        ActivityLog::log($request, $adminId, $resource, json_encode($request->all()), null, "Created an admin ", sprintf('Created admin %s ', $user->name));
        return $this->helper()->successResponse(message: "Admin created successful", data: [$userData]);
    }

    public function getAdmin(Request $request): JsonResponse
    {
        
        try {
            $users = (new UserService())->getAllAdmin();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        //$userData = UserResource::collection($user);
        return $this->helper()->successResponse(message: "Admin fetch successful", data: [$users]);
    }

    public function getAllRegisteredUsers(Request $request): JsonResponse
    {
        try {
            $agents = (new UserService())->getAllUsers();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Users fetch successful", data: [$agents]);
    }

}