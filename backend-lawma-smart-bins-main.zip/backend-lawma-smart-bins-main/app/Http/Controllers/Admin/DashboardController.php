<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Category;
use App\Enums\Profile;
use App\Enums\Status;
use App\Models\CommissionHistory;
use App\Models\Order;
use App\Models\Transaction;
use App\Models\User;
use App\Utilities\Helpers;
use Carbon\Carbon;
use DB;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\Merchant\UserResource;
use Log;


class DashboardController extends Controller
{
    public function dashboard(Request $request): JsonResponse
    {
        try {
           
            $statuses = [
               Status::SUCCESSFUL,
               Status::PENDING,
            ];

            // Get counts from database
            $counts = Order::select('status')
                ->selectRaw('COUNT(*) as count')
                ->whereIn('status', $statuses)
                ->groupBy('status')
                ->pluck('count', 'status')
                ->toArray();

                $order_status_distribution = array_map(function ($status) use ($counts) {
                    return [
                        'name' => $status,
                        'value' => $counts[$status] ?? 0,
                    ];
                }, $statuses);
                


            $orders = Order::where('status', Status::SUCCESSFUL)->get();

            $categoryTotals = [];

            foreach ($orders as $purchase) {

                $details =  json_decode($purchase->bin_purchase, true);
                
                if (is_string($details)) {
                    $orderArray = json_decode($details, true); // second decode
                } else {
                    $orderArray = $details;
                }
                
               

                foreach ($orderArray as $item) {
                    $category = $item['category'];
                    $quantity = $item['quantity'];

                    if (!isset($categoryTotals[$category])) {
                        $categoryTotals[$category] = 0;
                    }

                   
                    $categoryTotals[$category] += $quantity;
                }
            }

            

            $bin_type_distribution = [];
            foreach ($categoryTotals as $category => $total) {
                $bin_type_distribution[] = [
                    'name' => $category,
                    'value' => $total,
                ];
            }
        

            $now = Carbon::now();
            $startOfWeek = $now->copy()->startOfWeek();
            $startOfLastWeek = $startOfWeek->copy()->subWeek();
            $endOfLastWeek = $startOfWeek->copy()->subSecond();

            //total revenue
            $total_revenue = Transaction::where("status", Status::SUCCESSFUL)->sum("amount");

            //total order
            //$totalOrder = Order::count();
            $totalOrder = array_sum($categoryTotals);
            
            $currentTotalOrder = Order::whereBetween('created_at', [$startOfWeek, $now])->count();
            $previousTotalOrder = Order::whereBetween('created_at', [$startOfLastWeek, $endOfLastWeek])->count();
            $percentageOrderChange = round((($currentTotalOrder - $previousTotalOrder) / max($previousTotalOrder, 1)) * 100, 2);

            //total agents
            $totalAgent = User::where('type', Profile::AGENT)->count();

            //monthly_revenue_trend
            $monthlyRevenue = Transaction::select(
                DB::raw("DATE_FORMAT(created_at, '%Y-%m')"),
                DB::raw("SUM(amount)"),
                DB::raw("MIN(created_at)")
            )
            ->where('status',  Status::SUCCESSFUL)
            ->groupBy(DB::raw("DATE_FORMAT(created_at, '%Y-%m')"))
            ->orderBy(DB::raw("DATE_FORMAT(created_at, '%Y-%m')"), 'asc')
            ->get()
            ->map(function ($item) {
                return [
                    'month' => date('M', strtotime($item->{'MIN(created_at)'})),
                    'total' => (float) $item->{'SUM(amount)'},
                ];
            });

            //commissions paid
            $commission_paid = CommissionHistory::where("status", Status::PAID)->sum("commission");
            

            //weekly referral and commissions
            $startOfMonth = Carbon::now()->startOfMonth();
            $endOfMonth = Carbon::now()->endOfMonth();

            $weeks = collect();

            $current = $startOfMonth->copy();

            while ($current->lte($endOfMonth)) {
                $start = $current->copy();
                $end = $start->copy()->addDays(6)->endOfDay();

                if ($end->gt($endOfMonth)) {
                    $end = $endOfMonth->copy()->endOfDay();
                }

                $weeks->push([
                    'start' => $start->copy(),
                    'end' => $end->copy()
                ]);

                $current->addWeek();
            }

            $weeklyData = [];

            foreach ($weeks as $index => $range) {
                $orderCount = Order::where('status', Status::SUCCESSFUL)->whereBetween('created_at', [$range['start'], $range['end']])->sum("expected_amount");

                $commissionSum = CommissionHistory::where('status', Status::PAID)
                    ->whereBetween('created_at', [$range['start'], $range['end']])
                    ->sum('commission');

                $weeklyData[] = [
                    'week' => 'Week ' . ($index + 1),
                    'orders' => $orderCount,
                    'commission' => (float) $commissionSum
                ];
            }


            
            $output = [
                    'order_status_distribution' => $order_status_distribution,
                    'bin_type_distribution' => $bin_type_distribution,
                    'monthly_revenue_trend' => $monthlyRevenue,
                    'weekly_referral_commissions' => $weeklyData,
                    'overview' => [
                        'total_orders' => [
                            'total_orders' => $totalOrder,
                            'percentage_change' => $percentageOrderChange,
                            'message' => $percentageOrderChange >= 0
                                ? 'Orders increased by ' . $percentageOrderChange . '%'
                                : 'Orders decreased by ' . abs($percentageOrderChange) . '%'
                        ],
                        'total_revenue' => [
                            'total_revenue' => $total_revenue,
                            'percentage_change' => 0,
                        ],
                        'active_agents' => [
                            'active_agents' => $totalAgent,
                            'percentage_change' => 0,
                        ],
                        'commission_paid' => [
                            'commission_paid' => $commission_paid,
                            'percentage_change' => 0,
                        ],
                    ]
                ];
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Dashboard", data: [$output]);
    }
}