<?php

namespace App\Http\Controllers\Admin;

use Exception;
use JsonException;
use App\Models\User;
use App\Enums\Status;
use App\Utilities\Helpers;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use App\Models\CommissionHistory;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Models\CommissionRate;
use Illuminate\Support\Facades\Auth;
use App\Services\Admin\User\UserService;

class CommissionController extends Controller
{
    public function allCommissions(): JsonResponse
    {
        try {
            $agents = (new UserService())->getAllAgents();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }

        $output = array();

        foreach($agents as $agent){
            $rate = [
                'id' => $agent->id,
                'agent_name' => $agent->name,
                'referral_code' => $agent->referral_code,
                'rate' => $agent->commision_rate
            ];
            
            array_push($output, $rate);
        }

        return (new Helpers())->successResponse(message: "Rates", data: [(Object)$output]);
    }

    public function editCommission(Request $request,$id)
    {
        try {
            $validated = $request->validate([
                'rate' => 'required|numeric'
            ]);

            $agent = (new UserService())->getUserById($id);
            
            $rate = (new UserService($request))->editRate($id);

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $resource = User::class;
        ActivityLog::log($request, Auth::id(), $resource, json_encode($request->all()), null, "Edited Rate ", sprintf('Edited rate to %s', $rate->commision_rate));
    
        return (new Helpers())->successResponse(message: "Rate Edited successfully", data: [$rate]);
    }


    public function markCommissionAsPaid(Request $request, $id)
    {
        try {

            $commission = CommissionHistory::where("id", $id)->first();
            
            $commission->status = Status::PAID;
            $commission->paid_date = now();
            $commission->save();

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $resource = CommissionRate::class;
        ActivityLog::log($request, Auth::id(), $resource, json_encode($request->all()), null, "Marked Commission ", 'Marked commission as paid');
    

        return (new Helpers())->successResponse(message: "Commission Marked as Paid", data: [$commission]);


    }

}
