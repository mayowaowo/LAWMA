<?php

namespace App\Http\Controllers\Admin;

use App\Enums\Status;
use App\Models\Transaction;
use App\Utilities\Helpers;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\Merchant\UserResource;


class TransactionController extends Controller
{


    public function manualRepayments(Request $request)
    {
        try {
            
            $repayments = Transaction::with(['user', 'order.transactions'])->orderBy('updated_at', 'asc')->get();
           
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Manual Repayments", data: [$repayments]);
    }
}