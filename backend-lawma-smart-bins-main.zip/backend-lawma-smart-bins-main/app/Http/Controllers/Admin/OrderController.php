<?php

namespace App\Http\Controllers\Admin;

use App\Models\Transaction;
use Exception;
use App\Models\User;
use App\Models\Order;
use App\Utilities\Helpers;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Services\Admin\Order\OrderService;
use App\Http\Resources\Merchant\UserResource;

class OrderController extends Controller
{
    public function getAllOrders(Request $request): JsonResponse
    {
        try {
            $filters = $request->only(['status', 'category']);

            $orders = (new OrderService())->getAllOrders($filters);
                
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Orders fetch successful", data: [$orders]);
    }

    // public function getOrderPaymentHistory($id): JsonResponse
    // {
    //     try {
            
    //         $orders = Order::with("transactions")->find($id);

    //         $output = [
    //             "payment_schedule" => $orders->transactions,
    //             "total_amount" => "",
    //             "initial_payment" => "",
    //             "remaining_amount" => "",
    //             "payment_frequency" => "",
    //             "next_payment_date" => "",
    //         ];
            
                
    //     } catch (Exception $exception) {
    //         return (new Helpers())->errorResponse(message: $exception->getMessage());
    //     }
    //     return $this->helper()->successResponse(message: "Orders fetch successful", data: [$output]);
    // }

    public function editOrderStatus(Request $request, $id): JsonResponse
    {
        try {
            
            $orders = (new OrderService())->editOrderStatus($id);
                
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $resource = Order::class;
        ActivityLog::log($request, Auth::id(), $resource, json_encode($request->all()), null, "Edited Order ", sprintf('Edited order %s status to %s', $orders->order_reference, $orders->status));
    
        return $this->helper()->successResponse(message: "Order edited successful", data: [$orders]);
    }

    public function getUserOrders(int $id)
    {
        try {
        
            $user = User::findOrFail($id);
            
            $orders = (new OrderService([],$user))->fetchOrderHistory();
                
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Orders fetch successful", data: [$orders]);
    }

    public function getOrderPayementInformation($order_reference)
    {
        try {
        
            $order = Order::where("order_reference", $order_reference)->first();
            $transactions = Transaction::where('order_reference',$order_reference)->get();
            $output = [
                "payment_schedule" => $transactions,
                "total_amount" => $order->expected_amount,
                "initial_payment" => $order->firstPaidTransaction?->amount ?? 0,
                "remaining_amount" => $order->getRemainingPendingTransactionAttribute(),
                "payment_frequency" => "Monthly",
                "next_payment_date" => $order->firstPendingTransaction?->created_at,
            ];
              
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Order fetch successful", data: [$output]);
    }
}