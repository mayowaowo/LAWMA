<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests\Admin\BinRequest;
use App\Models\Bin;
use App\Services\Admin\Bin\BinService;
use App\Utilities\Helpers;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\Merchant\UserResource;
use Storage;


class BinController extends Controller
{
    public function allBins(): JsonResponse
    {
        try {
            $bins = (new BinService())->allBins();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return (new Helpers())->successResponse(message: "Bins", data: [(Object)$bins]);
    }

    public function addBin(BinRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $path = $request->file('image')->store('images', 'public');

            // Optionally get the full URL
            $url = Storage::url($path);
            $data['image_path'] = asset($url);
            
            $bin = (new BinService($data))->addBin();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return (new Helpers())->successResponse(message: "Added Bin successfully", data: [$bin]);
    }

    public function editBin(Request $request,$id)
    {
        try {
            $bin = Bin::find($id);
            if (!$bin) {
                return (new Helpers())->errorResponse(message: 'Bin not found');
            }
            $data = $request->all();

            if ($request->file('image')){
                $path = $request->file('image')->store('images', 'public');

                // Optionally get the full URL
                $url = Storage::url($path);
                $data['image_path'] = asset($url);
            }

            
            $bin = (new BinService($data))->editBin($id);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return (new Helpers())->successResponse(message: "Bin Edited successfully", data: [$bin]);
    }
}