<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Enums\Profile;
use Exception;
use App\Utilities\Helpers;
use App\Http\Requests\Admin\EmailVerificationRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Services\Admin\User\UserService;
use App\Http\Resources\Merchant\UserResource;
use App\Http\Requests\Merchant\Auth\LoginRequest;

class LoginController extends Controller
{
    /**
     * Login
     * 
     * @param Request
     * @return JsonResponse
     * @throws Exception
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $user = (new UserService($data))->loginUser();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage(), data: [], statusCode: 401);
        }

        if ($user->type != Profile::ADMIN){
            return (new Helpers())->errorResponse(message: "Permission Denied", data: [], statusCode: 401);
        }
        
       if ($user->email == "lsb@admin.com"){
            $userData = new UserResource($user);
            $token = $user->createToken('Smart')->plainTextToken;
            return (new Helpers())->successResponse(message: "Login Successful", data: ["user" => $userData, "token" => $token], );
       }   

        $userData = new UserResource($user);
        (new UserService($user))->sendOtp();

       return (new Helpers())->successResponse(message: "OTP has been sent", data: ["user" => $userData], );
    }


    public function verifyOtp(EmailVerificationRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $user = (new UserService($data))->validateOtp();
           
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }

        $token = $user->createToken('Smart')->plainTextToken;
        $userData = new UserResource($user);

        return (new Helpers())->successResponse(data: ["user" => $userData, "token" => $token], message: "High Five - Your verification was successful!");
    }

}
