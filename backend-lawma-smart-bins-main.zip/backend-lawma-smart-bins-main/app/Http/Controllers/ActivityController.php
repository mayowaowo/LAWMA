<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ActivityLog;
use Illuminate\Support\Facades\Auth;

class ActivityController extends Controller
{
    public function index() //activity log of a particular admin
    {
      $admin = Auth::user();
      $activities = ActivityLog::where('user_id', $admin->id)->orderBy('created_at', 'desc')->get();
      return $this->helper()->successResponse(message: "Activities fetch successful", data: ['name' => $admin->name, $activities]);
    }

    public function index_() //activity log of everyone regardless of the admin
    {
      $activities = ActivityLog::with('user')->orderBy('created_at', 'desc')->get();
      return $this->helper()->successResponse(message: "Activities fetch successful", data: [$activities]);
    }
}
