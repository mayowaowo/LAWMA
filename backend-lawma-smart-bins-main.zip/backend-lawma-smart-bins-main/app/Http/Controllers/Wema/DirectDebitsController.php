<?php

namespace App\Http\Controllers\Wema;

use App\Http\Controllers\Controller;
use App\Utilities\Helpers;
use Exception;
use Illuminate\Http\Request;

class DirectDebitsController extends Controller
{
    public function directDebit(Request $request)
    {
        try {
           
           
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Direct Debit", data: []);
    }
}
