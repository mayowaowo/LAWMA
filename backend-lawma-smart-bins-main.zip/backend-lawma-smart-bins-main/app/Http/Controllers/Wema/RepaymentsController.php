<?php

namespace App\Http\Controllers\Wema;

use App\Enums\PaymentType;
use App\Enums\Status;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Transaction;
use App\Utilities\Helpers;
use Exception;
use Illuminate\Http\Request;

class RepaymentsController extends Controller
{
    public function activeInstallmentPlans(Request $request)
    {
        try {
           
            $total_active_loans = Order::where('payment_status', Status::NOT_COMPLETED)->where('payment_type', PaymentType::INSTALLMENT)->get();
           
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Installments", data: [$total_active_loans]);
    }

    public function manualRepayments(Request $request)
    {
        try {
            $repayments = Transaction::with('user')->where('status', Status::PENDING)->get();
           
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Manual Repayments", data: [$repayments]);
    }
}
