<?php

namespace App\Http\Controllers\Wema;

use App\Enums\PaymentType;
use App\Enums\Status;
use App\Http\Controllers\Controller;

use App\Models\Order;
use App\Models\Transaction;
use App\Models\User;
use App\Utilities\Helpers;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function dashboard(Request $request): JsonResponse
    {
        try {
           
            $total_active_loans = Order::where('payment_status', Status::NOT_COMPLETED)->where('payment_type', PaymentType::INSTALLMENT)->get();
            $total_customers = User::where('installment_verification_status', Status::ACTIVE_NUMERIC)->get();
            $total = Transaction::where('created_at', '>=', now()->startOfMonth())->sum('amount');
            
            $output = [
                'total_active_loans' => count($total_active_loans),
                'total_customers' => count($total_customers),
                'monthly_repayments' => $total,
                'success_dd_rate' => 0,
                'upcoming_direct_debits' => [],
                'direct_debit_repayments' => [],
                'recent_loan_applications' => $total_active_loans
            ];
         
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Dashboard", data: [$output]);
    }
}
