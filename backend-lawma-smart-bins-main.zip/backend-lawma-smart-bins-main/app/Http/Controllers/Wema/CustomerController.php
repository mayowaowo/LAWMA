<?php

namespace App\Http\Controllers\Wema;

use App\Enums\PaymentType;
use App\Enums\Status;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\User;
use App\Utilities\Helpers;
use Exception;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function customers(Request $request)
    {
        try {
           
            
            $total_customers = User::where('installment_verification_status', Status::ACTIVE_NUMERIC)->orderBy('created_at', 'desc') ->get();

            foreach($total_customers as $customer){
                $active_loans = Order::where('user_id', $customer->id)->where('payment_type', PaymentType::INSTALLMENT)->where('payment_status', Status::NOT_COMPLETED)->count(); 
                $total_loan_amount = Order::where('user_id', $customer->id)->where('payment_type', PaymentType::INSTALLMENT)->where('payment_status', Status::NOT_COMPLETED)->sum('amount'); 

                $customer->active_loans = $active_loans;
                $customer->total_loan_amount = $total_loan_amount;
            }

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return $this->helper()->successResponse(message: "Customers", data: [$total_customers]);
    }
}
