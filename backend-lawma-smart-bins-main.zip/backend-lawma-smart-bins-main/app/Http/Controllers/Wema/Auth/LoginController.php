<?php

namespace App\Http\Controllers\Wema\Auth;

use App\Enums\Profile;
use Exception;
use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Services\Admin\User\UserService;
use App\Http\Resources\Merchant\UserResource;
use App\Http\Requests\Merchant\Auth\LoginRequest;

class LoginController extends Controller
{
    /**
     * Login
     * 
     * @param Request
     * @return JsonResponse
     * @throws Exception
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $user = (new UserService($data))->loginUser();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage(), data: [], statusCode: 401);
        }

        if ($user->type != Profile::WEMA_ADMIN){
            return (new Helpers())->errorResponse(message: "Permission Denied", data: [], statusCode: 401);
        }
        
        $userData = new UserResource($user);
        $token = $user->createToken('Smart')->plainTextToken;
        return (new Helpers())->successResponse(message: "Logged in successfully", data: ["user" => $userData, "token" => $token], );
    }
}
