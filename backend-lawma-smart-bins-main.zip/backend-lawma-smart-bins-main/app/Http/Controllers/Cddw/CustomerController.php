<?php

namespace App\Http\Controllers\Cddw;

use App\Enums\Status;
use App\Http\Controllers\Controller;
use App\Http\Requests\ApplicationRequest;
use App\Http\Requests\Cddw\RegisterRequest;
use App\Http\Requests\Merchant\Auth\LoginRequest;
use App\Http\Resources\RegistrationResource;
use App\Mail\CustomerNotification;
use App\Models\CddwActivityLogs;
use Illuminate\Support\Facades\Storage;
use App\Models\CddwAdmin;
use App\Models\CddwRegisteration;
use App\Models\CddwUser;
use App\Utilities\Helpers;
use Auth;
use Exception;
use Hash;
use Illuminate\Http\Request;
use Mail;

class CustomerController extends Controller
{
    public function registration(RegisterRequest $request)
    {
        try{

            $transactionReference = (new Helpers())->generateRegistrationReference();
            $receiptPath = $this->saveBase64Image($request->payment_receipt);
        
            if (auth()->user()->customer_reference == null){
                $customerReference = (new Helpers())->generateCustomerReference();
            }else{
                $customerReference = auth()->user()->customer_reference;
            }
            
                $reg = CddwRegisteration::create([
                    'name' => auth()->user()->name,
                    'customer_reference' => $customerReference,
                    'transaction_reference' => $transactionReference,
                    'email' => auth()->user()->email,
                    'phone' => auth()->user()->phone,
                    'land_size' => auth()->user()->land_size,
                    'number_of_floors' => auth()->user()->number_of_floors,
                    'location_density' => auth()->user()->location_density,
                    'bin_type' => auth()->user()->bin_type,
                    'evacuation_trips' => auth()->user()->evacuation_trips,
                    'user_id' => auth()->user()->id,
                    'payment_status' => Status::PAID, 
                    'status' => Status::ACTIVE,     
                    'amount' => $request->amount,
                    'collection_date' => $request->collection_date,
                    'payment_receipt' => $receiptPath
                ]);
          
                $resource = CddwRegisteration::class;
          
        }catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }

       // CddwActivityLogs::log($request, auth()->user()->id, $resource, json_encode($request->all()), null, "Customer made a fresh registration", sprintf('Customer made a fresh registration'));
    
        return (new Helpers())->successResponse(message: "Registered successfully", data: ["data" => $reg]);

    }

    public function getRegistration(){
        try{

            $reg = CddwRegisteration::with('users')->where("user_id", auth()->user()->id)->get();

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }
            return (new Helpers())->successResponse( "registerations", data: ["data" => $reg], );
    }

    public function searchCustomer(Request $request)
    {
        $request->validate([
            'name' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'reference' => 'nullable|string|max:255',
        ]);

        $query = CddwRegisteration::query();

        if ($request->has('name') && $request->name !== '') {
            $query->where('name', 'like', '%' . $request->name . '%');
        }

        if ($request->has('email') && $request->email !== '') {
            $query->where('email', 'like', '%' . $request->email . '%');
        }

        if ($request->has('transaction_reference') && $request->reference !== '') {
            $query->where('transaction_reference', $request->reference);
        }

        $transactions = $query->get();

        if ($transactions->isEmpty()) {
            return (new Helpers())->errorResponse('No transactions found matching the search criteria.');
        }

        $data = RegistrationResource::collection($transactions);

        return (new Helpers())->successResponse(message: "Transactions retrieved successfully.", data: ["data" => $data]);
    }

    public function sendEmail(int $id)
    {
        $user = CddwRegisteration::where('id', $id)->first();

        if (!$user){
            return (new Helpers())->errorResponse('No registration found matching the criteria.');
        }

        $notify = [
            "name" => strtoupper($user->name),
            "referenceID" => $user->transaction_reference,
            "customerID" => $user->customer_reference,
            "amount" => (new Helpers())->number_formatter($user->amount),
            "narration" => $user->site_description,
            "status" => $user->status,
            "transactionDate" => (new Helpers())->formatDate($user->created_at),
            'payerName' => $user->name,
            'paymentType' => $user->payment_type,
            'effectiveDate' => (new Helpers())->formatDate($user->effective_date),
            'region' => $user->region,
            'siteAddress' => $user->site_address,
            'transactionReference' => $user->transaction_reference,
        ];

       
        Mail::to($user->email)->queue(new CustomerNotification($notify));
        
    }


    public function newApplicantRegister(ApplicationRequest $request)
    {
        try{

          
            $sitePlanPath = $this->saveBase64Image($request->site_plan);
            
            $receiptPlanPath = $this->saveBase64Image($request->payment_receipt);
            

            $data = $request->safe()->except(['password_confirmation', 'site_plan']);
            $data['undertaking']         = (bool) ($request->boolean('undertaking'));

            if ($request->registration_levy_paid) {
                $data['registration_levy_paid']  = "true";
            }
            
           
            // Save site plan path
            $data['site_plan_path'] = $sitePlanPath;
            $data['payment_receipt'] = $receiptPlanPath;
            

            // Create record
            $application = CddwUser::create($data);

            

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage(), data: [], statusCode: 401);
        }

            return (new Helpers())->successResponse(message: "Registered successfully!", data: ["user" => $application], );

    }

    public function login(LoginRequest $request)
    {
        $data = $request->validated();

        try {
            $user = CddwUser::where('email', $request->email)->first();
            if(!$user) {
                throw new Exception("Invalid credentials provided");
            } elseif(!Hash::check($request->password, $user->password)) {
                throw new Exception("Invalid credentials provided");
            } 
        
            $token = $user->createToken('Cddw')->plainTextToken;

          
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage(), data: [], statusCode: 401);
        }

            return (new Helpers())->successResponse(message: "Login", data: ["user" => $user, "token" => $token], );

    }

    public function saveBase64Image($base64String, $folder = 'uploads')
    {
        // Extract base64 data
        if (preg_match('/data:image\/(\w+);base64,/', $base64String, $match)) {
            $extension = $match[1]; // jpg, png, gif etc.
            $base64String = substr($base64String, strpos($base64String, ',') + 1);
        } else {
            $extension = 'png';
        }

        // Decode base64
        $imageData = base64_decode($base64String);

        if ($imageData === false) {
            return null; // invalid base64
        }

        $filename = $folder . '/' . uniqid() . '.' . $extension;


        Storage::disk('public')->put($filename, $imageData);

        return Storage::url($filename);
    }

    public function updateProfile(Request $request)
    {

        try{
            $request->validate([
                'name' => 'sometimes|string|max:255',
                'phone' => 'sometimes|string|max:20',
                'organization' => 'sometimes|string',
            ]);
    
           
    
            $user = CddwUser::find(auth()->user()->id);
            $user->name = $request->name;
            $user->phone = $request->phone;
            $user->project_title = $request->organization;
          
            $user->save();

           
            return (new Helpers())->successResponse(message: "user updated successfully", data: [$user]);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }
    }

}
