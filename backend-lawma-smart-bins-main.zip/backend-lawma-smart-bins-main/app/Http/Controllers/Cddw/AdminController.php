<?php

namespace App\Http\Controllers\Cddw;

use App\Enums\Status;
use App\Http\Controllers\Controller;
use App\Http\Requests\Merchant\Auth\LoginRequest;
use App\Http\Resources\Merchant\UserResource;
use App\Models\ActivityLog;
use App\Models\CddwUser;
use Illuminate\Support\Facades\Storage;
use App\Models\CddwActivityLogs;
use App\Models\CddwAdmin;
use App\Models\CddwRegisteration;
use App\Models\CddwTransaction;
use App\Models\User;
use App\Services\Merchant\User\UserService;
use App\Utilities\Helpers;
use Auth;
use Hash;
use Illuminate\Http\Request;
use Exception;
use Illuminate\Support\Carbon;

class AdminController extends Controller
{

    public function login(LoginRequest $request)
    {
        $data = $request->validated();
        try {
            $user = CddwAdmin::with("roles.permissions")->where('email', $request->email)->first();
            if(!$user) {
                throw new Exception("Invalid credentials provided");
            } elseif(!Hash::check($request->password, $user->password)) {
                throw new Exception("Invalid credentials provided");
            } 
            // elseif($user->status !== Status::ACTIVE_NUMERIC) {
            //     throw new Exception("Your account has been blocked, kindly contact support");
            // }
 
            $user->last_login = Carbon::now();
            $user->login_count = $user->login_count + 1;
            $user->save();


            $token = $user->createToken('Cddw')->plainTextToken;
           // $userData = new UserResource($user);

          
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage(), data: [], statusCode: 401);
        }

            return (new Helpers())->successResponse(message: "Login", data: ["user" => $user, "token" => $token], );

    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return (new Helpers())->successResponse(message: "Logged out successfully");
    }

    public function dashboard()
    {
        try{

            $cddw = CddwRegisteration::count();
                
            $currentMonth = Carbon::now()->month;
            $currentYear = Carbon::now()->year;

            $cddwmonth = CddwRegisteration::whereMonth('created_at', $currentMonth)
                                    ->whereYear('created_at', $currentYear)
                         ->count();

            $transaction = CddwTransaction::sum('amount');

            // Split
            $lawma_share = $transaction * 0.25;
            $wastecare_share = $transaction * 0.75;

            $output = [
                "total_registration" => $cddw,
                "total_revenue" => $transaction,
                "lawma_share" => $lawma_share,
                "wastecare_share" => $wastecare_share,
                "new_registration" => $cddwmonth,
                "total_collection" => $transaction,
            ];

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage(), data: [], statusCode: 401);
        }

            return (new Helpers())->successResponse(message: "Dashboard", data: ["data" => $output], );


    }

    public function transactions()
    {
        try{
            $trx = CddwTransaction::all();

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }

            return (new Helpers())->successResponse( "transactions", data: ["data" => $trx], );

    }

    public function registerations()
    {
        try{
            $reg = CddwRegisteration::with('users')->get();

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }

            return (new Helpers())->successResponse( "registerations", data: ["data" => $reg], );

    }


    public function applicants()
    {
        try{
            $reg = CddwUser::all();

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }

            return (new Helpers())->successResponse( "applicants", data: ["data" => $reg], );

    }

    public function editAdminUser(Request $request)
    {

        try{
            $request->validate([
                'id' => 'required|integer|exists:cddw_admins,id',
                'name' => 'sometimes|string|max:255',
                'email' => 'sometimes|email|unique:cddw_admins,email,' . $request->id,
                'phone' => 'sometimes|string|max:20',
                'role_id' => 'sometimes|integer|exists:cddw_roles,id',
            ]);
    
            $admin = CddwAdmin::find($request->id);
            if (!$admin) {
                return (new Helpers())->errorResponse('Admin user not found', data: [], statusCode: 404);
            }
    
            $admin->fill($request->only(['name', 'email', 'phone', 'role_id']));
            $admin->save();

            $admin->roles()->syncWithoutDetaching([$request->role_id]);


            $resource = CddwAdmin::class;

            CddwActivityLogs::log($request, auth()->user()->id, $resource, json_encode($request->all()), null, "Edited Admin User ", sprintf('Edited Admin user'));
    
            return (new Helpers())->successResponse(message: "Admin user updated successfully", data: [$admin]);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }
    }

    public function deleteAdminUser(Request $request, int $id)
    {
        try{

                $admin = CddwAdmin::find($id);

                if (!$admin) {
                    return (new Helpers())->errorResponse('Admin user not found', data: [], statusCode: 404);
                }

                if ($request->user()->id === $admin->id) {
                    return (new Helpers())->errorResponse('You cannot delete your own account', data: [], statusCode: 403);
                }

                $admin->delete();
                $resource = CddwAdmin::class;
                CddwActivityLogs::log($request, auth()->user()->id, $resource, json_encode($request->all()), null, "Deleted Admin User ", sprintf('Deleted Admin user'));
    
                return (new Helpers())->successResponse(message: "Admin user deleted successfully", data: ["data" => []]);

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }
    }

    public function allActivityLogs(Request $request)
    {
        try{
            $activities = CddwActivityLogs::with('user')->orderBy('created_at', 'desc')->get();
            return $this->helper()->successResponse(message: "Activities fetch successful", data: [$activities]);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }
    }

    public function changePassword(Request $request)
    {
        try{
            $request->validate([
                'current_password' => 'required|string',
                'new_password' => 'required|string|min:8|confirmed',
            ]);

            $user = CddwAdmin::find(auth()->user()->id);

            if (!Hash::check($request->current_password, $user->password)) {
                return (new Helpers())->errorResponse('Current password is incorrect', data: [], statusCode: 400);
            }

            if (Hash::check($request->new_password, $user->password)) {
                return (new Helpers())->errorResponse('New password cannot be the same as the current password', data: [], statusCode: 400);
            }

            $user->password = $request->new_password;
            $user->save();
            
            $resource = CddwAdmin::class;
            CddwActivityLogs::log($request, auth()->user()->id, $resource, json_encode($request->all()), null, "Changed Password", sprintf('Changed Password'));
    
            return (new Helpers())->successResponse(message: "Password changed successfully", data: ["data" => $user]);

           
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage(), data: [], statusCode: 401);
        }
    }

    public function export(Request $request)
    {
        $type = $request->query('type', 'csv'); // default to CSV

       
        $reports = CddwTransaction::latest()->get();
    
        if ($type === 'csv') {
            return $this->exportCsv($reports);
        }
        
        return $this->exportCsv($reports);
     
    }

    public function exportCsv($reports)
    {
            $fileName = 'ccdw_transaction_' . now()->format('Y_m_d_His') . '.csv';
      
            $handle = fopen('php://temp', 'r+');

            fputcsv($handle, ['Reference ID', 'Sender Name', 'Amount', 'Date of Payment']);
             

            foreach ($reports as $report) {

                    fputcsv($handle, [
                        $report->provider_reference,
                        $report->sender_name,
                        $report->amount,
                        $report->created_at->toDateString(),
                    ]);

                }
                

            rewind($handle);

            // Read the CSV content into a string
            $csvData = stream_get_contents($handle);
            fclose($handle);

            // Save to Laravel storage (storage/app/)
            Storage::put($fileName, $csvData);
            

            return response()->download(Storage::path($fileName), $fileName)->deleteFileAfterSend(true);
    }


}
