<?php

namespace App\Http\Controllers\Cddw;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UserRequest;
use App\Mail\CddwAdminNotification;
use App\Models\ActivityLog;
use App\Models\CddwActivityLogs;
use App\Models\CddwAdmin;
use App\Models\CddwPermission;
use App\Models\User;
use App\Models\CddwRole;
use App\Utilities\Helpers;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Mail;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class RoleController extends Controller
{
    public function update(Request $request, User $user)
    {
        $request->validate([
            'role_id' => 'required|string|exists:roles,id',
        ]);
       
         $role = Role::findOrFail($request->input('role_id'));
         
         $user->syncRoles([$role->name]);

         $resource = Role::class;
         CddwActivityLogs::log($request, auth()->user()->id, $resource, json_encode($request->all()), null, "Updated User Role ", sprintf('Updated user role'));
         return $this->helper()->successResponse(message: "User role updated successfully.", data: [ 'user' => $user->only(['id', 'name', 'email']),
         'role' => $user->getRoleNames()->first()]);
      
    }


    public function roleMgt()
    {
        $roles = CddwRole::with('permissions')->get();
        return $this->helper()->successResponse(message: "Roles", data: [$roles]);
    }

    public function permissionMgt()
    {
        $roles = CddwPermission::get();
        return $this->helper()->successResponse(message: "Permissions", data: [$roles]);
    }

    public function addRole(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|unique:cddw_roles,name',
            'description' => 'nullable|string',
            'permissions' => 'required|array',
            'permissions.*' => 'exists:cddw_permissions,id',
        ]);

        $role = CddwRole::create($data);

        $role->permissions()->sync($request->permissions);

        return $this->helper()->successResponse(message: "Roles", data: [$role]);
    }


   
    public function addAdmin(Request $request)
    {
        $data = $request->validate([
            'fullname' => 'required|string',
            'email' => 'required|email|unique:cddw_admins,email',
            'role_id' => 'required|numeric',
        ]);
        try {
            $role = CddwRole::find($request->role_id);
            if (!$role) {
                throw new \Exception("Invalid role");
            }

            $password = (new Helpers())->randomNumbers();

            $user = new CddwAdmin();
            $user->name = $data["fullname"];
            $user->email = $data["email"];
            $user->password = $password;
            $user->save();
            
            $user->roles()->syncWithoutDetaching([$data['role_id']]);


        $notify = [
            "name" => strtoupper($user->name),
            "email" => $user->email,
            "password" => $password,
        ];

       
        Mail::to($user->email)->send(new CddwAdminNotification($notify));
        
    
    } catch (\Exception $exception) {
        return (new Helpers())->errorResponse($exception->getMessage());
    }
        $resource = CddwAdmin::class;
        CddwActivityLogs::log($request, auth()->user()->id, $resource, json_encode($request->all()), null, "Added Admin User ", sprintf('Added Admin user'));
    
        return $this->helper()->successResponse("Admin created successful", data: [$user]);
    }

    public function getAdmin(Request $request)
    {
        try {
                $users = CddwAdmin::all();
        
                foreach($users as $user){
                    $user->role_name = $user->getRoleNames()->first();
                }
               
               
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }

        return $this->helper()->successResponse(message: "Admin fetch successful", data: [$users]);
    }
}
 