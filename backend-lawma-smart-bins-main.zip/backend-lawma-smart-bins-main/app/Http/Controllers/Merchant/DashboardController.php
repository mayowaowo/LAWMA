<?php

namespace App\Http\Controllers\Merchant;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Resources\Merchant\UserResource;


class DashboardController extends Controller
{
    
    /**
     * Dashboard
     * 
     * @param Request
     * @return JsonResponse
     */
    public function dashboard(Request $request): JsonResponse
    {
        $user = Auth::user();
        return $this->helper()->successResponse(message: "Dashboard fetch successfully", data: [$user]);
    }
}
