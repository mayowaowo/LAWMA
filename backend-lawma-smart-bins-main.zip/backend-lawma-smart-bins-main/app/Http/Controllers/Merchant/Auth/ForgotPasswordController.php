<?php

namespace App\Http\Controllers\Merchant\Auth;

use Exception;
use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Services\Merchant\User\UserService;
use App\Http\Resources\Merchant\UserResource;
use App\Http\Requests\Merchant\Auth\ForgotPasswordRequest;
use App\Http\Requests\Merchant\Auth\EmailAuthenticationRequest;

class ForgotPasswordController extends Controller
{
    /**
     * Forgot password 
     * 
     * @param Request
     * @return JsonResponse
     * @throws Exception
     */
    public function forgotPassword(ForgotPasswordRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $user = (new UserService($data))->emailExists();
            (new UserService([], $user))->emailVerification("Resend", $user);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage(), data: [], statusCode: 401);
        }
        $userData = new UserResource($user);
        return (new Helpers())->successResponse(message: "OTP sent successfully", data: [$userData]);
    }

    /**
     * Resend OTP
     * 
     * @param Request
     * @return JsonResponse
     * @throws Exception
     */
    public function resendOtp(Request $request): JsonResponse
    {
        try {
            $user = (new UserService(["uuid" => $request->route('uuid')]))->fetchUserByUUID();
            (new UserService([], $user))->emailVerification("Resend", $user);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $userData = new UserResource($user);
        return (new Helpers())->successResponse(data: [$userData], message: "Email sent successfully!");
    }

    /**
     * Email Authentication & Change Password
     * 
     * @return JsonResponse
     * @throws Exception
     */
    public function emailAuthentication(EmailAuthenticationRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            (new UserService($data))->forgotPasswordValidateOtp();
            $user = (new UserService($data))->updateUser();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $userData = new UserResource($user);
        return (new Helpers())->successResponse(data: [$userData], message: "Your password has been changed successfully!");
    }
}
