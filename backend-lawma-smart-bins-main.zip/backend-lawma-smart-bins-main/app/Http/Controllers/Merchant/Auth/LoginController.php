<?php

namespace App\Http\Controllers\Merchant\Auth;

use Exception;
use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Services\Merchant\User\UserService;
use App\Http\Resources\Merchant\UserResource;
use App\Http\Requests\Merchant\Auth\LoginRequest;

class LoginController extends Controller
{
    /**
     * Login
     * 
     * @param Request
     * @return JsonResponse
     * @throws Exception
     */
    public function login(LoginRequest $request): JsonResponse
    {
        $data = $request->validated();
        $response = (new UserService($data))->pendingOnboardingProcess(); /** Checks for pending onboarding process to be continued */
        if($response["status"] === true) {
            $userData = new UserResource($response["data"]);
            return (new Helpers())->successResponse(data: [$userData], message: $response["message"]);
        }
        try {
            $user = (new UserService($data))->loginUser();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse( $exception->getMessage());
        }
        $userData = new UserResource($user);
        $token = $user->createToken('Smart')->plainTextToken;
        return (new Helpers())->successResponse(message: "Logged in successfully", data: ["user" => $userData, "token" => $token], );
    }
}
