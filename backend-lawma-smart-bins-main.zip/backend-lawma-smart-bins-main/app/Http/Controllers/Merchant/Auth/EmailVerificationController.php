<?php

namespace App\Http\Controllers\Merchant\Auth;

use Exception;
use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Services\Merchant\User\UserService;
use App\Http\Resources\Merchant\UserResource;
use App\Http\Requests\Merchant\Auth\EmailVerificationRequest;


class EmailVerificationController extends Controller
{

    /**
     * Email Verification
     * 
     * @return JsonResponse
     * @throws Exception
     */
    public function emailVerification(EmailVerificationRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            (new UserService($data))->validateOtp();
            $user = (new UserService($this->mergeData($data)))->updateUser();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $userData = new UserResource($user);
        return (new Helpers())->successResponse(data: [$userData], message: "High Five - Your email verification was successful!");
    }

    /**
     * Resend OTP
     * 
     * @param Request
     * @return JsonResponse
     * @throws Exception
     */
    public function resendOtp(Request $request): JsonResponse
    {
        try {
            $user = (new UserService(["uuid" => $request->route('uuid')]))->fetchUserByUUID();
            (new UserService([], $user))->emailVerification("Resend", $user);
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $userData = new UserResource($user);
        return (new Helpers())->successResponse(data: [$userData], message: "Email sent successfully!");
    }

    /**
     * Merge data
     * 
     * @param array $arrayData
     * @return array
     */
    private function mergeData(array $arrayData): array
    {
        $mergeData = ["email_verified_at" => Carbon::now()];
        foreach ($mergeData as $key => $value) {
            $arrayData[$key] = $value;
        }
        return $arrayData;
    }
}
