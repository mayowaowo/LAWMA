<?php

namespace App\Http\Controllers\Merchant\Auth;

use Exception;
use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use App\Http\Resources\Merchant\UserResource;
use App\Services\Merchant\User\UserService;
use App\Http\Requests\Merchant\Auth\RegisterRequest;


class RegisterController extends Controller
{
    
    /**
     * Registration
     * 
     * @param Request
     * @return JsonResponse
     */
    public function register(RegisterRequest $request): JsonResponse
    {
        $data = $request->validated();
        $response = (new UserService($data))->pendingOnboardingProcess(); /** Checks for pending onboarding process to be continued */
        if($response["status"] === true) {
            $userData = new UserResource($response["data"]);
            return (new Helpers())->successResponse(data: [$userData], message: $response["message"]);
        }
        try {
            $user = (new UserService($data))->initiateUserCreation();

        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        $userData = new UserResource($user);
        return (new Helpers())->successResponse(data: [$userData], message: "High Five - You have successfully signed up!");
    }
}
