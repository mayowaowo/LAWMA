<?php

namespace App\Http\Controllers\Merchant\Auth;

use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;

class LogoutController extends Controller
{
    /**
     * Logout
     * 
     * @param Request
     * @return JsonResponse
     */
    public function logout(Request $request): JsonResponse
    {
        $request->user()->tokens()->delete();
        return (new Helpers())->successResponse(message: "Logged out successfully");
    }
}
