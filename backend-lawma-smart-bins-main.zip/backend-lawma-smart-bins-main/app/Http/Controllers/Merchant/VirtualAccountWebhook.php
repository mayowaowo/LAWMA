<?php

namespace App\Http\Controllers\Merchant;

use App\Enums\Profile;
use App\Models\Bin;
use App\Models\CddwTransaction;
use App\Models\Referral;
use App\Models\User;
use App\Enums\Status;
use App\Models\Order;
use App\Enums\PaymentType;
use App\Utilities\Helpers;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Models\CommissionHistory;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use App\Mail\TransactionNotification;
use App\Mail\TrackerRepaymentNotification;
use App\Mail\TrackerTransactionNotification;
use App\Mail\RepaymentTransactionNotification;

class VirtualAccountWebhook extends Controller
{
    const EVENT_STATUS = "collection.virtualaccount.successful";
    protected Order $orderData;
    protected Transaction|null $transactionData;
    protected mixed $webhook;
    protected bool $repaymentStatus;


    /**
     * Process Sarepay Virtual
     * Account Webhook
     * 
     * @param Request $request
     * @return JsonResponse
     */
    public function handleVirtualAccountWebhook(Request $request): JsonResponse
    {
        $this->webhook = $request->all();
        Log::warning($this->webhook);
        if( $this->isPayloadValid() ) $this->handleWebhook();
        return response()->json(['status' => 'success'], 200);
    }

    /**
     * Checks if the received webhook 
     * is valid by comparing the HMAC hash
     * @return bool
     */
    private function isPayloadValid(): bool 
    {
        $data = json_encode($this->webhook['data']);
        $key = config('payment.sarepay_secret_key');
        $received_hmac = base64_decode($this->webhook['hash']);
        $calculated_hmac = hash_hmac('sha256', $data, $key, true);
        return hash_equals($calculated_hmac, $received_hmac);
    }

    /**
     * Execute the job.
     */
    public function handleWebhook(): void
    {
        Log::info($this->webhook);
        $this->transactionData = Transaction::where('reference', $this->webhook['data']['customer_reference'])->first();
        if($this->transactionData) {
            $this->incomingEventChecks();
        }

        if ($this->webhook['data']['recipient'] == '9391322312'){
            $this->ccdwIncomingEventChecks();
        }
    }

    /**
     * Incoming event checks
     */
    protected function incomingEventChecks()
    {
        return match ($this->webhook['event']) {
            self::EVENT_STATUS => $this->processRequest(),
            default => $this->unhandledEvent()
        };
    }

     /**
     * Incoming event checks
     */
    protected function ccdwIncomingEventChecks()
    {
        return match ($this->webhook['event']) {
            self::EVENT_STATUS => $this->processCcdwRequest(),
            default => $this->unhandledEvent()
        };
    }


    /**
     * Process Request
     * @return void
     */
    protected function processCcdwRequest(): void
    {
        Log::info($this->webhook['data']);
        /**
         * Checks if transaction already been processed
         * and account already funded
         */
        $transaction = CddwTransaction::where('provider_reference', $this->webhook['data']['transaction_reference'])->exists();
        if($transaction) return;

        $transaction = new CddwTransaction();
        $transaction->sender_name = $this->webhook['data']['sender']['originatorName'];
        $transaction->status = Status::SUCCESSFUL;
        $transaction->provider_status = Status::SUCCESSFUL;
        $transaction->provider_reference = $this->webhook['data']['transaction_reference'];
        $transaction->meta = json_encode($this->webhook);
        $transaction->account_number = null;
        $transaction->amount = $this->webhook['data']['amount'];
        $transaction->save();
    }

    /**
     * Process Request
     * @return void
     */
    protected function processRequest(): void
    {
        Log::info($this->webhook['data']);
        /**
         * Checks if transaction already been processed
         * and account already funded
         */
        $transaction = Transaction::where('provider_reference', $this->webhook['data']['transaction_reference'])->exists();
        if($transaction) return;


        $this->orderData = Order::where('order_reference', $this->transactionData->order_reference)->first();

        $binData = json_decode($this->orderData->bin_purchase, true);
        
        foreach ($binData as $item) {
            $bin = Bin::where("name", $item['category'])->first();
            $bin->stock = $bin->stock - $item['quantity'];
            $bin->save();
        }

        if($this->orderData->payment_type === PaymentType::ONEOFF) $this->one_off_payment_update();
        else $this->validateInstallment();
    }

    /**
     * Update transaction
     * 
     * @return void
     */
    protected function updateTransaction(): void
    {
        $this->transactionData->status = Status::SUCCESSFUL;
        $this->transactionData->provider_status = Status::SUCCESSFUL;
        $this->transactionData->provider_reference = $this->webhook['data']['transaction_reference'];
        $this->transactionData->meta = json_encode($this->webhook);
        $this->transactionData->account_number = null;
        $this->transactionData->save();
    }


    //   /**
    //  * Create Installment Verification
    //  * 
    //  * @return void
    //  */
    public function createCommissionHistory():void
    {

        $user = User::find($this->orderData->user_id);
        if ($user->type == Profile::USER){

           
            $refer = Referral::where("user_id", $user->id)->first();
               
            if ($refer){
                $commissionHistory = new CommissionHistory();
                $commissionHistory->user_id = $refer->referral_id;
                $commissionHistory->order_id = $this->orderData->id;
    
                $items = json_decode($this->orderData->bin_purchase, true); 
                $secDetails = is_string($items) ? json_decode($items, true) : $items;
    
                $totalQuantity = 0;
                if (is_array($secDetails)) {
                    foreach ($secDetails as $item) {
                        $totalQuantity += $item['quantity'] ?? 0;
                    }
                }
    
                $commission = $totalQuantity * 3000;
                $commissionHistory->commission = $commission;
                $commissionHistory->status = Status::PENDING;
                $commissionHistory->save();
            }

          
        }
    }

    /**
     * One-off payment update
     * 
     * @return void
     */
    protected function one_off_payment_update(): void
    {
        $this->updateTransaction();
        $this->createCommissionHistory();
        $this->orderData->status = Status::SUCCESSFUL;
        $this->orderData->payment_status = Status::COMPLETED;
        $this->orderData->account_number = null;
        $this->orderData->save();
        $this->repaymentStatus = false;
        $this->sendNotification();
    }

    /**
     * Installment update
     * 
     * @return void
     */
    protected function validateInstallment(): void
    {
        $payment_remitted = Transaction::where('order_reference', $this->orderData->order_reference)->sum('amount');
        if($payment_remitted >= $this->orderData->total_amount ) $this->installmentPaymentCompleted();
        else $this->repayment();
    }

    /**
     * Installment update
     * 
     * @return void
     */
    protected function installmentPaymentCompleted(): void
    {
        $this->updateTransaction();
        $this->createCommissionHistory();
        $this->orderData->payment_status = Status::COMPLETED;
        $this->orderData->status = Status::SUCCESSFUL;
        $this->orderData->remitted_amount = ($this->orderData->remitted_amount + $this->webhook['data']['amount']);
        $this->orderData->account_number = null;
        $this->orderData->save();
        $this->repaymentStatus = false;
        $this->sendNotification();
    }

    /**
     * Installment update
     * 
     * @return void
     */
    protected function repayment(): void
    {
        $this->updateTransaction();
        /** If amount remitted was in full payment */
        if($this->webhook['data']['amount'] >= $this->orderData->total_amount ) {
            $this->orderData->payment_status = Status::COMPLETED;
            $this->orderData->status = Status::SUCCESSFUL;
            $this->orderData->remitted_amount = ($this->orderData->remitted_amount + $this->webhook['data']['amount']);
            $this->orderData->account_number = null;
            $this->orderData->payment_time = Carbon::now();
            $this->orderData->save();
            $this->repaymentStatus = true;
            $this->sendNotification();
        } else {
            $this->orderData->remitted_amount = ($this->orderData->remitted_amount + $this->webhook['data']['amount']);
            $this->orderData->account_number = null;
            $this->orderData->status = Status::SUCCESSFUL;
            $this->orderData->payment_time = Carbon::now();
            $this->orderData->save();
            $this->repaymentStatus = true;
            $this->sendNotification();
        }
    }
    
    /**
     * Unhandle Event
     */
    protected function unhandledEvent(): void
    {
        Log::debug(sprintf("Unabled to process virtual account"));
    }

    /**
     * Send Notification
     * to Email
     * 
     * @return void
     */
    protected function sendNotification(): void
    {
        sleep(3);
        $user = User::where('id', $this->orderData->user_id)->first();
        $notify = [
            "name" => strtoupper($user->name),
            "orderReference" => $this->transactionData->order_reference,
            "transactionReference" => $this->transactionData->reference,
            "amount" => (new Helpers())->number_formatter($this->transactionData->amount),
            "narration" => $this->transactionData->narration,
            "status" => $this->transactionData->status,
            "transactionDate" => (new Helpers())->formatDate($this->transactionData->created_at)
        ];

        if( $this->repaymentStatus === true ) {
            Mail::to($user->email)->queue(new RepaymentTransactionNotification($notify));
            Mail::to(env('PRODUCT_EMAIL'))->queue(new TrackerRepaymentNotification($notify));
            Mail::to(env('FINANCE_EMAIL'))->queue(new TrackerRepaymentNotification($notify));
        } else {
            Mail::to($user->email)->queue(new TransactionNotification($notify));
            Mail::to(env('PRODUCT_EMAIL'))->queue(new TrackerTransactionNotification($notify));
            Mail::to(env('FINANCE_EMAIL'))->queue(new TrackerTransactionNotification($notify));
        }
    }
}
