<?php

namespace App\Http\Controllers\Merchant;

use Exception;
use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Merchant\OrderRequest;
use App\Services\Merchant\Order\OrderService;
use App\Http\Requests\Merchant\NextPaymentInstallmentRequest;


class OrderController extends Controller
{
    
    /**
     * Ordering
     * 
     * @param OrderRequest $request
     * @return JsonResponse
     */
    public function order(OrderRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $user = Auth::user();
            $order = (new OrderService($data, $user))->initiateOrder();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return (new Helpers())->successResponse(message: "Order processed successfully", data: [$order]);
    }

    /**
     * Fetch order history
     * 
     * @param Request $request
     * @return JsonResponse
     * @throws Exception
     */
    public function OrderHistory(Request $request): JsonResponse
    {
        try {
            $user = Auth::user();
            $orders = (new OrderService([], $user))->fetchOrderHistory();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return (new Helpers())->successResponse(message: "Orders history fetched successfully", data: [$orders]);
    }

    /**
     * Next Payment Installment
     * 
     * @param NextPaymentInstallmentRequest $request
     * @return JsonResponse
     * @throws Exception
     */
    public function nextPaymentInstallment(NextPaymentInstallmentRequest $request): JsonResponse
    {
        $data = $request->validated();
        try {
            $user = Auth::user();
            $orders = (new OrderService($data, $user))->initiateNextPayment();
        } catch (Exception $exception) {
            return (new Helpers())->errorResponse(message: $exception->getMessage());
        }
        return (new Helpers())->successResponse(message: "Next payment initiated successfully", data: [$orders]);
    }
}
