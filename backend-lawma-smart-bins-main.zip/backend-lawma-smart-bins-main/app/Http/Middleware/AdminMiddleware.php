<?php

namespace App\Http\Middleware;

use App\Enums\Profile;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        $type = Profile::ADMIN;

        if (!$user || $user->type !== $type) {
            abort(response()->json([
                'message' => 'Permission Denied.'
            ], 401));
        }

        return $next($request);
    }
}
