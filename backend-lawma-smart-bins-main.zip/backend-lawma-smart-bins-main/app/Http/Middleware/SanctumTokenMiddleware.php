<?php

namespace App\Http\Middleware;

use Closure;
use App\Utilities\Helpers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class SanctumTokenMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $token = $request->bearerToken();
        if (!$token) {
            return (new Helpers())->errorResponse(message: "Unauthorized, access token not provided.", data: [], statusCode: 401);
        }
        if (!Auth::guard('sanctum')->check()) {
            $user = $request->user(); // This triggers sanctum's token parsing
            if(!$user) {
                return (new Helpers())->errorResponse(message: "Your login session has expired...", data: [], statusCode: 401);
            }
        }
        return $next($request);
    }
}
