<?php

namespace App\Http\Middleware;


use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class PapertrailMiddleware
{
    protected $startTime;

    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $this->startTime = microtime(true);
        return $next($request);
    }

    /**
     * @param Request $request
     * @param $response
     * @return void
     */
    public function terminate(Request $request, $response)
    {
        $data = $request->all();
        $data = $this->stripSensitiveData($data);
        $endTime = microtime(true);
        $dataToLog  = 'Service: Ramp Collection-Service' . "\n";
        $dataToLog .= 'Time: '   . gmdate("F j, Y, g:i a") . "\n";
        $dataToLog .= 'Duration: ' . number_format($endTime - LARAVEL_START, 3) . "\n";
        $dataToLog .= 'IP Address: ' . $request->header('X-Real-IP') . "\n";
        $dataToLog .= 'URL: '    . $request->path() . "\n";
        $dataToLog .= 'Method: ' . $request->method() . "\n";
        $dataToLog .= 'Status: '    . $response->status() . "\n";
        $dataToLog .= 'Input: '  . json_encode($data) . "\n" ;
        $dataToLog .= 'Output: ' . $response->getContent() . "\n";

        $this->sendLogs($dataToLog);

        if ($response->status() >= 200 && $response->status() <= 299 ){
            Log::info($dataToLog);
        }elseif ($response->status() >= 400 && $response->status() <= 499){
            Log::warning($dataToLog);
        }else{
            Log::error($dataToLog);
        }
    }

    private function stripSensitiveData(array $data)
    {
        if(isset($data['pin'])) unset($data['pin']);
        if(isset($data['otp'])) unset($data['otp']);
        if(isset($data['card'])) unset($data['card']);
        if(isset($data['card_data'])) unset($data['card_data']);
        if(isset($data['encryption_key'])) unset($data['encryption_key']);
        if(isset($data['secret_key'])) unset($data['secret_key']);
        if(isset($data['public_key'])) unset($data['public_key']);
        if(isset($data['merchant'])) unset($data['merchant']);
        return $data;
    }

    private function sendLogs($payload)
    {
        $url = config('api.custom_logger_url');
        $headers = [
            "Content-Type: application/octet-stream",
            "Authorization: Bearer ".config('api.custom_logger_auth')
        ];
    
        $ch = curl_init($url);
    
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
        $response = curl_exec($ch);
        curl_close($ch);
    }
    
}
