<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ApplicationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name'                   => ['required', 'string', 'max:255'],
            'rc_number'              => ['nullable', 'string', 'unique:cddw_users,rc_number', 'max:100'],
            'address'                => ['nullable', 'string', 'max:500'],
            'contact_person_name'    => ['required', 'string', 'max:255'],
            'contact_person_title'   => ['nullable', 'string', 'max:255'],
            'phone'                  => ['nullable', 'string', 'unique:cddw_users,phone', 'max:30'],
            'email'                  => ['nullable', 'email', 'unique:cddw_users,email', 'max:255'],
            'password'               => ['required', 'string', 'min:8', 'confirmed'], // requires password_confirmation
            'project_title'          => ['required', 'string', 'max:255'],
            'project_type'           => ['nullable', 'string', 'max:255'],
            'project_address'        => ['nullable', 'string', 'max:500'],
            'planned_start_date'     => ['nullable', 'date'],
            'planned_end_date'       => ['nullable', 'date', 'after_or_equal:planned_start_date'],
            'hazardous_materials'        => ['nullable', 'string'],
            'site_plan'              => ['nullable', 'string'], 
            'undertaking'            => ['required', 'boolean'],
            'signature'              => ['nullable', 'string'],
            'registration_levy_paid'     => ['required', 'boolean'],
            'registration_levy_amount'     => ['required', 'numeric'],
            // Registration & Site Info
            'land_size'              => ['nullable', 'numeric', 'min:0'],
            'number_of_floors'       => ['nullable', 'integer', 'min:0'],
            'location_density'       => ['nullable', 'string'],
            'payment_receipt'        =>  ['required', 'string'],
            'bin_type'               => ['nullable', 'string', 'max:100'],
            'evacuation_trips'       => ['nullable', 'integer', 'min:0'],

        ];
    }
}
