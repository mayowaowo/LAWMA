<?php

namespace App\Http\Requests\Merchant;

use App\Enums\Category;
use App\Enums\PaymentType;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class OrderRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'color' => 'required|string',
            'bin_purchase' => 'required|array',
            'dispatch_address' => 'required|string',
            'dispatch_city' => 'required|string',
            'dispatch_postal' => 'required|string',
            'postal' => 'required|string',
            'save_dispatch_details' => 'required|boolean',
            'payment_type' => ['required', 'string', Rule::in(PaymentType::$types)],
            'receiver_name' => 'sometimes|string|nullable',
            'receiver_phone' => 'sometimes|string|nullable',
            'payment_period' => 'sometimes|string|nullable',
            "bvn" => "sometimes|nullable|numeric|digits:11",
            "nin" => "sometimes|nullable|numeric|digits:11"
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            response()->json([
                'status' => false,
                'message' => 'Validation errors occurred',
                'data' => [],
                'errors' => $validator->errors(),
            ], 422)
        );
    }
}
