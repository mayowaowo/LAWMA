<?php

namespace App\Http\Requests\Merchant\Auth;

use App\Enums\Profile;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Http\Exceptions\HttpResponseException;

class RegisterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'fullname' => 'required|string|max:50|regex:/^[A-Za-z\s]+$/',
            'email' => 'required|email|string|max:50',
            'phone' => 'required|string|max:13',
            'address' => 'required|string|max:250',
            'postal' => 'required|string|max:11',
            'city' => 'required|string',
            'type' => ['required', 'string', Rule::in(Profile::$types)],
            'referral' => 'sometimes',
            'password' => [
                'required',
                'confirmed',
                Password::min(8)
                    ->mixedCase()
                    ->numbers()
                    ->symbols()
            ]
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        throw new HttpResponseException(
            response()->json([
                'status' => false,
                'message' => 'Validation errors occurred',
                'data' => [],
                'errors' => $validator->errors(),
            ], 422)
        );
    }
}
