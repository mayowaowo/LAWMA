<?php

namespace App\Http\Requests\Cddw;

use Illuminate\Foundation\Http\FormRequest;

class RegisterRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
       
            return [
                // 'name' => 'required|string|max:255',
                // 'email' => 'required|email|max:255',
                // 'phone' => 'required|string|max:20',
                // 'region' => 'required|string|max:255',
                // 'company_address' => 'required|string|max:255',
                // 'site_address' => 'required|string|max:255',
                // 'company_phone' => 'required|string|max:20',
                // 'site_phone' => 'required|string|max:20',
                // 'site_description' => 'nullable|string|max:500',
                // 'payment_type' => 'required|string|max:100',
                'amount' => 'required|numeric|min:0',
                'collection_date' => 'required|date',
                'payment_receipt' => 'required|string'
            ];
        
    
    
    }
}
