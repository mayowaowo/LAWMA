<?php

namespace App\Http\Resources\Merchant;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class TransactionHistoryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            "transactionReference" => $this->reference,
            "amount" => $this->amount,
            "type" => $this->type,
            "transactionType" => $this->transaction_type,
            "narration" => $this->narration,
            "status" => $this->status,
            "createdAt" => $this->created_at
        ];
    }
}
