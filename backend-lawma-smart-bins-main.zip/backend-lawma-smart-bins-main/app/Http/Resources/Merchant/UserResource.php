<?php

namespace App\Http\Resources\Merchant;

use App\Enums\Status;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            "uuid" => $this->uuid,
            "name" => $this->name,
            "email" => $this->email,
            "phone" => $this->phone,
            "city" => $this->city,
            "postalCode" => $this->postal_code,
            "type" => $this->type,
            "emailVerification" => ( $this->email_verified_at ) ? true : false,
            "installmentVerificationStatus" =>  ( $this->installment_verification_status === Status::ACTIVE_NUMERIC ) ? true : false,
            "referalCode" => $this->referral_code,
            "savedDispatchDetails" => DispatchDetailsResource::collection($this->savedDispatchDetails) ?? [],
            "referrals" => ReferralsResource::collection($this->referrals) ?? [],
            "role" => $this->getRoleNames()->first(),
            "totalCommission" => $this->agentTotalCommission() ?? 0,
            "createdAt" => $this->created_at,
            "updatedAt" => $this->updated_at
        ];
    }
}
