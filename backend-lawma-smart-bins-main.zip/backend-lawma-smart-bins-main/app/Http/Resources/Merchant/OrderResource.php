<?php

namespace App\Http\Resources\Merchant;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Http\Resources\Merchant\TransactionHistoryResource;

class OrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            "id" => $this->id,
            "orderReference" => $this->order_reference,
            "binPurchaseItems" => json_decode($this->bin_purchase, true),
            "amount" => $this->amount,
            "expectedAmount" => $this->expected_amount,
            "totalAmount" => $this->total_amount,
            "paymentPeriod" => $this->payment_period,
            "paymentStatus" => $this->payment_status,
            "status" => $this->status,
            "createdAt" => $this->created_at,
            "transactionHistory" => TransactionHistoryResource::collection($this->transactions)
        ];
    }
}
