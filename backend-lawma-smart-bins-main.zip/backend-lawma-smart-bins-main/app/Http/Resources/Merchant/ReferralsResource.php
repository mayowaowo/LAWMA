<?php

namespace App\Http\Resources\Merchant;

use App\Models\User;
use App\Enums\Status;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class ReferralsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $userData = $this->userData($this->user_id);
        return [
            "uuid" => $userData->uuid,
            "user_name" => $userData->name,
            "status" => $this->status === Status::ACTIVE_NUMERIC
                ? strtoupper(Status::ACTIVE)
                : strtoupper(Status::IN_ACTIVE),
            "created_at" => $this->created_at?->toIso8601String(),
        ];
    }

    public function userData($userID): mixed
    {
        $user = User::where('id', $userID)->first();
        return $user;

    }
}
