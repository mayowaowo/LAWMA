<?php

namespace App\Http\Resources\Merchant;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class DispatchDetailsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $dispatchDetails = ( $this->dispatch_details ) ? json_decode($this->dispatch_details, true) : [];
        $receiverDetails = ( $this->receiver_details ) ? json_decode($this->receiver_details, true) : [];
        return [
            "id" => $this->id,
            "dispatchAddress" => ( isset($dispatchDetails["dispatch_address"]) && !empty($dispatchDetails["dispatch_address"]) ) ? $dispatchDetails["dispatch_address"] : null,
            "dispatchCity" => ( isset($dispatchDetails["dispatch_city"]) && !empty($dispatchDetails["dispatch_city"]) ) ? $dispatchDetails["dispatch_city"] : null,
            "dispatchPostal" => ( isset($dispatchDetails["dispatch_postal"]) && !empty($dispatchDetails["dispatch_postal"]) ) ? $dispatchDetails["dispatch_postal"] : null,
            "receiverName" => ( isset($receiverDetails["receiver_name"]) && !empty($receiverDetails["receiver_name"]) ) ? $receiverDetails["receiver_name"] : null,
            "receiverPhone" => ( isset($receiverDetails["receiver_phone"]) && !empty($receiverDetails["receiver_phone"]) ) ? $receiverDetails["receiver_phone"] : null,
        ];
    }
}
