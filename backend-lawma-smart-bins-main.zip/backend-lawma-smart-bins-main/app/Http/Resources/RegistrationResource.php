<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class RegistrationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
           "name" => $this->name,
           "id" => $this->id,
           "customer_ref" => $this->customer_reference,
            "email" => $this->email,
            "phone" => $this->phone,
            "reference" => $this->transaction_reference,
            "payment_type" => $this->payment_type,
            "amount" => $this->amount,
        ];
    }
}
