<?php

namespace App\Traits;

trait PaginationTrait
{
    /**
     * Pagination
     * 
     * @param mixed $paginate
     * @return mixed
     */
    
    public function paginate( mixed $paginate ): mixed
    {
        return [
            'total' => $paginate->total(),
            'per_page' => $paginate->perPage(),
            'current_page' => $paginate->currentPage(),
            'last_page' => $paginate->lastPage(),
            'next_page_url' => $paginate->nextPageUrl(),
            'prev_page_url' => $paginate->previousPageUrl(),
            'from' => $paginate->firstItem(),
            'to' => $paginate->lastItem(),
        ];
    }
}
