<?php

namespace App\Utilities;

use Illuminate\Support\Carbon;
use Illuminate\Http\JsonResponse;


class Helpers {

    /**
     * Error response
     *
     * @param array $data
     * @param string $code
     * @param string $message
     * @param int $statusCode
     * @return JsonResponse
     */
    public function errorResponse(
        string $message = "Action was not successful",
        int    $statusCode = 400,
        array  $data = []
    ): JsonResponse
    {
        $response = [
            'status' => false,
            'message' => $message,
            'data' => $data
        ];
        return response()->json($response, $statusCode);
    }

    /**
     * Success response
     *
     * @param array $data
     * @param string $code
     * @param string $message
     * @param int $statusCode
     * @return JsonResponse
     */

    public function successResponse(
        string $message = "Action was successful",
        int    $statusCode = 200,
        array  $data = [],
    ): JsonResponse
    {
        $response = [
            'status' => true,
            'message' => $message,
            'data' => $data
        ];
        return response()->json($response, $statusCode);
    }

    /**
     * Generate code
     * 
     * @return string
     */
    public function generateReferralCode(): string
    {
        return "LSB-".date("y").$this->randomNumbers(4);
    }

    /**
     * Generate random numbers
     * 
     * @param int $length
     * @return string
     */
    public function randomNumbers($length = 6): string
    {
        $str = "";
        $characters = array_merge(
            range('0', '9')
        );
        $max = count($characters) - 1;
        for ($i = 0; $i < $length; $i++) {
            $rand = random_int(0, $max);
            $str .= $characters[$rand];
        }
        return $str;
    }

    /**
     * Generate transaction /
     * Session Id
     * 
     * @return string
     */
    public function generateReference(): string
    {
        return "LSB_".Carbon::now()->format("ymdHms").$this->randomNumbers(8);
    }

    public function generateCustomerReference(): string
    {
        return "CUST_".Carbon::now()->format("ymdHms").$this->randomNumbers(8);
    }

    public function generateRegistrationReference(): string
    {
        return "LAW_".Carbon::now()->format("ymdHms").$this->randomNumbers(8);
    }

    /**
     * Generate order ID
     * 
     * @return string
     */
    public function generateOrderId(): string
    {
        return "ORD_".Carbon::now()->format("ymdHms").$this->randomNumbers(4);
    }

    /**
     * Format number
     * 
     * @param mixed $value
     * @return string
     */
    public function number_formatter(mixed $amount): string {
        return number_format((float)$amount, 2, '.', ',');
    }

    /**
     * Format the date and time
     * in the desired format
     * 
     * @param mixed $dateString
     * @return mixed
     */
    public function formatDate(mixed $dateString): mixed
    {
        $carbonDate = Carbon::createFromFormat('Y-m-d H:i:s', $dateString);
        $dateFormat = $carbonDate->format('d-m-Y H:i');
        return $dateFormat;
    }

}