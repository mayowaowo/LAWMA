<?php

return [
    'logger_url' => env('PAPERTRAIL_ENDPOINT'),
    'logger_auth' => env('PAPERTRAIL_TOKEN')
];