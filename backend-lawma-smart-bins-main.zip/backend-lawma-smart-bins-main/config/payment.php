<?php

return [
    'sarepay_base_url' => env('SAREPAY_BASE_URL'),
    'sarepay_secret_key' => env('SAREPAY_SECRET_KEY'),
    /** Dojah */
    'dojah_base_url' => env('DOJAH_BASE_URL'),
    'dojah_secret_key' => env('DOJAH_SECRET_KEY'),
    'dojah_app_id' => env('DOJAH_APP_ID'),
    'dojah_test_bvn' => env('DOJAH_TEST_BVN'),
    'dojah_test_nin' => env('DOJAH_TEST_NIN'),
    'lawma_smart_bin_frontend_base_url' => env('LAWMA_SMART_BIN_FRONTEND_BASE_URL')
];
