<x-mail::message>
{{ __('Dear') }}  <b>{{ $name }},</b>
 
The details of this transaction are shown below:



Transaction Notification

Order ID	        :	{{ $orderReference }}

Status	        :	{{ $status }}

Description	:	{{ $narration }}

Amount	                :	NGN {{ $amount }}

Transaction Reference	            :	{{ $transactionReference }}

Time of Transaction	    :	{{ $transactionDate }}





For your security, if this request did not originate from you please let us know by sending an email to {{ env('MAIL_ADMIN') }}


Thank You for choosing {{ config('app.name') }}

</x-mail::message>