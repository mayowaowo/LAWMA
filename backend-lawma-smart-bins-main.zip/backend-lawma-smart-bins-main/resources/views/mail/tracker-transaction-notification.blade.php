<x-mail::message>
{{ __('Dear') }}  <b>Team,</b>

{{ $name }} just made a payment of ₦ {{ $amount }}

</x-mail::message>