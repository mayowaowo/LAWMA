<x-mail::message>
<b>{{ __('Hello') }} {{ $name }},</b>

Please use the OTP code below : <h3 style="text-align: center;background: #FAFAFA; padding: 10px">{{ $otp }}</h3>

If you have any questions visit our Website or send an email to service@lawmasmartbins.com

Cheers,<br>
{{ config('app.name') }} Team.
</x-mail::message>