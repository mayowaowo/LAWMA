<x-mail::message>
<b>{{ __('Hello') }} {{ $name }},</b>

Kindly copy verification code below to complete onboarding process with Lawma Smart Bins.
<h3 style="text-align: center;background: #FAFAFA; padding: 10px">{{ $otp }}</h3>

Please ignore this email if you didn’t create an account.
If you have any questions visit our Website or send an email to service@lawmasmartbins.com

Thank You,<br>
{{ config('app.name') }}.
</x-mail::message>