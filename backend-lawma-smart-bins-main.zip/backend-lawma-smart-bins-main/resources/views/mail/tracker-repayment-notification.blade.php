<x-mail::message>
{{ __('Dear') }}  <b>Team,</b>

{{ $name }} just made a repayment of ₦ {{ $amount }}

</x-mail::message>