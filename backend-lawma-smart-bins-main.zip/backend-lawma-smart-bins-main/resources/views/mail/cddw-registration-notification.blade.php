<x-mail::message>
{{ __('Dear') }}  <b>{{ $name }},</b>
 
The details of this transaction are shown below:


Transaction Notification

Reference ID	        :	{{ $referenceID }}

Customer ID	        :	{{ $customerID }}

Payer Name      : {{ $payerName }}

Amount Paid     : NGN {{ $amount }}

Payment Type    :  {{ $paymentType }}

Effective Date  : {{ $effectiveDate }}

Region      : {{ $region }}

Status	        :	{{ $status }}

Site Address	:	{{ $siteAddress }}

Transaction Reference	            :	{{ $transactionReference }}

Time of Transaction	    :	{{ $transactionDate }}



For your security, if this request did not originate from you please let us know by sending an email to {{ env('MAIL_ADMIN') }}


Thank You for choosing {{ config('app.name') }}

</x-mail::message>