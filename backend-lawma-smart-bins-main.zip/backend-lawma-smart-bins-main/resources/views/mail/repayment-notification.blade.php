<x-mail::message>
{{ __('Dear') }} <strong>{{ $name }}</strong>,

We noticed that your payment is due. Kindly click the button below to complete your repayment.

@component('mail::button', ['url' => $repaymentLink])
Make a Repayment
@endcomponent

For your security, if this request did not originate from you, please let us know by sending an email to <a href="mailto:{{ env('MAIL_ADMIN') }}">{{ env('MAIL_ADMIN') }}</a>.

Thank you for choosing {{ config('app.name') }}.

</x-mail::message>
