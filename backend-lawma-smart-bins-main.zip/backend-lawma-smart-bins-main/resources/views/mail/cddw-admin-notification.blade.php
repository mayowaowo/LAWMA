<x-mail::message>
<b> {{__('Hello')}} {{ $name }}, </b>

Welcome aboard!
Your account has been successfully created on the LAWMA Construction & Disaster Waste Registration Portal. You can now log in to the admin dashboard.
<p>Here are your login details:</p>

- **Portal URL:** 
    <div style="text-align: center; background: #FAFAFA; padding: 10px;">
        <a href="https://cddw.lawmasmartbins.com" target="_blank">cddw.lawmasmartbins.com</a>
    </div> 
- **Email:** <h3 style="text-align: center;background: #FAFAFA; padding: 10px">{{ $email }}</h3> 
- **Temporary Password:**<h3 style="text-align: center;background: #FAFAFA; padding: 10px">{{ $password }}</h3> 

<h3 style="text-align: center;background: #FAFAFA; padding: 10px">
    Important: Please change your password after your first login for security reasons.
</h3> 
{{-- @component('mail::button', ['url' => $link])
Reset Your Password
@endcomponent --}}

{{-- - **Referral Code:**<h3 style="text-align: center;background: #FAFAFA; padding: 10px"> {{ $referralCode }} </h3> 
Share this code with others to register on <a href="https://lawmasmartbins.com" target="_blank">lawmasmartbins.com</a> and earn commissions for every successful referral. --}}

Thank you for being a part of the Smart Bin initiative — together, we’re making Lagos cleaner and smarter!
 
Best regards,<br>
The {{ config('app.name') }} Team
</x-mail::message>
