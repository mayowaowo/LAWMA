<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return response(config('app.name')." ::: ".config('app.env'), 200)
        ->header('Content-Type', 'text/plain');
});
Route::get(
    'health', 
    [\App\Http\Controllers\HealthCheckController::class, 'health']
)->name('health');