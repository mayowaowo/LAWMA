<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Merchant\OrderController;
use App\Http\Controllers\Merchant\DashboardController;
use App\Http\Controllers\Merchant\Auth\LoginController;
use App\Http\Controllers\Merchant\Auth\LogoutController;
use App\Http\Controllers\Merchant\VirtualAccountWebhook;
use App\Http\Controllers\Merchant\Auth\RegisterController;
use App\Http\Controllers\Merchant\Auth\ForgotPasswordController;
use App\Http\Controllers\Merchant\Auth\EmailVerificationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::get('', function () {
    return [
        'app' => 'MERCHANT API APP',
        'version' => '1.0.0',
    ];
});
Route::post('', function () {
    return [
        'app' => 'MERCHANT API APP',
        'version' => '1.0.0',
    ];
});

Route::post('virtual-account-webhook', [VirtualAccountWebhook::class, 'handleVirtualAccountWebhook']);
Route::group(['middleware' => ['apiLog']], function () {
    Route::group(['prefix' => 'auth'], function () {
        Route::post('signup', [RegisterController::class, 'register']);
        Route::post('login', [LoginController::class, 'login']);
        Route::post('email-verification', [EmailVerificationController::class, 'emailVerification']);
        Route::get('resend-otp/{uuid}', [EmailVerificationController::class, 'resendOtp']);
        Route::post('forgot-password', [ForgotPasswordController::class, 'forgotPassword']);
        Route::get('forgot-password-resend-otp/{uuid}', [ForgotPasswordController::class, 'resendOtp']);
        Route::post('forgot-password-process', [ForgotPasswordController::class, 'emailAuthentication']);

        Route::group(['middleware' => ['auth:sanctum']], function () {
            Route::get('logout', [LogoutController::class, 'logout']);
        });
    });
    Route::group(['middleware' => ['auth:sanctum']], function () {
        Route::get('dashboard', [DashboardController::class, 'dashboard']);
        Route::post('order', [OrderController::class, 'order']);
        Route::get('orders-history', [OrderController::class, 'orderHistory']);
        Route::post('pay-next-installment', [OrderController::class, 'nextPaymentInstallment']);
    });
});

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

