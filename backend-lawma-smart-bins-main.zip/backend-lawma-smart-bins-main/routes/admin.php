<?php

use App\Http\Controllers\ActivityController;
use App\Http\Controllers\Admin\Auth\LoginController;
use App\Http\Controllers\Admin\BinController;
use App\Http\Controllers\Admin\CommissionController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\SettingsController;
use App\Http\Controllers\Admin\TransactionController;
use App\Http\Controllers\Admin\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/


Route::get('', function () {
    return [
        'app' => 'ADMIN API APP',
        'version' => '1.0.0',
    ];
});
Route::post('', function () {
    return [
        'app' => 'ADMIN API APP',
        'version' => '1.0.0',
    ];
});

Route::prefix('reports')->group(function () {
   
    Route::get('/export', [ReportController::class, 'export']);
    
});

Route::group(['middleware' => ['apiLog']], function () {
    Route::group(['prefix' => 'auth'], function () {

        Route::post('login', [LoginController::class, 'login']);
        Route::post('verify-otp', [LoginController::class, 'verifyOtp']);

        Route::group(['middleware' => ['auth:sanctum']], function () {
        });
    });

    Route::prefix('bin')->group(function () {
        Route::get('/', [BinController::class, 'allBins']);
    });


    Route::group(['middleware' => ['auth:sanctum', 'admin']], function () {
        Route::get('dashboard', [DashboardController::class, 'dashboard']);

        Route::prefix('bin')->group(function () {
            Route::post('add', [BinController::class, 'addBin']);
            //Route::get('/', [BinController::class, 'allBins']);
            Route::post('edit/{id}', [BinController::class, 'editBin']);
        });

        Route::prefix('order')->group(function () {
            Route::get('/', [OrderController::class, 'getAllOrders']);
            Route::get('/user/{id}', [OrderController::class, 'getUserOrders']);
            Route::get('/info/{order_reference}', [OrderController::class, 'getOrderPayementInformation']);
            Route::post('/{id}', [OrderController::class, 'editOrderStatus']);
            
        });

        Route::prefix('settings')->group(function () {
            Route::get('/roles', [SettingsController::class, 'roleMgt']);
            Route::put('/users/{user}/role', [RoleController::class, 'update']);
        });

        Route::prefix('agents')->group(function () {
            Route::post('/', [UserController::class, 'createAgent']);
            Route::get('/', [UserController::class, 'getAllAgents']);
            Route::get('/users', [UserController::class, 'getAllRegisteredUsers']);
            Route::post('/deactivate/{id}', [UserController::class, 'deactivateAgent']);
            Route::post('/activate/{id}', [UserController::class, 'activateAgent']);
        });

        Route::prefix('reports')->group(function () {
            Route::get('/', [ReportController::class, 'reports']);
            //Route::get('/export', [ReportController::class, 'export']);
            
        });

        Route::prefix('commissions')->group(function () {
            Route::get('/', [CommissionController::class, 'allCommissions']);
            Route::post('/edit/{id}', [CommissionController::class, 'editCommission']);
            Route::post('/mark/{id}', [CommissionController::class, 'markCommissionAsPaid']);
        });


        Route::prefix('user')->group(function () {
            Route::post('/add', [UserController::class, 'addAdmin']);
            Route::get('/', [UserController::class, 'getAdmin']);
        });

        Route::prefix('repayments')->group(function () {
            Route::get('/', [TransactionController::class, 'manualRepayments']);
        });

        Route::get('/activities', [ActivityController::class, 'index']);
        Route::get('/admin-activities', [ActivityController::class, 'index_']);
    });
});
