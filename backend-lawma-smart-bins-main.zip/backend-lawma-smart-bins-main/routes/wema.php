<?php

use App\Http\Controllers\Wema\Auth\LoginController;
use App\Http\Controllers\Wema\CustomerController;
use App\Http\Controllers\Wema\DashboardController;
use App\Http\Controllers\Wema\DirectDebitsController;
use App\Http\Controllers\Wema\RepaymentsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::get('', function () {
    return [
        'app' => 'WEMA PORTAL API APP',
        'version' => '1.0.0',
    ];
});
Route::post('', function () {
    return [
        'app' => 'WEMA PORTAL API APP',
        'version' => '1.0.0',
    ];
});


Route::group(['middleware' => ['apiLog']], function () {
    Route::group(['prefix' => 'auth'], function () {
        Route::post('login', [LoginController::class, 'login']);
    });

    Route::group(['middleware' => ['auth:sanctum']], function () {
        Route::get('dashboard', [DashboardController::class, 'dashboard']);
        Route::get('customers', [CustomerController::class, 'customers']);
        Route::get('installments', [RepaymentsController::class, 'activeInstallmentPlans']);
        Route::get('direct-debit', [DirectDebitsController::class, 'directDebit']);
        Route::get('repayments', [RepaymentsController::class, 'manualRepayments']);
        
    });
});


// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

