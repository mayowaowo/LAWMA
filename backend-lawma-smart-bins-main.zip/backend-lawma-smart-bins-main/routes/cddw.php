
<?php

use App\Http\Controllers\Cddw\RoleController;
use App\Http\Controllers\Cddw\AdminController;
use App\Http\Controllers\Cddw\CustomerController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;



Route::post('', function () {
    return [
        'app' => 'CDDW API APP',
        'version' => '1.0.0',
    ];
});

Route::prefix('admin')->group(function () {
    Route::get('/export', [AdminController::class, 'export']);
});

Route::group(['middleware' => ['apiLog']], function () {
    
    Route::group(['prefix' => 'customer'], function () {
        Route::post('application', [CustomerController::class, 'newApplicantRegister']);
        Route::post('login', [CustomerController::class, 'login']);

        Route::group(['middleware' => ['auth:sanctum']], function () {
            Route::post('/new-register', [CustomerController::class, 'registration']);
            Route::get('/registration', [CustomerController::class, 'getRegistration']);
            Route::post('/edit-profile', [CustomerController::class, 'updateProfile']);
            Route::get('/registration/search', [CustomerController::class, 'searchCustomer']);
            Route::get('/email/{id}', [CustomerController::class, 'sendEmail']);
            
        });

    });

    Route::group(['prefix' => 'admin'], function () {
        Route::post('login', [AdminController::class, 'login']);
    
        Route::group(['middleware' => ['auth:sanctum']], function () {
            Route::post('logout', [AdminController::class, 'logout']);
            Route::get('/dashboard', [AdminController::class, 'dashboard']);
            Route::post('/change-password', [AdminController::class, 'changePassword']);
            Route::get('/registration', [AdminController::class, 'registerations']);
            Route::get('/applicants', [AdminController::class, 'applicants']);
            Route::get('/transactions', [AdminController::class, 'transactions']);
            Route::prefix('user')->group(function () {
                Route::post('/add', [RoleController::class, 'addAdmin']);
                Route::get('/', [RoleController::class, 'getAdmin']);
                Route::post('/edit', [AdminController::class, 'editAdminUser']);
                Route::delete('/{id}', [AdminController::class, 'deleteAdminUser']);
            });
            
            
            Route::get('/activities', [AdminController::class, 'allActivityLogs']);

            Route::prefix('roles')->group(function () {
                Route::post('/add', [RoleController::class, 'addRole']);
                Route::get('/', [RoleController::class, 'roleMgt']);
                Route::get('/permissions', [RoleController::class, 'permissionMgt']);
            });
        });

    });
   
});
