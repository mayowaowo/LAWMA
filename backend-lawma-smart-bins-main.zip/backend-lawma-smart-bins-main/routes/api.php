<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return [
        'app' => 'LAWMA SMART BINS APP API',
        'version' => '1.0.0',
    ];
});
Route::post('/', function () {
    return [
        'app' => 'LAWMA SMART BINS APP API',
        'version' => '1.0.0',
    ];
});


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');
